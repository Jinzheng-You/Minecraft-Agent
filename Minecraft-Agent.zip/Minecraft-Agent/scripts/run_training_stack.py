#!/usr/bin/env python3
"""
Start local Paper 1.20.1 + Mineflayer bridge for HRL training.

This is a process orchestrator, not a trainer. It keeps paths pinned to the
coursework workspace and can optionally launch python/main.py for real-server
PPO/DQN training after the bridge is ready.
"""

from __future__ import annotations

import argparse
import os
import shutil
import signal
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path


PROJECT_ROOT = Path(r"D:\PythonProject\RL_Final\RLFinal\Minecraft-Agent")
CONDA_ROOT = Path(r"D:\PythonProject\RL_Final\.conda")
SERVER_DIR = PROJECT_ROOT / "minecraft-server"
MINEFLAYER_DIR = PROJECT_ROOT / "mineflayer"
PYTHON_EXE = CONDA_ROOT / "python.exe"
NODE_EXE = CONDA_ROOT / "node.exe"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--mc-port", type=int, default=25565)
    p.add_argument("--bridge-port", type=int, default=8765)
    p.add_argument("--mc-version", default="1.20.1")
    p.add_argument("--username", default="DQN_bot")
    p.add_argument("--memory", default="3G")
    p.add_argument("--reset-world", action="store_true", help="Back up and regenerate world/world_nether/world_the_end")
    p.add_argument("--train-real", action="store_true", help="Launch python/main.py against the live bridge")
    p.add_argument("--policy", default="DQN", choices=["DQN", "PPO"])
    p.add_argument("--timesteps", type=int, default=20000)
    p.add_argument("--env-aware", action="store_true")
    return p.parse_args()


def patch_server_properties(port: int) -> None:
    prop_path = SERVER_DIR / "server.properties"
    lines = []
    if prop_path.exists():
        lines = prop_path.read_text(encoding="utf-8", errors="ignore").splitlines()
    values = {
        "server-port": str(port),
        "online-mode": "false",
        "enforce-secure-profile": "false",
        "enable-rcon": "true",
        "rcon.password": "hrltraining",
        "rcon.port": "25575",
        "difficulty": "peaceful",
        "spawn-protection": "0",
        "allow-flight": "true",
        "max-tick-time": "60000",
    }
    seen = set()
    out = []
    for line in lines:
        if not line or line.startswith("#") or "=" not in line:
            out.append(line)
            continue
        key = line.split("=", 1)[0]
        if key in values:
            out.append(f"{key}={values[key]}")
            seen.add(key)
        else:
            out.append(line)
    for key, value in values.items():
        if key not in seen:
            out.append(f"{key}={value}")
    prop_path.write_text("\n".join(out) + "\n", encoding="utf-8")


def backup_worlds() -> None:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = PROJECT_ROOT / "data" / "world_backups" / stamp
    backup_dir.mkdir(parents=True, exist_ok=True)
    for name in ["world", "world_nether", "world_the_end"]:
        src = SERVER_DIR / name
        if src.exists():
            dst = backup_dir / name
            shutil.move(str(src), str(dst))
            print(f"[Stack] Backed up {src.name} -> {dst}")


def stream_output(name: str, process: subprocess.Popen) -> None:
    assert process.stdout is not None
    for raw in process.stdout:
        text = raw.rstrip()
        if text:
            print(f"[{name}] {text}")


def start_process(name: str, args: list[str], cwd: Path, env: dict | None = None) -> subprocess.Popen:
    proc = subprocess.Popen(
        args,
        cwd=str(cwd),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )
    threading.Thread(target=stream_output, args=(name, proc), daemon=True).start()
    return proc


def wait_for_port(host: str, port: int, timeout: float = 120.0) -> bool:
    import socket

    deadline = time.time() + timeout
    while time.time() < deadline:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(2)
            try:
                sock.connect((host, port))
                return True
            except OSError:
                time.sleep(1)
    return False


def main() -> None:
    args = parse_args()
    patch_server_properties(args.mc_port)
    if args.reset_world:
        backup_worlds()

    java_cmd = [
        "java",
        f"-Xmx{args.memory}",
        f"-Xms{args.memory}",
        "-jar",
        str(SERVER_DIR / "paper.jar"),
        "nogui",
    ]
    server = start_process("Paper", java_cmd, SERVER_DIR)
    print("[Stack] Waiting for Paper server port...")
    if not wait_for_port("127.0.0.1", args.mc_port, 180):
        raise RuntimeError("Paper server did not open its port in time")

    node = str(NODE_EXE if NODE_EXE.exists() else "node")
    env = os.environ.copy()
    env.update({
        "MC_HOST": "localhost",
        "MC_PORT": str(args.mc_port),
        "MC_VERSION": args.mc_version,
        "MC_USERNAME": args.username,
        "BRIDGE_PORT": str(args.bridge_port),
        "AUTO_RECONNECT": "1",
        "VIEWER_PORT": "3007",
    })
    bot = start_process("Mineflayer", [node, "src/runner.js"], MINEFLAYER_DIR, env=env)
    print("[Stack] Waiting for Mineflayer bridge...")
    if not wait_for_port("127.0.0.1", args.bridge_port, 120):
        raise RuntimeError("Mineflayer bridge did not open in time")

    trainer = None
    if args.train_real:
        python = str(PYTHON_EXE if PYTHON_EXE.exists() else sys.executable)
        train_cmd = [
            python,
            "main.py",
            "--policy",
            args.policy,
            "--mode",
            "pure_rl",
            "--timesteps",
            str(args.timesteps),
            "--host",
            "localhost",
            "--port",
            str(args.bridge_port),
            "--checkpoint",
            str(PROJECT_ROOT / "python" / "checkpoints" / f"real_{args.policy.lower()}"),
        ]
        if args.env_aware:
            train_cmd.append("--env-aware")
        trainer = start_process("Trainer", train_cmd, PROJECT_ROOT / "python")

    print("[Stack] Running. Press Ctrl+C to stop.")
    children = [p for p in [trainer, bot, server] if p is not None]
    try:
        while all(p.poll() is None for p in [bot, server]):
            time.sleep(1)
    except KeyboardInterrupt:
        print("[Stack] Stopping processes...")
    finally:
        for proc in children:
            if proc.poll() is None:
                proc.terminate()
        time.sleep(3)
        for proc in children:
            if proc.poll() is None:
                proc.kill()


if __name__ == "__main__":
    main()
