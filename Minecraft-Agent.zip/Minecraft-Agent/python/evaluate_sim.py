#!/usr/bin/env python3
"""Evaluate a trained simulated Minecraft HRL Double DQN model."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from agent.ddqn import DDQNConfig, DoubleDQNAgent
from env.sim_minecraft_env import SimMinecraftHRLEnv


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--model", default=str(ROOT / "results" / "sim_ddqn" / "best_model.pt"))
    p.add_argument("--episodes", type=int, default=100)
    p.add_argument("--task", default="mixed", choices=["all", "mixed", "wood", "wooden_pickaxe", "stone_pickaxe", "iron_pickaxe", "diamond_pickaxe"])
    p.add_argument("--difficulty", default="normal", choices=["normal", "hard"])
    p.add_argument("--max-steps", type=int, default=120)
    p.add_argument("--seed", type=int, default=2026)
    p.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    p.add_argument("--action-mask", action="store_true", help="Use valid-action mask during evaluation")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    device = torch.device("cuda" if args.device == "auto" and torch.cuda.is_available() else ("cpu" if args.device == "auto" else args.device))
    env = SimMinecraftHRLEnv(task="mixed", difficulty=args.difficulty, max_steps=args.max_steps, seed=args.seed)
    agent = DoubleDQNAgent(env.state_dim, env.action_dim, DDQNConfig(), device)
    payload = agent.load(args.model, map_location=device)

    tasks = ["wood", "wooden_pickaxe", "stone_pickaxe", "iron_pickaxe", "diamond_pickaxe"] if args.task == "all" else [args.task]
    rewards = []
    successes = []
    steps = []
    invalid = []
    reasons = {}
    per_task = {}

    for task_index, task_name in enumerate(tasks):
        task_rewards = []
        task_successes = []
        task_steps = []
        task_invalid = []
        for ep in range(args.episodes):
            env.config.task = task_name
            state, _ = env.reset(seed=args.seed + task_index * 10000 + ep)
            done = False
            total = 0.0
            info = {}
            while not done:
                mask = env.valid_action_mask() if args.action_mask else None
                action = agent.act(state, valid_mask=mask, epsilon=0.0)
                state, reward, terminated, truncated, info = env.step(action)
                total += reward
                done = terminated or truncated
            task_rewards.append(total)
            task_successes.append(1 if info.get("success") else 0)
            task_steps.append(info.get("steps", 0))
            task_invalid.append(info.get("invalid_actions", 0))
            reasons[info.get("done_reason", "unknown")] = reasons.get(info.get("done_reason", "unknown"), 0) + 1
        per_task[task_name] = {
            "success_rate": float(np.mean(task_successes)),
            "average_reward": float(np.mean(task_rewards)),
            "average_steps": float(np.mean(task_steps)),
            "average_invalid_actions": float(np.mean(task_invalid)),
        }
        rewards.extend(task_rewards)
        successes.extend(task_successes)
        steps.extend(task_steps)
        invalid.extend(task_invalid)

    print(f"Model: {args.model}")
    print(f"Loaded episode: {payload.get('episode', '?')}")
    print(f"Episodes: {args.episodes}")
    print(f"Max steps: {args.max_steps}")
    print(f"Success rate: {np.mean(successes):.3f}")
    print(f"Average reward: {np.mean(rewards):.2f}")
    print(f"Average steps: {np.mean(steps):.2f}")
    print(f"Average invalid actions: {np.mean(invalid):.2f}")
    print(f"Terminal events: {reasons}")
    if len(tasks) > 1:
        print("Per-task results:")
        for task_name, stats in per_task.items():
            print(
                f"  {task_name}: success={stats['success_rate']:.3f} "
                f"reward={stats['average_reward']:.2f} "
                f"steps={stats['average_steps']:.2f} "
                f"invalid={stats['average_invalid_actions']:.2f}"
            )


if __name__ == "__main__":
    main()
