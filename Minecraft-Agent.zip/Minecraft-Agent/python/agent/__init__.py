"""
Minecraft Agent Module

Provides the high-level planner and action novelty components.
"""

try:
    from .planner import (
        HRLAgent,
        ActionNoveltyTracker,
        SkillGraphPlanner,
        NoveltyExplorationCallback,
        evaluate_agent,
        create_state_hash
    )
    from .callbacks import MetricsAndBestModelCallback
except ModuleNotFoundError as exc:
    if exc.name != "stable_baselines3":
        raise
    HRLAgent = None
    ActionNoveltyTracker = None
    SkillGraphPlanner = None
    NoveltyExplorationCallback = None
    MetricsAndBestModelCallback = None

    def evaluate_agent(*args, **kwargs):
        raise ModuleNotFoundError("stable_baselines3 is required for real Minecraft PPO/DQN training")

    def create_state_hash(*args, **kwargs):
        return ""

__all__ = [
    'HRLAgent',
    'ActionNoveltyTracker',
    'SkillGraphPlanner',
    'NoveltyExplorationCallback',
    'MetricsAndBestModelCallback',
    'evaluate_agent',
    'create_state_hash'
]
