"""Training callbacks for real Minecraft HRL runs."""

from __future__ import annotations

import csv
from collections import deque
from pathlib import Path
from typing import Dict, List

import numpy as np
from stable_baselines3.common.callbacks import BaseCallback


class MetricsAndBestModelCallback(BaseCallback):
    """Save metrics and a true best model using success first, reward second."""

    def __init__(self, out_dir: str | Path, window: int = 100, flush_every: int = 100, verbose: int = 0):
        super().__init__(verbose)
        self.out_dir = Path(out_dir)
        self.window = int(window)
        self.flush_every = int(flush_every)
        self.rows: List[Dict] = []
        self.reward_window = deque(maxlen=self.window)
        self.success_window = deque(maxlen=self.window)
        self.steps_window = deque(maxlen=self.window)
        self.invalid_window = deque(maxlen=self.window)
        self.best_success = -1.0
        self.best_reward = -1e9

    def _on_training_start(self) -> None:
        self.out_dir.mkdir(parents=True, exist_ok=True)

    def _on_step(self) -> bool:
        rewards = self.locals.get("rewards", [0.0])
        dones = self.locals.get("dones", [False])
        infos = self.locals.get("infos", [{}])
        reward = float(rewards[0]) if len(rewards) else 0.0
        info = infos[0] if infos else {}
        success = float(info.get("skill_success", False))
        invalid = float(info.get("invalid_action", not bool(info.get("skill_success", True))))

        self.reward_window.append(reward)
        self.success_window.append(success)
        self.invalid_window.append(invalid)
        self.steps_window.append(float(info.get("steps", 0)))

        row = {
            "timestep": int(self.num_timesteps),
            "reward": reward,
            "success": success,
            "steps": float(info.get("steps", 0)),
            "invalid_actions": invalid,
            "skill_name": info.get("skill_name", ""),
            "skill_success": success,
            "done": bool(dones[0]) if len(dones) else False,
            "success_window": float(np.mean(self.success_window)) if self.success_window else 0.0,
            "reward_window": float(np.mean(self.reward_window)) if self.reward_window else 0.0,
            "invalid_window": float(np.mean(self.invalid_window)) if self.invalid_window else 0.0,
        }
        self.rows.append(row)

        current_success = row["success_window"]
        current_reward = row["reward_window"]
        if (current_success > self.best_success) or (
            np.isclose(current_success, self.best_success) and current_reward > self.best_reward
        ):
            self.best_success = current_success
            self.best_reward = current_reward
            best_dir = self.out_dir / "best_model"
            best_dir.mkdir(parents=True, exist_ok=True)
            self.model.save(best_dir / "policy")

        if self.num_timesteps % self.flush_every == 0:
            self.flush()
        return True

    def _on_training_end(self) -> None:
        self.flush()

    def flush(self) -> None:
        if not self.rows:
            return
        path = self.out_dir / "metrics.csv"
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(self.rows[0].keys()))
            writer.writeheader()
            writer.writerows(self.rows)
        try:
            self._plot(path)
        except Exception as exc:
            if self.verbose:
                print(f"[MetricsCallback] Plot skipped: {exc}")

    def _plot(self, path: Path) -> None:
        import matplotlib.pyplot as plt
        import pandas as pd

        df = pd.read_csv(path)
        curves = [
            ("reward", "reward_curve.png", "Reward"),
            ("success", "success_rate_curve.png", "Success"),
            ("steps", "episode_steps_curve.png", "Steps"),
            ("invalid_actions", "invalid_actions_curve.png", "Invalid actions"),
        ]
        for col, filename, title in curves:
            plt.figure(figsize=(8, 4.5))
            plt.plot(df["timestep"], df[col], alpha=0.25)
            plt.plot(df["timestep"], df[col].rolling(self.window, min_periods=1).mean(), linewidth=2)
            plt.title(title)
            plt.xlabel("Timestep")
            plt.grid(alpha=0.25)
            plt.tight_layout()
            plt.savefig(self.out_dir / filename, dpi=150)
            plt.close()
