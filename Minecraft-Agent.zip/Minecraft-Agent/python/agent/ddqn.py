"""
Small Double DQN implementation used by the fast simulation trainer.

The real Minecraft environment can still use Stable-Baselines3 through
planner.py. This module is intentionally self-contained so coursework runs can
produce reproducible checkpoints and metrics without waiting on a live server.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Deque, Dict, Iterable, Tuple

import numpy as np
import torch
from torch import nn


class QNetwork(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class ReplayBuffer:
    def __init__(self, capacity: int, state_dim: int, seed: int = 42):
        self.capacity = int(capacity)
        self.state_dim = int(state_dim)
        self.rng = np.random.default_rng(seed)
        self.states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.next_states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.actions = np.zeros(capacity, dtype=np.int64)
        self.rewards = np.zeros(capacity, dtype=np.float32)
        self.dones = np.zeros(capacity, dtype=np.float32)
        self.pos = 0
        self.size = 0

    def push(self, state, action, reward, next_state, done) -> None:
        self.states[self.pos] = state
        self.actions[self.pos] = action
        self.rewards[self.pos] = reward
        self.next_states[self.pos] = next_state
        self.dones[self.pos] = float(done)
        self.pos = (self.pos + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size: int, device: torch.device) -> Tuple[torch.Tensor, ...]:
        idx = self.rng.integers(0, self.size, size=batch_size)
        return (
            torch.as_tensor(self.states[idx], dtype=torch.float32, device=device),
            torch.as_tensor(self.actions[idx], dtype=torch.long, device=device).unsqueeze(1),
            torch.as_tensor(self.rewards[idx], dtype=torch.float32, device=device).unsqueeze(1),
            torch.as_tensor(self.next_states[idx], dtype=torch.float32, device=device),
            torch.as_tensor(self.dones[idx], dtype=torch.float32, device=device).unsqueeze(1),
        )

    def __len__(self) -> int:
        return self.size


@dataclass
class DDQNConfig:
    gamma: float = 0.99
    lr: float = 1e-3
    batch_size: int = 128
    buffer_size: int = 100000
    target_update_interval: int = 10
    epsilon_start: float = 1.0
    epsilon_end: float = 0.05
    epsilon_decay: float = 0.995
    hidden_dim: int = 128


class DoubleDQNAgent:
    def __init__(self, state_dim: int, action_dim: int, config: DDQNConfig, device: torch.device):
        self.state_dim = int(state_dim)
        self.action_dim = int(action_dim)
        self.config = config
        self.device = device
        self.online = QNetwork(state_dim, action_dim, config.hidden_dim).to(device)
        self.target = QNetwork(state_dim, action_dim, config.hidden_dim).to(device)
        self.target.load_state_dict(self.online.state_dict())
        self.optimizer = torch.optim.Adam(self.online.parameters(), lr=config.lr)
        self.loss_fn = nn.SmoothL1Loss()
        self.epsilon = config.epsilon_start
        self.training_steps = 0

    def act(self, state: np.ndarray, valid_mask: np.ndarray | None = None, epsilon: float | None = None) -> int:
        eps = self.epsilon if epsilon is None else float(epsilon)
        if np.random.random() < eps:
            if valid_mask is not None and valid_mask.sum() > 0:
                return int(np.random.choice(np.flatnonzero(valid_mask > 0)))
            return int(np.random.randint(self.action_dim))

        with torch.no_grad():
            state_t = torch.as_tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
            q_values = self.online(state_t).squeeze(0).detach().cpu().numpy()
        if valid_mask is not None and valid_mask.sum() > 0:
            q_values = q_values.copy()
            q_values[valid_mask <= 0] = -1e9
        return int(np.argmax(q_values))

    def update(self, replay: ReplayBuffer) -> float | None:
        if len(replay) < self.config.batch_size:
            return None
        states, actions, rewards, next_states, dones = replay.sample(self.config.batch_size, self.device)

        q = self.online(states).gather(1, actions)
        with torch.no_grad():
            # Double DQN: online network selects the action, target network
            # evaluates that selected action.
            next_actions = self.online(next_states).argmax(dim=1, keepdim=True)
            next_q = self.target(next_states).gather(1, next_actions)
            target_q = rewards + self.config.gamma * (1.0 - dones) * next_q

        loss = self.loss_fn(q, target_q)
        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.online.parameters(), 10.0)
        self.optimizer.step()
        self.training_steps += 1
        return float(loss.item())

    def update_target(self) -> None:
        self.target.load_state_dict(self.online.state_dict())

    def decay_epsilon(self) -> None:
        self.epsilon = max(self.config.epsilon_end, self.epsilon * self.config.epsilon_decay)

    def save(self, path: str | Path, extra: Dict | None = None) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "online": self.online.state_dict(),
            "target": self.target.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "epsilon": self.epsilon,
            "training_steps": self.training_steps,
            "state_dim": self.state_dim,
            "action_dim": self.action_dim,
            "config": self.config.__dict__,
        }
        if extra:
            payload.update(extra)
        torch.save(payload, path)

    def load(self, path: str | Path, map_location: torch.device | str | None = None) -> Dict:
        payload = torch.load(path, map_location=map_location or self.device)
        self.online.load_state_dict(payload["online"])
        self.target.load_state_dict(payload.get("target", payload["online"]))
        if "optimizer" in payload:
            self.optimizer.load_state_dict(payload["optimizer"])
        self.epsilon = float(payload.get("epsilon", self.epsilon))
        self.training_steps = int(payload.get("training_steps", 0))
        return payload
