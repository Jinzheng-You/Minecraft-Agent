#!/usr/bin/env python3
"""Streamlit dashboard for simulated HRL training outputs."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st


ROOT = Path(__file__).resolve().parent
DEFAULT_RESULTS = ROOT / "results" / "sim_ddqn"


def main() -> None:
    st.set_page_config(page_title="Minecraft HRL Training Results", layout="wide")
    st.title("Minecraft Agent - Training Results")

    results_dir = Path(st.sidebar.text_input("Results directory", str(DEFAULT_RESULTS)))
    metrics_path = results_dir / "metrics.csv"
    if not metrics_path.exists():
        st.warning(f"No metrics.csv found at {metrics_path}")
        return

    df = pd.read_csv(metrics_path)
    latest = df.iloc[-1]
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Episodes", int(latest["episode"]))
    c2.metric("Last success window", f"{latest.get('success_window', df['success'].tail(50).mean()):.2f}")
    c3.metric("Last reward window", f"{latest.get('reward_window', df['reward'].tail(50).mean()):.1f}")
    c4.metric("Invalid actions", f"{df['invalid_actions'].tail(50).mean():.2f}")

    st.dataframe(df.tail(50), use_container_width=True)

    image_names = [
        "training_overview.png",
        "reward_curve.png",
        "success_rate_curve.png",
        "episode_steps_curve.png",
        "invalid_actions_curve.png",
    ]
    for image_name in image_names:
        path = results_dir / image_name
        if path.exists():
            st.image(str(path), caption=image_name, use_container_width=True)


if __name__ == "__main__":
    main()
