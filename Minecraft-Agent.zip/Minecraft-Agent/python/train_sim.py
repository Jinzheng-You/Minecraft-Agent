#!/usr/bin/env python3
"""
Train Double DQN in the lightweight Minecraft simulation.

This mode is for fast coursework iteration. It does not require Minecraft,
Paper, or Mineflayer to be running.
"""

from __future__ import annotations

import argparse
import csv
import sys
from collections import deque
from pathlib import Path
from typing import Dict, List

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from agent.ddqn import DDQNConfig, DoubleDQNAgent, ReplayBuffer
from env.sim_minecraft_env import SimMinecraftAgentEnv


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Train Double DQN in simulated Minecraft environment")
    p.add_argument("--episodes", type=int, default=800)
    p.add_argument("--task", type=str, default="mixed", choices=["mixed", "wood", "wooden_pickaxe", "stone_pickaxe", "iron_pickaxe", "diamond_pickaxe"])
    p.add_argument("--curriculum", action="store_true", help="Train easy-to-hard tasks before mixed fine-tuning")
    p.add_argument(
        "--curriculum-spec",
        default="wood:200,wooden_pickaxe:250,stone_pickaxe:300,iron_pickaxe:400,diamond_pickaxe:500,mixed:350",
        help="Comma-separated task:episodes schedule used when --curriculum is enabled",
    )
    p.add_argument("--eval-task", default=None, choices=["all", "mixed", "wood", "wooden_pickaxe", "stone_pickaxe", "iron_pickaxe", "diamond_pickaxe"])
    p.add_argument("--difficulty", type=str, default="normal", choices=["normal", "hard"])
    p.add_argument("--max-steps", type=int, default=80)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--gamma", type=float, default=0.99)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--batch-size", type=int, default=128)
    p.add_argument("--buffer-size", type=int, default=100000)
    p.add_argument("--target-update-interval", type=int, default=10)
    p.add_argument("--epsilon-start", type=float, default=1.0)
    p.add_argument("--epsilon-end", type=float, default=0.05)
    p.add_argument("--epsilon-decay", type=float, default=0.995)
    p.add_argument("--checkpoint-interval", type=int, default=100)
    p.add_argument("--eval-interval", type=int, default=50)
    p.add_argument("--eval-episodes", type=int, default=30)
    p.add_argument("--eval-seed", type=int, default=100000)
    p.add_argument("--best-after-episode", type=int, default=0, help="Do not update best_model before this episode")
    p.add_argument("--log-interval", type=int, default=25)
    p.add_argument("--window", type=int, default=50)
    p.add_argument("--out-dir", type=str, default=str(ROOT / "results" / "sim_ddqn"))
    p.add_argument("--resume", type=str, default=None, help="Path to checkpoint .pt")
    p.add_argument("--device", type=str, default="auto", choices=["auto", "cpu", "cuda"])
    p.add_argument("--action-mask", action="store_true", help="Use valid-action mask during exploration and exploitation")
    p.add_argument("--eval-action-mask", action="store_true", help="Use valid-action mask during deterministic evaluation")
    return p.parse_args()


def select_device(name: str) -> torch.device:
    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(name)


def parse_curriculum(spec: str) -> List[tuple[str, int]]:
    schedule: List[tuple[str, int]] = []
    for chunk in spec.split(","):
        if not chunk.strip():
            continue
        task, count = chunk.split(":", 1)
        schedule.append((task.strip(), int(count)))
    return schedule


def curriculum_total_episodes(spec: str) -> int:
    return sum(count for _, count in parse_curriculum(spec))


def task_for_episode(args: argparse.Namespace, episode: int) -> str:
    if not args.curriculum:
        return args.task
    total = 0
    for task, count in parse_curriculum(args.curriculum_spec):
        total += count
        if episode <= total:
            return task
    return "mixed"


def write_metrics(path: Path, rows: List[Dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    fieldnames: List[str] = []
    for row in rows:
        for key in row.keys():
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def evaluate_policy(agent: DoubleDQNAgent, args: argparse.Namespace, episodes: int, seed_offset: int) -> Dict[str, float]:
    eval_task = args.eval_task or ("mixed" if args.curriculum else args.task)
    tasks = ["wood", "wooden_pickaxe", "stone_pickaxe", "iron_pickaxe", "diamond_pickaxe"] if eval_task == "all" else [eval_task]
    task_stats: Dict[str, Dict[str, float]] = {}
    all_rewards: List[float] = []
    all_successes: List[int] = []
    all_steps: List[int] = []
    all_invalid: List[int] = []

    for task_index, task_name in enumerate(tasks):
        stats = evaluate_policy_one_task(agent, args, task_name, episodes, seed_offset + task_index * 10000)
        task_stats[task_name] = stats
        all_rewards.append(stats["eval_reward"])
        all_successes.append(stats["eval_success"])
        all_steps.append(stats["eval_steps"])
        all_invalid.append(stats["eval_invalid_actions"])

    result = {
        "eval_success": float(np.mean(all_successes)),
        "eval_reward": float(np.mean(all_rewards)),
        "eval_steps": float(np.mean(all_steps)),
        "eval_invalid_actions": float(np.mean(all_invalid)),
        "eval_min_task_success": float(np.min(all_successes)),
    }
    for task_name, stats in task_stats.items():
        result[f"eval_success_{task_name}"] = stats["eval_success"]
    return result


def evaluate_policy_one_task(agent: DoubleDQNAgent, args: argparse.Namespace, eval_task: str, episodes: int, seed_offset: int) -> Dict[str, float]:
    eval_env = SimMinecraftAgentEnv(
        task=eval_task,
        difficulty=args.difficulty,
        max_steps=args.max_steps,
        seed=args.seed + seed_offset,
    )
    rewards: List[float] = []
    successes: List[int] = []
    steps: List[int] = []
    invalid_actions: List[int] = []

    for idx in range(episodes):
        state, _ = eval_env.reset(seed=args.seed + seed_offset + idx)
        done = False
        total_reward = 0.0
        info: Dict = {}
        while not done:
            mask = eval_env.valid_action_mask() if args.eval_action_mask else None
            action = agent.act(state, valid_mask=mask, epsilon=0.0)
            state, reward, terminated, truncated, info = eval_env.step(action)
            total_reward += reward
            done = bool(terminated or truncated)

        rewards.append(total_reward)
        successes.append(1 if info.get("success") else 0)
        steps.append(int(info.get("steps", 0)))
        invalid_actions.append(int(info.get("invalid_actions", 0)))

    return {
        "eval_success": float(np.mean(successes)),
        "eval_reward": float(np.mean(rewards)),
        "eval_steps": float(np.mean(steps)),
        "eval_invalid_actions": float(np.mean(invalid_actions)),
    }


def train() -> None:
    args = parse_args()
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = select_device(args.device)
    print(f"Using device: {device}")
    if args.curriculum:
        total_schedule = curriculum_total_episodes(args.curriculum_spec)
        if args.episodes < total_schedule:
            print(
                f"Warning: curriculum schedule totals {total_schedule} episodes, "
                f"but --episodes is {args.episodes}. Later tasks may be under-trained."
            )

    out_dir = Path(args.out_dir)
    ckpt_dir = out_dir / "checkpoints"
    out_dir.mkdir(parents=True, exist_ok=True)
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    env = SimMinecraftAgentEnv(
        task=args.task,
        difficulty=args.difficulty,
        max_steps=args.max_steps,
        seed=args.seed,
    )
    config = DDQNConfig(
        gamma=args.gamma,
        lr=args.lr,
        batch_size=args.batch_size,
        buffer_size=args.buffer_size,
        target_update_interval=args.target_update_interval,
        epsilon_start=args.epsilon_start,
        epsilon_end=args.epsilon_end,
        epsilon_decay=args.epsilon_decay,
    )
    agent = DoubleDQNAgent(env.state_dim, env.action_dim, config, device)
    replay = ReplayBuffer(args.buffer_size, env.state_dim, seed=args.seed)

    start_episode = 1
    metrics: List[Dict] = []
    best_success = -1.0
    best_reward = -1e9
    best_min_task_success = -1.0

    if args.resume:
        payload = agent.load(args.resume, map_location=device)
        start_episode = int(payload.get("episode", 0)) + 1
        metrics = list(payload.get("metrics", []))
        best_success = float(payload.get("best_success", best_success))
        best_reward = float(payload.get("best_reward", best_reward))
        best_min_task_success = float(payload.get("best_min_task_success", best_min_task_success))
        print(f"Resumed from {args.resume} at episode {start_episode}")

    success_window: deque = deque(maxlen=args.window)
    reward_window: deque = deque(maxlen=args.window)
    if metrics:
        for row in metrics[-args.window:]:
            success_window.append(float(row.get("success", 0)))
            reward_window.append(float(row.get("reward", 0)))

    for episode in range(start_episode, args.episodes + 1):
        env.config.task = task_for_episode(args, episode)
        state, info = env.reset(seed=args.seed + episode)
        done = False
        total_reward = 0.0
        losses: List[float] = []

        while not done:
            valid_mask = env.valid_action_mask() if args.action_mask else None
            action = agent.act(state, valid_mask=valid_mask)
            next_state, reward, terminated, truncated, info = env.step(action)
            done = bool(terminated or truncated)
            replay.push(state, action, reward, next_state, done)
            loss = agent.update(replay)
            if loss is not None:
                losses.append(loss)
            state = next_state
            total_reward += reward

        agent.decay_epsilon()
        if episode % args.target_update_interval == 0:
            agent.update_target()

        success = 1 if info.get("success") else 0
        success_window.append(success)
        reward_window.append(total_reward)
        row = {
            "episode": episode,
            "task": info.get("task", ""),
            "reward": round(total_reward, 6),
            "success": success,
            "steps": info.get("steps", 0),
            "invalid_actions": info.get("invalid_actions", 0),
            "stage_score": info.get("stage_score", 0),
            "epsilon": round(agent.epsilon, 6),
            "loss": round(float(np.mean(losses)) if losses else 0.0, 6),
            "done_reason": info.get("done_reason", ""),
            "success_window": round(float(np.mean(success_window)), 6),
            "reward_window": round(float(np.mean(reward_window)), 6),
        }
        metrics.append(row)

        current_success = float(np.mean(success_window))
        did_eval = episode == 1 or episode % args.eval_interval == 0 or episode == args.episodes
        eval_stats = {
            "eval_success": "",
            "eval_reward": "",
            "eval_steps": "",
            "eval_invalid_actions": "",
            "eval_min_task_success": "",
        }
        if did_eval:
            eval_stats = evaluate_policy(agent, args, args.eval_episodes, args.eval_seed + episode * 1000)
            row.update({key: round(value, 6) for key, value in eval_stats.items()})
            eval_success = float(eval_stats["eval_success"])
            eval_reward = float(eval_stats["eval_reward"])
            eval_min_success = float(eval_stats.get("eval_min_task_success", eval_success))
            can_update_best = episode >= args.best_after_episode
            if args.eval_task == "all":
                is_better = (
                    (eval_min_success > best_min_task_success) or
                    (
                        np.isclose(eval_min_success, best_min_task_success) and
                        (
                            eval_success > best_success or
                            (np.isclose(eval_success, best_success) and eval_reward > best_reward)
                        )
                    )
                )
            else:
                is_better = (
                    (eval_success > best_success) or
                    (np.isclose(eval_success, best_success) and eval_reward > best_reward)
                )
            if can_update_best and is_better:
                best_success = eval_success
                best_reward = eval_reward
                best_min_task_success = eval_min_success
                agent.save(out_dir / "best_model.pt", {
                    "episode": episode,
                    "metrics": metrics,
                    "best_success": best_success,
                    "best_reward": best_reward,
                    "best_min_task_success": best_min_task_success,
                    "best_source": "deterministic_eval",
                    "eval_stats": eval_stats,
                    "skill_subset": info.get("skill_subset", []),
                })
        else:
            row.update(eval_stats)

        if did_eval:
            print(
                f"  eval@{episode}: success={float(eval_stats['eval_success']):.3f} "
                f"min_task={float(eval_stats.get('eval_min_task_success', eval_stats['eval_success'])):.3f} "
                f"reward={float(eval_stats['eval_reward']):.2f} "
                f"steps={float(eval_stats['eval_steps']):.1f} "
                f"invalid={float(eval_stats['eval_invalid_actions']):.1f}"
            )

        if episode % args.checkpoint_interval == 0:
            agent.save(ckpt_dir / f"checkpoint_ep_{episode:05d}.pt", {
                "episode": episode,
                "metrics": metrics,
                "best_success": best_success,
                "best_reward": best_reward,
                "best_min_task_success": best_min_task_success,
                "skill_subset": info.get("skill_subset", []),
            })
            write_metrics(out_dir / "metrics.csv", metrics)

        if episode % args.log_interval == 0 or episode == 1:
            print(
                f"Episode {episode:04d}/{args.episodes} "
                f"reward={total_reward:8.2f} "
                f"success{args.window}={current_success:.2f} "
                f"steps={row['steps']:3d} invalid={row['invalid_actions']:2d} "
                f"task={row['task']} eps={agent.epsilon:.3f}"
            )

    agent.save(out_dir / "final_model.pt", {
        "episode": args.episodes,
        "metrics": metrics,
        "best_success": best_success,
        "best_reward": best_reward,
        "best_min_task_success": best_min_task_success,
    })
    write_metrics(out_dir / "metrics.csv", metrics)

    try:
        from plot_sim_results import plot_metrics

        plot_metrics(out_dir / "metrics.csv", out_dir)
    except Exception as exc:
        print(f"Plot warning: {exc}")

    print(f"Saved final model: {out_dir / 'final_model.pt'}")
    print(f"Saved best model:  {out_dir / 'best_model.pt'} | success={best_success:.3f} reward={best_reward:.2f}")
    print(f"Saved metrics:     {out_dir / 'metrics.csv'}")


if __name__ == "__main__":
    train()
