"""
MinecraftHRLEnv - Gymnasium Environment Wrapper

This environment wraps the Minecraft world for Hierarchical RL.
Following the Options Framework (Sutton, Precup, Singh 1999), the action space
consists of discrete "options" (skills) rather than primitive actions.

Key Design Decisions:
1. Action Space: Discrete(N) where N = number of skills in the library
2. Observation Space: Dict space with high-level state features
3. Reward: Combination of intrinsic (skill success) and extrinsic (goal progress)

Reference Papers:
- Voyager: Code-as-action paradigm
- Plan4MC: Skill decomposition
- DEPS: Error correction loop
"""

import gymnasium as gym
from gymnasium import spaces
import numpy as np
import json
import asyncio
import websockets
from typing import Dict, Any, Tuple, Optional
import time
import threading
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "..", "data"))
from reward.context_reward import ContextRewardShaper
from env.sim_minecraft_env import CORE_SKILL_IDS, SKILL_NAMES
try:
    from config import BIOMES, STRUCTURES
    _BIOME_IDX  = {b: i for i, b in enumerate(BIOMES)}
    _STRUCT_IDX = {s: i for i, s in enumerate(STRUCTURES)}
except ImportError:
    BIOMES, STRUCTURES = [], []
    _BIOME_IDX, _STRUCT_IDX = {}, {}


class MinecraftHRLEnv(gym.Env):
    """
    Gymnasium environment for Hierarchical RL in Minecraft.
    
    The environment communicates with a Mineflayer bot via WebSocket.
    Actions are skill IDs that trigger temporally-extended behaviors.
    
    Observation Space (Dict):
        - health: float [0, 20]
        - food: float [0, 20]
        - position: Box(3,) - x, y, z coordinates
        - inventory: MultiBinary(N) - presence of key items
        - nearby_blocks: Box(M,) - counts of nearby block types
        - available_skills: MultiBinary(K) - which skills can be executed
        
    Action Space:
        - Discrete(K) where K = number of skills
        
    Reward:
        - Intrinsic: Based on skill success/failure
        - Extrinsic: Based on tech tree progress
    """
    
    metadata = {"render_modes": ["human", "none"], "render_fps": 1}
    
    # Key items to track in observation (order matters for encoding)
    TRACKED_ITEMS = [
        # Wood tier
        'oak_log', 'birch_log', 'spruce_log',
        'oak_planks', 'birch_planks', 'spruce_planks',
        'stick', 'crafting_table',
        'wooden_pickaxe',
        # Stone tier
        'cobblestone', 'stone', 'stone_pickaxe',
        # Iron tier
        'coal', 'raw_iron', 'iron_ingot', 'furnace',
        'iron_pickaxe',
        'iron_helmet', 'iron_chestplate', 'iron_leggings', 'iron_boots',
        # Diamond tier
        'diamond',
        'diamond_pickaxe',
        'diamond_helmet', 'diamond_chestplate', 'diamond_leggings', 'diamond_boots',
        # Food / misc
        'chest', 'apple', 'bread', 'cooked_beef'
    ]

    # Block types to track (order matters for encoding)
    TRACKED_BLOCKS = [
        'oak_log', 'birch_log', 'spruce_log',
        'stone', 'cobblestone',
        'iron_ore', 'deepslate_iron_ore',
        'coal_ore', 'deepslate_coal_ore',
        'diamond_ore', 'deepslate_diamond_ore',
        'crafting_table', 'furnace',
        'water', 'lava'
    ]
    
    def __init__(
        self,
        host: str = "localhost",
        port: int = 8765,
        render_mode: Optional[str] = None,
        max_episode_steps: int = 1000,
        env_aware: bool = False,
        context_reward: bool = True,
        hard_reset: bool = False,
    ):
        super().__init__()

        self.host = host
        self.port = port
        self.render_mode = render_mode
        self.max_episode_steps = max_episode_steps
        self.env_aware = env_aware          # include biome/structure in observation
        self.context_reward = context_reward  # enable context-sensitive reward bonus
        self.hard_reset = hard_reset
        
        # WebSocket connection
        self.ws = None
        self._loop = None
        self._ws_thread = None
        
        # State tracking
        self._current_state = None
        self._step_count = 0
        self._connected = False
        
        # Will be set after connecting to get actual skill count
        self._num_skills = 13  # Default, updated on connect
        self._skill_info = []

        # Context-sensitive reward shaper (only instantiated when enabled)
        self.context_shaper = ContextRewardShaper() if context_reward else None

        # Define spaces (will be updated after connection)
        self._define_spaces()
        
    def _define_spaces(self):
        """Define observation and action spaces."""
        
        # Observation space as a Dict
        self.observation_space = spaces.Dict({
            # Player stats (normalized)
            'health': spaces.Box(low=0, high=1, shape=(1,), dtype=np.float32),
            'food': spaces.Box(low=0, high=1, shape=(1,), dtype=np.float32),
            
            # Position (normalized to reasonable range)
            'position': spaces.Box(
                low=-1, high=1, 
                shape=(3,), 
                dtype=np.float32
            ),
            
            # Inventory: count of each tracked item (capped)
            'inventory': spaces.Box(
                low=0, high=64,
                shape=(len(self.TRACKED_ITEMS),),
                dtype=np.float32
            ),
            
            # Nearby blocks: distance to nearest (normalized)
            'nearby_blocks': spaces.Box(
                low=0, high=1,
                shape=(len(self.TRACKED_BLOCKS),),
                dtype=np.float32
            ),
            
            # Available skills: binary mask
            'available_skills': spaces.MultiBinary(self._num_skills),
            
            # Time of day (normalized)
            'time_of_day': spaces.Box(low=0, high=1, shape=(1,), dtype=np.float32),

            # Is daytime
            'is_day': spaces.MultiBinary(1)
        })

        # env-aware mode: extend observation with biome + structure context
        if self.env_aware and BIOMES:
            self.observation_space.spaces['biome_vec'] = spaces.Box(
                low=0, high=1, shape=(len(BIOMES),), dtype=np.float32
            )
            self.observation_space.spaces['structure_vec'] = spaces.Box(
                low=0, high=1, shape=(len(STRUCTURES),), dtype=np.float32
            )
        
        # Action space: discrete skill selection
        self.action_space = spaces.Discrete(self._num_skills)
        
    def connect(self, timeout: float = 30.0) -> bool:
        """
        Establish WebSocket connection to the Mineflayer bot.
        
        Args:
            timeout: Maximum time to wait for connection
            
        Returns:
            True if connected successfully
        """
        async def _connect():
            uri = f"ws://{self.host}:{self.port}"
            try:
                self.ws = await asyncio.wait_for(
                    websockets.connect(uri, ping_interval=20, ping_timeout=20),
                    timeout=timeout
                )
                
                # Get action space info
                await self.ws.send(json.dumps({'type': 'get_action_space'}))
                response = json.loads(await self.ws.recv())
                
                if response['type'] == 'action_space':
                    self._num_skills = response['n']
                    self._skill_info = response['skills']
                    self._define_spaces()  # Redefine with correct skill count
                    
                self._connected = True
                print(f"[Env] Connected to Mineflayer bot")
                print(f"[Env] Action space: {self._num_skills} skills")
                return True
                
            except Exception as e:
                print(f"[Env] Connection failed: {e}")
                return False
        
        # Run in event loop
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
        return loop.run_until_complete(_connect())
    
    def _send_and_receive(self, message: dict) -> dict:
        """Send a message and wait for response, with reconnect on dropped connection."""
        async def _async_send():
            await self.ws.send(json.dumps(message))
            return json.loads(await self.ws.recv())

        for attempt in range(5):
            try:
                loop = asyncio.get_event_loop()
                return loop.run_until_complete(_async_send())
            except Exception as e:
                print(f"[Env] WebSocket error (attempt {attempt + 1}/5): {e} — reconnecting...")
                time.sleep(3)
                self.connect(timeout=30.0)
        raise RuntimeError("[Env] Failed to communicate with Mineflayer after 5 reconnect attempts")
    
    def _encode_observation(self, state: dict) -> dict:
        """
        Convert raw state dict to observation space format.
        
        This is where we transform the rich Minecraft state into
        a fixed-size numerical representation suitable for RL.
        """
        obs = {}
        
        # Health and food (normalized to [0, 1])
        # Guard against null values sent during bot spawn before vitals are populated
        obs['health'] = np.array([(state.get('health') or 20) / 20.0], dtype=np.float32)
        obs['food'] = np.array([(state.get('food') or 20) / 20.0], dtype=np.float32)
        
        # Position (normalize to [-1, 1] assuming ±10000 range)
        # Guard against null position components sent during bot death/respawn
        pos = state.get('position') or {}
        pos_x = pos.get('x') or 0
        pos_y = pos.get('y') or 64
        pos_z = pos.get('z') or 0
        obs['position'] = np.array([
            pos_x / 10000.0,
            (pos_y - 64) / 64.0,  # Center around sea level
            pos_z / 10000.0
        ], dtype=np.float32).clip(-1, 1)
        
        # Inventory encoding
        inventory = state.get('inventory', {})
        inv_vec = np.zeros(len(self.TRACKED_ITEMS), dtype=np.float32)
        for i, item in enumerate(self.TRACKED_ITEMS):
            inv_vec[i] = min(inventory.get(item, 0), 64)
        obs['inventory'] = inv_vec
        
        # Nearby blocks (inverse distance, normalized)
        nearby = state.get('nearby_blocks', {})
        blocks_vec = np.zeros(len(self.TRACKED_BLOCKS), dtype=np.float32)
        for i, block in enumerate(self.TRACKED_BLOCKS):
            if block in nearby:
                # Convert distance to proximity (closer = higher value)
                dist = nearby[block].get('nearest_distance', 64)
                blocks_vec[i] = max(0, 1 - dist / 64)
        obs['nearby_blocks'] = blocks_vec
        
        # Available skills mask
        available = state.get('available_skills', list(range(self._num_skills)))
        skills_mask = np.zeros(self._num_skills, dtype=np.int8)
        for skill_id in available:
            if skill_id < self._num_skills:
                skills_mask[skill_id] = 1
        obs['available_skills'] = skills_mask
        
        # Time of day
        time_of_day = state.get('time_of_day') or 0
        obs['time_of_day'] = np.array([time_of_day / 24000.0], dtype=np.float32)
        obs['is_day'] = np.array([1 if state.get('is_day', True) else 0], dtype=np.int8)

        # env-aware mode: add biome one-hot and structure multi-hot
        if self.env_aware and BIOMES:
            biome_vec = np.zeros(len(BIOMES), dtype=np.float32)
            biome_idx = _BIOME_IDX.get(state.get("biome", ""), -1)
            if biome_idx >= 0:
                biome_vec[biome_idx] = 1.0
            obs['biome_vec'] = biome_vec

            structure_vec = np.zeros(len(STRUCTURES), dtype=np.float32)
            for struct in state.get("nearby_structures", []):
                sidx = _STRUCT_IDX.get(struct, -1)
                if sidx >= 0:
                    structure_vec[sidx] = 1.0
            obs['structure_vec'] = structure_vec

        return obs
    
    def reset(
        self,
        seed: Optional[int] = None,
        options: Optional[dict] = None
    ) -> Tuple[dict, dict]:
        """
        Reset the environment.
        
        Note: True reset requires server-side commands. This performs
        a "soft reset" that continues from current bot state.
        """
        super().reset(seed=seed)
        
        if not self._connected:
            if not self.connect():
                raise RuntimeError("Failed to connect to Mineflayer bot")
        
        self._step_count = 0
        if self.context_shaper is not None:
            self.context_shaper.reset()

        # Send reset command
        response = self._send_and_receive({'type': 'reset', 'hard': self.hard_reset})
        
        if response['type'] != 'reset_result':
            raise RuntimeError(f"Unexpected response: {response}")
        
        self._current_state = response['state']
        obs = self._encode_observation(self._current_state)
        
        info = response.get('info', {})
        info['raw_state'] = self._current_state
        info['hard_reset'] = self.hard_reset
        
        return obs, info
    
    def step(self, action: int) -> Tuple[dict, float, bool, bool, dict]:
        """
        Execute a skill and return the result.
        
        Args:
            action: Skill ID to execute
            
        Returns:
            observation: Encoded state after skill execution
            reward: Reward signal
            terminated: True if episode ended (death or goal reached)
            truncated: True if max steps exceeded
            info: Additional information (skill result, raw state)
        """
        if not self._connected:
            raise RuntimeError("Not connected to Mineflayer bot")
        
        self._step_count += 1
        
        # Execute the skill
        response = self._send_and_receive({
            'type': 'step',
            'action': int(action)
        })
        
        if response['type'] != 'step_result':
            raise RuntimeError(f"Unexpected response: {response}")
        
        self._current_state = response['state']
        obs = self._encode_observation(self._current_state)

        # Base reward from tech tree (via Mineflayer bot)
        base_reward = response['reward']

        # Context-sensitive bonus: rewards structure shortcuts and biome-adaptive play
        context_bonus = 0.0
        if self.context_shaper is not None:
            skill_name = self.get_skill_name(action)
            context_obs = {
                "biome": self._current_state.get("biome", ""),
                "nearby_structures": self._current_state.get("nearby_structures", []),
            }
            context_bonus = self.context_shaper.get_bonus(context_obs, skill_name)
        reward = base_reward + context_bonus

        terminated = response['done']
        truncated = response.get('truncated', self._step_count >= self.max_episode_steps)

        info = response.get('info', {})
        info['raw_state'] = self._current_state
        info['base_reward'] = base_reward
        info['context_bonus'] = context_bonus
        info['invalid_action'] = bool(info.get('invalid_action', False))

        return obs, reward, terminated, truncated, info
    
    def render(self):
        """Render the environment (print state summary)."""
        if self.render_mode == "human" and self._current_state:
            state = self._current_state
            print(f"\n{'='*40}")
            print(f"Step: {self._step_count}")
            print(f"Health: {state.get('health', '?')}/20")
            print(f"Food: {state.get('food', '?')}/20")
            print(f"Position: {state.get('position', '?')}")
            print(f"Inventory: {len(state.get('inventory', {}))} item types")
            print(f"Available skills: {state.get('available_skills', [])}")
            print(f"{'='*40}")
    
    def close(self):
        """Clean up resources."""
        if self.ws:
            asyncio.get_event_loop().run_until_complete(self.ws.close())
            self.ws = None
            self._connected = False
            print("[Env] Disconnected from Mineflayer bot")
    
    def get_skill_info(self) -> list:
        """Return information about available skills."""
        return self._skill_info
    
    def get_skill_name(self, action: int) -> str:
        """Get the name of a skill by ID."""
        for skill in self._skill_info:
            if skill['id'] == action:
                return skill['name']
        return f"skill_{action}"


# Wrapper for flattened observation space (for standard SB3 algorithms)
class FlatMinecraftEnv(gym.ObservationWrapper):
    """
    Flattens the Dict observation space into a single Box space.
    Useful for algorithms that don't support Dict observations.
    """
    
    def __init__(self, env: MinecraftHRLEnv):
        super().__init__(env)
        
        # Calculate flattened size
        self._obs_keys = list(env.observation_space.spaces.keys())
        self._obs_sizes = {}
        total_size = 0
        
        for key in self._obs_keys:
            space = env.observation_space.spaces[key]
            if isinstance(space, spaces.Box):
                size = int(np.prod(space.shape))
            elif isinstance(space, spaces.MultiBinary):
                size = space.n
            else:
                raise ValueError(f"Unsupported space type: {type(space)}")
            self._obs_sizes[key] = size
            total_size += size
        
        self.observation_space = spaces.Box(
            low=-np.inf, high=np.inf,
            shape=(total_size,),
            dtype=np.float32
        )
    
    def _recompute_flat_space(self):
        """Recompute flat observation space from the inner env's current spaces.
        Must be called after the inner env's skill count is updated via connect()."""
        self._obs_keys = list(self.env.observation_space.spaces.keys())
        self._obs_sizes = {}
        total_size = 0
        for key in self._obs_keys:
            space = self.env.observation_space.spaces[key]
            if isinstance(space, spaces.Box):
                size = int(np.prod(space.shape))
            elif isinstance(space, spaces.MultiBinary):
                size = space.n
            else:
                raise ValueError(f"Unsupported space type: {type(space)}")
            self._obs_sizes[key] = size
            total_size += size
        self.observation_space = spaces.Box(
            low=-np.inf, high=np.inf,
            shape=(total_size,),
            dtype=np.float32
        )

    def connect(self, timeout: float = 30.0) -> bool:
        """Connect the inner env and recompute the flat observation space."""
        result = self.env.unwrapped.connect(timeout=timeout)
        if result:
            self._recompute_flat_space()
        return result

    def observation(self, obs: dict) -> np.ndarray:
        """Flatten the observation dict into a single array."""
        parts = []
        for key in self._obs_keys:
            arr = np.asarray(obs[key], dtype=np.float32).flatten()
            parts.append(arr)
        return np.concatenate(parts)


class SkillSubsetActionWrapper(gym.ActionWrapper):
    """Map a compact action space onto selected original Mineflayer skill IDs."""

    def __init__(self, env: gym.Env, skill_ids: list[int]):
        super().__init__(env)
        self.skill_ids = list(skill_ids)
        self.action_space = spaces.Discrete(len(self.skill_ids))

    def action(self, action: int) -> int:
        return int(self.skill_ids[int(action)])

    def get_skill_name(self, action: int) -> str:
        original = self.action(action)
        base = self.env.unwrapped
        if hasattr(base, "get_skill_name"):
            return base.get_skill_name(original)
        return SKILL_NAMES.get(original, f"skill_{original}")

    def original_skill_id(self, action: int) -> int:
        return self.action(action)

    def connect(self, timeout: float = 30.0) -> bool:
        connector = getattr(self.env, "connect", None) or getattr(self.env.unwrapped, "connect")
        return connector(timeout=timeout)


# Factory function for easy environment creation
def make_minecraft_env(
    host: str = "localhost",
    port: int = 8765,
    flatten: bool = True,
    skill_subset: str | list[int] | None = None,
    **kwargs
) -> gym.Env:
    """
    Create a Minecraft HRL environment.
    
    Args:
        host: Mineflayer bot host
        port: Mineflayer bot WebSocket port
        flatten: If True, return flattened observation space
        **kwargs: Additional arguments for MinecraftHRLEnv
        
    Returns:
        Gymnasium environment
    """
    env = MinecraftHRLEnv(host=host, port=port, **kwargs)
    
    if flatten:
        env = FlatMinecraftEnv(env)

    if skill_subset:
        ids = CORE_SKILL_IDS if skill_subset == "core" else list(skill_subset)
        env = SkillSubsetActionWrapper(env, ids)
    
    return env
