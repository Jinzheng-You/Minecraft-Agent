"""
Lightweight Gymnasium simulation for Minecraft HRL skill training.

This environment keeps the existing Mineflayer skill IDs, but trains over a
smaller high-value subset of 10-20 skills by default. It is intentionally
abstract: each action is a temporally extended Minecraft skill such as
harvest_wood, craft_wooden_pickaxe, mine_stone, or mine_diamond.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import gymnasium as gym
import numpy as np
from gymnasium import spaces


CORE_SKILL_IDS: List[int] = [
    1,   # harvest_wood
    3,   # craft_planks
    4,   # craft_sticks
    5,   # craft_crafting_table
    10,  # place_crafting_table
    6,   # craft_wooden_pickaxe
    2,   # mine_stone
    7,   # craft_stone_pickaxe
    13,  # craft_furnace
    11,  # mine_iron
    12,  # smelt_iron
    14,  # craft_iron_pickaxe
    19,  # dig_to_diamond_level
    21,  # mine_diamond
    22,  # craft_diamond_pickaxe
    8,   # eat_food
    9,   # explore
    27,  # clear_junk
]


SKILL_NAMES: Dict[int, str] = {
    0: "idle",
    1: "harvest_wood",
    2: "mine_stone",
    3: "craft_planks",
    4: "craft_sticks",
    5: "craft_crafting_table",
    6: "craft_wooden_pickaxe",
    7: "craft_stone_pickaxe",
    8: "eat_food",
    9: "explore",
    10: "place_crafting_table",
    11: "mine_iron",
    12: "smelt_iron",
    13: "craft_furnace",
    14: "craft_iron_pickaxe",
    15: "craft_iron_helmet",
    16: "craft_iron_chestplate",
    17: "craft_iron_leggings",
    18: "craft_iron_boots",
    19: "dig_to_diamond_level",
    20: "return_to_surface",
    21: "mine_diamond",
    22: "craft_diamond_pickaxe",
    23: "craft_diamond_helmet",
    24: "craft_diamond_chestplate",
    25: "craft_diamond_leggings",
    26: "craft_diamond_boots",
    27: "clear_junk",
}


TASKS = ["wood", "wooden_pickaxe", "stone_pickaxe", "iron_pickaxe", "diamond_pickaxe"]
TASK_TO_INDEX = {name: idx for idx, name in enumerate(TASKS)}

TASK_RELEVANT_SKILLS = {
    "wood": {1, 8, 9, 27},
    "wooden_pickaxe": {1, 3, 4, 5, 6, 8, 9, 10, 27},
    "stone_pickaxe": {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 27},
    "iron_pickaxe": {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 27},
    "diamond_pickaxe": {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 19, 21, 22, 27},
}


@dataclass
class SimConfig:
    max_steps: int = 80
    difficulty: str = "normal"
    task: str = "mixed"
    seed: int = 42


class SimMinecraftHRLEnv(gym.Env):
    """Fast skill-level simulator for staged Minecraft resource training."""

    metadata = {"render_modes": ["human"]}

    INV_KEYS = [
        "logs",
        "planks",
        "sticks",
        "crafting_table",
        "placed_table",
        "wooden_pickaxe",
        "cobblestone",
        "stone_pickaxe",
        "furnace",
        "raw_iron",
        "coal",
        "iron_ingot",
        "iron_pickaxe",
        "diamond",
        "diamond_pickaxe",
        "food",
        "junk",
    ]

    def __init__(
        self,
        task: str = "mixed",
        difficulty: str = "normal",
        max_steps: int = 80,
        seed: int = 42,
        action_ids: Optional[List[int]] = None,
    ):
        super().__init__()
        self.config = SimConfig(max_steps=max_steps, difficulty=difficulty, task=task, seed=seed)
        self.action_ids = list(action_ids or CORE_SKILL_IDS)
        self.action_space = spaces.Discrete(len(self.action_ids))
        obs_dim = 6 + len(self.INV_KEYS) + 6 + len(TASKS) + len(self.action_ids)
        self.observation_space = spaces.Box(low=0.0, high=1.0, shape=(obs_dim,), dtype=np.float32)
        self.rng = np.random.default_rng(seed)
        self.inv: Dict[str, int] = {}
        self.resources: Dict[str, int | bool] = {}
        self.task = "wood"
        self.steps = 0
        self.invalid_actions = 0
        self.health = 20.0
        self.food = 20.0
        self.y_level = 64
        self.time_of_day = 1000
        self.done_reason = "running"
        self.last_stage_score = 0

    @property
    def state_dim(self) -> int:
        return int(self.observation_space.shape[0])

    @property
    def action_dim(self) -> int:
        return int(self.action_space.n)

    def get_skill_name(self, compact_action: int) -> str:
        if compact_action < 0 or compact_action >= len(self.action_ids):
            return "invalid"
        return SKILL_NAMES.get(self.action_ids[compact_action], f"skill_{self.action_ids[compact_action]}")

    def original_skill_id(self, compact_action: int) -> int:
        return self.action_ids[int(compact_action)]

    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None) -> Tuple[np.ndarray, dict]:
        super().reset(seed=seed)
        if seed is not None:
            self.rng = np.random.default_rng(seed)

        requested_task = (options or {}).get("task") or self.config.task
        self.task = str(self.rng.choice(TASKS)) if requested_task == "mixed" else requested_task
        if self.task not in TASK_TO_INDEX:
            self.task = "wood"

        self.steps = 0
        self.invalid_actions = 0
        self.health = 20.0
        self.food = 18.0 if self.config.difficulty == "hard" else 20.0
        self.y_level = 64
        self.time_of_day = int(self.rng.integers(0, 3000))
        self.done_reason = "running"
        self.inv = {key: 0 for key in self.INV_KEYS}
        self.inv["food"] = int(self.rng.integers(0, 2))
        self.resources = {
            "wood_near": int(self.rng.integers(2, 7)),
            "stone_near": int(self.rng.integers(2, 7)),
            "iron_near": int(self.rng.integers(0, 4)),
            "coal_near": int(self.rng.integers(0, 3)),
            "diamond_near": 0,
            "at_diamond_level": False,
        }
        if self.config.difficulty == "hard":
            self.resources["wood_near"] = max(1, int(self.resources["wood_near"]) - 1)
            self.resources["iron_near"] = max(0, int(self.resources["iron_near"]) - 1)

        self.last_stage_score = self._task_progress_score()
        return self._obs(), self._info(False)

    def step(self, action: int) -> Tuple[np.ndarray, float, bool, bool, dict]:
        self.steps += 1
        self.time_of_day = (self.time_of_day + 450) % 24000
        self.food = max(0.0, self.food - (0.10 if self.config.difficulty != "hard" else 0.16))

        skill_id = self.original_skill_id(int(action))
        reward, valid = self._execute_skill(skill_id)
        if not valid:
            self.invalid_actions += 1
            reward -= 2.0
        elif skill_id not in TASK_RELEVANT_SKILLS.get(self.task, set()):
            reward = reward * 0.15 - 1.5

        if self.food <= 0:
            self.health -= 0.35 if self.config.difficulty != "hard" else 0.55
        if self._is_night() and self.config.difficulty == "hard":
            self.health -= 0.08

        new_stage = self._task_progress_score()
        if new_stage > self.last_stage_score:
            reward += float(new_stage - self.last_stage_score) * 3.0
        elif new_stage < self.last_stage_score:
            reward -= 0.5
        self.last_stage_score = new_stage

        success = self._task_success()
        terminated = bool(success or self.health <= 0)
        truncated = self.steps >= self.config.max_steps and not terminated
        if success:
            reward += 60.0
            self.done_reason = "task_complete"
        elif self.health <= 0:
            reward -= 20.0
            self.done_reason = "dead"
        elif truncated:
            reward -= 30.0
            self.done_reason = "timeout"

        reward -= 0.15
        return self._obs(), float(reward), terminated, truncated, self._info(success)

    def valid_action_mask(self) -> np.ndarray:
        return np.array([1 if self._precondition(skill_id) else 0 for skill_id in self.action_ids], dtype=np.float32)

    def _execute_skill(self, skill_id: int) -> Tuple[float, bool]:
        if not self._precondition(skill_id):
            return -0.2, False

        if skill_id == 1:
            gain = min(int(self.resources["wood_near"]), int(self.rng.integers(1, 3)))
            self.inv["logs"] += gain
            self.resources["wood_near"] = max(0, int(self.resources["wood_near"]) - gain)
            return 1.5 * gain, True
        if skill_id == 3:
            logs = min(self.inv["logs"], 2)
            self.inv["logs"] -= logs
            self.inv["planks"] += logs * 4
            return 1.0 + logs * 0.4, True
        if skill_id == 4:
            self.inv["planks"] -= 2
            self.inv["sticks"] += 4
            return 1.0, True
        if skill_id == 5:
            self.inv["planks"] -= 4
            self.inv["crafting_table"] += 1
            return 2.0, True
        if skill_id == 10:
            self.inv["crafting_table"] -= 1
            self.inv["placed_table"] = 1
            return 1.5, True
        if skill_id == 6:
            self.inv["planks"] -= 3
            self.inv["sticks"] -= 2
            self.inv["wooden_pickaxe"] = 1
            return 4.0, True
        if skill_id == 2:
            mined = min(int(self.resources["stone_near"]), 3)
            self.inv["cobblestone"] += mined
            self.resources["stone_near"] = max(0, int(self.resources["stone_near"]) - mined)
            self.inv["junk"] += 1
            return 1.6 * mined, True
        if skill_id == 7:
            self.inv["cobblestone"] -= 3
            self.inv["sticks"] -= 2
            self.inv["stone_pickaxe"] = 1
            return 5.0, True
        if skill_id == 13:
            self.inv["cobblestone"] -= 8
            self.inv["furnace"] = 1
            return 4.0, True
        if skill_id == 11:
            mined = min(max(1, int(self.resources["iron_near"])), 3)
            self.inv["raw_iron"] += mined
            self.resources["iron_near"] = max(0, int(self.resources["iron_near"]) - mined)
            if int(self.resources["coal_near"]) > 0:
                self.inv["coal"] += 1
                self.resources["coal_near"] = int(self.resources["coal_near"]) - 1
            return 3.0 * mined, True
        if skill_id == 12:
            amount = min(self.inv["raw_iron"], 3)
            self.inv["raw_iron"] -= amount
            self.inv["iron_ingot"] += amount
            if self.inv["coal"] > 0:
                self.inv["coal"] -= 1
            else:
                self.inv["planks"] = max(0, self.inv["planks"] - 2)
            return 3.0 * amount, True
        if skill_id == 14:
            self.inv["iron_ingot"] -= 3
            self.inv["sticks"] -= 2
            self.inv["iron_pickaxe"] = 1
            return 8.0, True
        if skill_id == 19:
            self.y_level = -59
            self.resources["at_diamond_level"] = True
            self.resources["diamond_near"] = max(1, int(self.rng.integers(1, 5)))
            return 6.0, True
        if skill_id == 21:
            mined = min(int(self.resources["diamond_near"]), 3)
            self.inv["diamond"] += mined
            self.resources["diamond_near"] = max(0, int(self.resources["diamond_near"]) - mined)
            return 7.0 * mined, True
        if skill_id == 22:
            self.inv["diamond"] -= 3
            self.inv["sticks"] -= 2
            self.inv["diamond_pickaxe"] = 1
            return 12.0, True
        if skill_id == 8:
            self.inv["food"] -= 1
            self.food = min(20.0, self.food + 7.0)
            return 2.0, True
        if skill_id == 9:
            before = dict(self.resources)
            self.resources["wood_near"] += int(self.rng.integers(0, 4))
            self.resources["stone_near"] += int(self.rng.integers(0, 4))
            self.resources["iron_near"] += int(self.rng.integers(0, 3))
            self.resources["coal_near"] += int(self.rng.integers(0, 2))
            if bool(self.resources["at_diamond_level"]):
                self.resources["diamond_near"] += int(self.rng.integers(0, 4))
            self.inv["food"] += int(self.rng.random() < 0.25)
            useful_gain = 0
            if self._needs_wood() and int(before["wood_near"]) <= 0:
                useful_gain += int(self.resources["wood_near"])
            if self._needs_stone() and int(before["stone_near"]) <= 0:
                useful_gain += int(self.resources["stone_near"])
            if self._needs_iron() and int(before["iron_near"]) <= 0:
                useful_gain += int(self.resources["iron_near"])
            if self._needs_fuel() and int(before["coal_near"]) <= 0:
                useful_gain += int(self.resources["coal_near"])
            if self._needs_diamond() and int(before["diamond_near"]) <= 0:
                useful_gain += int(self.resources["diamond_near"])
            return 0.2 + min(3.0, useful_gain * 0.5), True
        if skill_id == 27:
            cleared = self.inv["junk"]
            self.inv["junk"] = 0
            return 0.5 + 0.1 * cleared, True
        return -0.1, False

    def _precondition(self, skill_id: int) -> bool:
        if skill_id == 1:
            return int(self.resources["wood_near"]) > 0
        if skill_id == 3:
            return self.inv["logs"] > 0 and self.inv["planks"] < 32
        if skill_id == 4:
            return self.inv["planks"] >= 2 and self.inv["sticks"] < 16
        if skill_id == 5:
            return self.inv["planks"] >= 4 and self.inv["crafting_table"] + self.inv["placed_table"] < 1
        if skill_id == 10:
            return self.inv["crafting_table"] > 0 and self.inv["placed_table"] < 1
        if skill_id == 6:
            return self.inv["placed_table"] > 0 and self.inv["planks"] >= 3 and self.inv["sticks"] >= 2 and self.inv["wooden_pickaxe"] < 1
        if skill_id == 2:
            return self.inv["wooden_pickaxe"] > 0 and int(self.resources["stone_near"]) > 0
        if skill_id == 7:
            return self.inv["placed_table"] > 0 and self.inv["cobblestone"] >= 3 and self.inv["sticks"] >= 2 and self.inv["stone_pickaxe"] < 1
        if skill_id == 13:
            return self.inv["placed_table"] > 0 and self.inv["cobblestone"] >= 8 and self.inv["furnace"] < 1
        if skill_id == 11:
            return self.inv["stone_pickaxe"] + self.inv["iron_pickaxe"] > 0 and int(self.resources["iron_near"]) > 0
        if skill_id == 12:
            return self.inv["furnace"] > 0 and self.inv["raw_iron"] > 0 and (self.inv["coal"] > 0 or self.inv["planks"] >= 2)
        if skill_id == 14:
            return self.inv["placed_table"] > 0 and self.inv["iron_ingot"] >= 3 and self.inv["sticks"] >= 2 and self.inv["iron_pickaxe"] < 1
        if skill_id == 19:
            return self.inv["iron_pickaxe"] > 0 and self.y_level > -50
        if skill_id == 21:
            return self.inv["iron_pickaxe"] > 0 and bool(self.resources["at_diamond_level"]) and int(self.resources["diamond_near"]) > 0
        if skill_id == 22:
            return self.inv["placed_table"] > 0 and self.inv["diamond"] >= 3 and self.inv["sticks"] >= 2 and self.inv["diamond_pickaxe"] < 1
        if skill_id == 8:
            return self.inv["food"] > 0 and self.food < 18
        if skill_id == 9:
            return self._needs_exploration()
        if skill_id == 27:
            return self.inv["junk"] > 0
        return False

    def _needs_wood(self) -> bool:
        wood_units = self.inv["logs"] + self.inv["planks"] // 4
        if self.task == "wood":
            return wood_units < 4
        if self.inv["wooden_pickaxe"] <= 0:
            return self.inv["logs"] <= 0 and self.inv["planks"] < 7
        if self.task in {"iron_pickaxe", "diamond_pickaxe"}:
            needs_tool_sticks = (
                (self.inv["iron_ingot"] >= 3 and self.inv["iron_pickaxe"] <= 0) or
                (self.inv["diamond"] >= 3 and self.inv["diamond_pickaxe"] <= 0)
            )
            if needs_tool_sticks and self.inv["sticks"] < 2:
                return self.inv["logs"] <= 0 and self.inv["planks"] < 2
        if self.task in {"iron_pickaxe", "diamond_pickaxe"} and self.inv["furnace"] <= 0:
            return self.inv["planks"] < 2 and self.inv["logs"] <= 0 and self.inv["coal"] <= 0
        return False

    def _needs_stone(self) -> bool:
        if self.task not in {"stone_pickaxe", "iron_pickaxe", "diamond_pickaxe"}:
            return False
        if self.inv["stone_pickaxe"] <= 0:
            return self.inv["wooden_pickaxe"] > 0 and self.inv["cobblestone"] < 3
        if self.task in {"iron_pickaxe", "diamond_pickaxe"} and self.inv["furnace"] <= 0:
            return self.inv["cobblestone"] < 8
        return False

    def _needs_iron(self) -> bool:
        if self.task not in {"iron_pickaxe", "diamond_pickaxe"}:
            return False
        return self.inv["stone_pickaxe"] + self.inv["iron_pickaxe"] > 0 and self.inv["iron_ingot"] + self.inv["raw_iron"] < 3

    def _needs_fuel(self) -> bool:
        if self.task not in {"iron_pickaxe", "diamond_pickaxe"}:
            return False
        return self.inv["raw_iron"] > 0 and self.inv["coal"] <= 0 and self.inv["planks"] < 2

    def _needs_diamond(self) -> bool:
        if self.task != "diamond_pickaxe":
            return False
        return self.inv["iron_pickaxe"] > 0 and bool(self.resources["at_diamond_level"]) and self.inv["diamond"] < 3

    def _needs_exploration(self) -> bool:
        if self._needs_wood() and int(self.resources["wood_near"]) <= 0:
            return True
        if self._needs_stone() and int(self.resources["stone_near"]) <= 0:
            return True
        if self._needs_iron() and int(self.resources["iron_near"]) <= 0:
            return True
        if self._needs_fuel() and int(self.resources["coal_near"]) <= 0:
            return True
        if self._needs_diamond() and int(self.resources["diamond_near"]) <= 0:
            return True
        return self.inv["food"] <= 0 and self.food < 10

    def _task_success(self) -> bool:
        if self.task == "wood":
            return self.inv["logs"] + self.inv["planks"] // 4 >= 4
        if self.task == "wooden_pickaxe":
            return self.inv["wooden_pickaxe"] > 0
        if self.task == "stone_pickaxe":
            return self.inv["stone_pickaxe"] > 0
        if self.task == "iron_pickaxe":
            return self.inv["iron_pickaxe"] > 0
        if self.task == "diamond_pickaxe":
            return self.inv["diamond_pickaxe"] > 0
        return False

    def _stage_score(self) -> int:
        score = 0
        score += int(self.inv["logs"] > 0 or self.inv["planks"] > 0)
        score += int(self.inv["sticks"] > 0)
        score += int(self.inv["placed_table"] > 0)
        score += int(self.inv["wooden_pickaxe"] > 0)
        score += int(self.inv["cobblestone"] >= 3)
        score += int(self.inv["stone_pickaxe"] > 0)
        score += int(self.inv["furnace"] > 0)
        score += int(self.inv["raw_iron"] > 0)
        score += int(self.inv["iron_ingot"] >= 3)
        score += int(self.inv["iron_pickaxe"] > 0)
        score += int(bool(self.resources["at_diamond_level"]))
        score += int(self.inv["diamond"] >= 3)
        score += int(self.inv["diamond_pickaxe"] > 0)
        return score

    def _task_progress_score(self) -> int:
        wood_units = self.inv["logs"] + self.inv["planks"] // 4
        score = min(4, wood_units)
        if self.task == "wood":
            return score

        score += int(self.inv["planks"] >= 3)
        score += int(self.inv["sticks"] >= 2)
        score += int(self.inv["placed_table"] > 0)
        score += int(self.inv["wooden_pickaxe"] > 0)
        if self.task == "wooden_pickaxe":
            return score

        score += int(self.inv["cobblestone"] >= 3)
        score += int(self.inv["stone_pickaxe"] > 0)
        if self.task == "stone_pickaxe":
            return score

        score += int(self.inv["furnace"] > 0)
        score += int(self.inv["raw_iron"] > 0)
        score += int(self.inv["iron_ingot"] >= 3)
        score += int(self.inv["iron_pickaxe"] > 0)
        if self.task == "iron_pickaxe":
            return score

        score += int(bool(self.resources["at_diamond_level"]))
        score += int(self.inv["diamond"] >= 3)
        score += int(self.inv["diamond_pickaxe"] > 0)
        return score

    def _is_night(self) -> bool:
        return 12542 <= self.time_of_day <= 23459

    def _obs(self) -> np.ndarray:
        inv_vec = np.array([min(self.inv[key], 64) / 64.0 for key in self.INV_KEYS], dtype=np.float32)
        resource_vec = np.array(
            [
                min(int(self.resources["wood_near"]), 16) / 16.0,
                min(int(self.resources["stone_near"]), 16) / 16.0,
                min(int(self.resources["iron_near"]), 16) / 16.0,
                min(int(self.resources["coal_near"]), 8) / 8.0,
                min(int(self.resources["diamond_near"]), 8) / 8.0,
                1.0 if self.resources["at_diamond_level"] else 0.0,
            ],
            dtype=np.float32,
        )
        task_vec = np.zeros(len(TASKS), dtype=np.float32)
        task_vec[TASK_TO_INDEX[self.task]] = 1.0
        misc = np.array(
            [
                self.health / 20.0,
                self.food / 20.0,
                np.clip((self.y_level + 64) / 128.0, 0.0, 1.0),
                self.time_of_day / 24000.0,
                1.0 if self._is_night() else 0.0,
                self.steps / float(self.config.max_steps),
            ],
            dtype=np.float32,
        )
        mask = self.valid_action_mask().astype(np.float32)
        obs = np.concatenate([misc, inv_vec, resource_vec, task_vec, mask]).astype(np.float32)
        if obs.shape[0] != self.observation_space.shape[0]:
            raise RuntimeError(f"Observation shape mismatch: {obs.shape[0]} != {self.observation_space.shape[0]}")
        return obs

    def _info(self, success: bool) -> dict:
        return {
            "task": self.task,
            "success": bool(success),
            "invalid_actions": int(self.invalid_actions),
            "steps": int(self.steps),
            "done_reason": self.done_reason,
            "stage_score": int(self.last_stage_score),
            "skill_subset": [SKILL_NAMES.get(skill_id, str(skill_id)) for skill_id in self.action_ids],
        }
