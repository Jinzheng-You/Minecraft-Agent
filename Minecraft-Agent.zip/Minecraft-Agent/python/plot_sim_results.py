#!/usr/bin/env python3
"""Plot training curves for the simulated HRL Double DQN run."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def rolling(series: pd.Series, window: int = 50) -> pd.Series:
    return series.rolling(window=window, min_periods=1).mean()


def save_curve(df: pd.DataFrame, x: str, y: str, out_path: Path, ylabel: str, window: int = 50) -> None:
    plt.figure(figsize=(8, 4.5))
    plt.plot(df[x], df[y], alpha=0.28, label=y)
    plt.plot(df[x], rolling(df[y], window), linewidth=2.0, label=f"{window}-episode mean")
    plt.xlabel("Episode")
    plt.ylabel(ylabel)
    plt.grid(alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()


def plot_metrics(metrics_csv: str | Path, out_dir: str | Path, window: int = 50) -> None:
    metrics_csv = Path(metrics_csv)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(metrics_csv)
    if df.empty:
        return

    save_curve(df, "episode", "reward", out_dir / "reward_curve.png", "Episode reward", window)
    save_curve(df, "episode", "success", out_dir / "success_rate_curve.png", "Success", window)
    save_curve(df, "episode", "steps", out_dir / "episode_steps_curve.png", "Episode steps", window)
    save_curve(df, "episode", "invalid_actions", out_dir / "invalid_actions_curve.png", "Invalid actions", window)

    fig, axes = plt.subplots(2, 2, figsize=(11, 7))
    plots = [
        ("reward", "Reward"),
        ("success", "Success"),
        ("steps", "Steps"),
        ("invalid_actions", "Invalid actions"),
    ]
    for ax, (col, title) in zip(axes.flat, plots):
        ax.plot(df["episode"], df[col], alpha=0.25)
        ax.plot(df["episode"], rolling(df[col], window), linewidth=2)
        ax.set_title(title)
        ax.set_xlabel("Episode")
        ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(out_dir / "training_overview.png", dpi=150)
    plt.close(fig)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--metrics", default=str(Path(__file__).resolve().parent / "results" / "sim_ddqn" / "metrics.csv"))
    p.add_argument("--out-dir", default=str(Path(__file__).resolve().parent / "results" / "sim_ddqn"))
    p.add_argument("--window", type=int, default=50)
    args = p.parse_args()
    plot_metrics(args.metrics, args.out_dir, args.window)
    print(f"Saved plots to {args.out_dir}")


if __name__ == "__main__":
    main()
