#!/usr/bin/env python3
"""Run a trained HRL model against a live Mineflayer bridge for observation."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from agent import HRLAgent
from env import make_minecraft_env


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", required=True, help="Checkpoint directory containing policy.zip")
    p.add_argument("--host", default="localhost")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--policy", default="DQN", choices=["DQN", "PPO"])
    p.add_argument("--mode", default="pure_rl", choices=["pure_rl", "hybrid", "heuristic"])
    p.add_argument("--skill-subset", default="core", choices=["core", "none"])
    p.add_argument("--task", default=None, help="Task label sent to bridge, e.g. wood, iron_pickaxe, diamond")
    p.add_argument("--steps", type=int, default=300)
    p.add_argument("--hard-reset", action="store_true")
    p.add_argument("--device", default="auto")
    return p.parse_args()


def send_bridge(env, payload: dict) -> None:
    base = env.unwrapped
    if hasattr(base, "_send_and_receive"):
        response = base._send_and_receive(payload)
        print(response)


def main() -> None:
    args = parse_args()
    subset = None if args.skill_subset == "none" else args.skill_subset
    env = make_minecraft_env(
        host=args.host,
        port=args.port,
        flatten=True,
        hard_reset=args.hard_reset,
        skill_subset=subset,
        render_mode="human",
    )
    if not env.connect(timeout=30):
        raise RuntimeError("Could not connect to Mineflayer bridge")

    if args.task:
        send_bridge(env, {"type": "set_task", "task": args.task})

    agent = HRLAgent(env=env, mode=args.mode, policy_type=args.policy, device=args.device)
    agent.load(args.checkpoint)

    obs, info = env.reset()
    total_reward = 0.0
    for step in range(args.steps):
        action = agent.select_action(obs, deterministic=True)
        skill_name = env.get_skill_name(action) if hasattr(env, "get_skill_name") else str(action)
        print(f"Step {step:04d}: action={action} skill={skill_name}")
        obs, reward, terminated, truncated, info = env.step(action)
        total_reward += reward
        print(f"  reward={reward:.3f} total={total_reward:.3f} info={json.dumps({k: str(v) for k, v in info.items() if k != 'raw_state'}, ensure_ascii=False)}")
        if terminated or truncated:
            print("Episode ended; resetting.")
            obs, info = env.reset()
            total_reward = 0.0
    env.close()


if __name__ == "__main__":
    main()
