/**
 * Minecraft Agent - Mineflayer Entry Point
 * 
 * This is the main entry point for the Minecraft bot. It:
 * 1. Creates and configures the Mineflayer bot
 * 2. Loads necessary plugins (pathfinder, tool, etc.)
 * 3. Initializes the SkillManager
 * 4. Starts the Bridge server for Python communication
 * 
 * Usage:
 *   node src/index.js [--host <host>] [--port <port>] [--username <username>]
 * 
 * Environment Variables:
 *   MC_HOST - Minecraft server host (default: localhost)
 *   MC_PORT - Minecraft server port (default: 25565)
 *   MC_USERNAME - Bot username (default: DQN_bot)
 *   BRIDGE_PORT - WebSocket bridge port (default: 8765)
 *   VIEWER_PORT - Prismarine viewer HTTP port (default: 3007)
 *   SPAWN_STABILIZE - Disable bot physics briefly after spawn (default: 0)
 *   START_PHYSICS_DISABLED - Keep Mineflayer physics off until a task starts (default: 0)
 *   ENABLE_PHYSICS_ON_TASK - Re-enable physics automatically when a task starts (default: 0)
 *   SAFE_SPAWN_CHECK - Let bot move itself away from water/void after spawn (default: 0)
 */

const mineflayer = require('mineflayer');
const { pathfinder } = require('mineflayer-pathfinder');
const toolPlugin = require('mineflayer-tool').plugin;
const collectBlock = require('mineflayer-collectblock').plugin;

const SkillManager = require('./skillManager');
const Bridge = require('./bridge');

// Configuration
const config = {
    host: process.env.MC_HOST || 'localhost',
    port: parseInt(process.env.MC_PORT) || 25565,
    username: process.env.MC_USERNAME || 'DQN_bot',
    bridgePort: parseInt(process.env.BRIDGE_PORT) || 8765,
    viewerPort: parseInt(process.env.VIEWER_PORT) || 3007,
    enableViewer: process.env.ENABLE_VIEWER === '1',
    spawnStabilize: process.env.SPAWN_STABILIZE === '1',
    startPhysicsDisabled: process.env.START_PHYSICS_DISABLED === '1',
    enablePhysicsOnTask: process.env.ENABLE_PHYSICS_ON_TASK === '1',
    safeSpawnCheck: process.env.SAFE_SPAWN_CHECK === '1',
    version: process.env.MC_VERSION || '1.20.1'  // Specify version for stability
};

console.log('='.repeat(60));
console.log('Minecraft Hierarchical RL Agent');
console.log('='.repeat(60));
console.log(`Configuration:`);
console.log(`  Server: ${config.host}:${config.port}`);
console.log(`  Username: ${config.username}`);
console.log(`  Bridge Port: ${config.bridgePort}`);
console.log(`  Viewer: ${config.enableViewer ? `enabled on ${config.viewerPort}` : 'disabled'}`);
console.log(`  MC Version: ${config.version}`);
console.log(`  Spawn Stabilize: ${config.spawnStabilize ? 'enabled' : 'disabled'}`);
console.log(`  Start Physics Disabled: ${config.startPhysicsDisabled ? 'enabled' : 'disabled'}`);
console.log(`  Enable Physics On Task: ${config.enablePhysicsOnTask ? 'enabled' : 'disabled'}`);
console.log(`  Safe Spawn Check: ${config.safeSpawnCheck ? 'enabled' : 'disabled'}`);
console.log('='.repeat(60));

// Create the bot
const bot = mineflayer.createBot({
    host: config.host,
    port: config.port,
    username: config.username,
    version: config.version,
    auth: 'offline',  // For local servers without auth
    physicsEnabled: !(config.spawnStabilize || config.startPhysicsDisabled),
    maxCatchupTicks: 1
});

// Global references
let skillManager = null;
let bridge = null;
let demoPaused = false;
const PICKAXE_TIERS = ['wooden', 'stone', 'iron', 'diamond', 'netherite'];
const TOOL_SAFETY_USES = 8;
const TIMEOUT_MULTIPLIER = Math.max(1, Number(process.env.TIMEOUT_MULTIPLIER || 3));

const TASK_SKILL_SEQUENCES = {
    wood: [1],
    wooden_pickaxe: [1, 3, 4, 5, 10, 6],
    stone_pickaxe: [1, 3, 4, 5, 10, 6, 2, 7],
    // After crafting a stone pickaxe, the first 3 cobble have been spent.
    // Mine stone several more times so furnace crafting has its 8 cobble input.
    iron_pickaxe: [1, 3, 4, 5, 10, 6, 2, 7, 2, 2, 2, 13, 11, 12, 14],
    diamond: [1, 3, 4, 5, 10, 6, 2, 7, 2, 2, 2, 13, 11, 12, 14, 19, 21],
    diamond_pickaxe: [1, 3, 4, 5, 10, 6, 2, 7, 2, 2, 2, 13, 11, 12, 14, 19, 21, 22]
};

function describeSurroundings() {
    if (!bot.entity) return 'entity=not_ready';
    const pos = bot.entity.position;
    const feet = bot.blockAt(pos);
    const head = bot.blockAt(pos.offset(0, 1, 0));
    const below = bot.blockAt(pos.offset(0, -1, 0));
    const nearbyHostiles = Object.values(bot.entities || {})
        .filter(e => e.type === 'mob' && e.position && e.position.distanceTo(pos) <= 8)
        .slice(0, 5)
        .map(e => `${e.name || e.mobType || 'mob'}@${e.position.distanceTo(pos).toFixed(1)}`)
        .join(', ') || 'none';
    return [
        `pos=${pos.x.toFixed(1)},${pos.y.toFixed(1)},${pos.z.toFixed(1)}`,
        `feet=${feet?.name || 'unknown'}`,
        `head=${head?.name || 'unknown'}`,
        `below=${below?.name || 'unknown'}`,
        `health=${bot.health}`,
        `food=${bot.food}`,
        `oxygen=${bot.oxygenLevel}`,
        `near_mobs=${nearbyHostiles}`
    ].join(' ');
}

function countItem(itemName) {
    return bot.inventory.items()
        .filter(i => i.name === itemName)
        .reduce((sum, i) => sum + i.count, 0);
}

function countItemLike(pattern) {
    return bot.inventory.items()
        .filter(i => i.name.includes(pattern))
        .reduce((sum, i) => sum + i.count, 0);
}

function countCobbleMaterials() {
    // Vanilla stone-tool/furnace equivalents: cobblestone, cobbled deepslate, blackstone.
    const names = new Set(['cobblestone', 'cobbled_deepslate', 'blackstone']);
    return bot.inventory.items()
        .filter(i => names.has(i.name))
        .reduce((sum, i) => sum + i.count, 0);
}

function countSmeltableIron() {
    const names = new Set(['raw_iron', 'iron_ore', 'deepslate_iron_ore']);
    return bot.inventory.items()
        .filter(i => names.has(i.name))
        .reduce((sum, i) => sum + i.count, 0);
}

function pickaxeTierIndex(itemOrTierName) {
    const name = String(itemOrTierName || '');
    const tier = PICKAXE_TIERS.find(t => name === t || name.startsWith(`${t}_pickaxe`));
    return PICKAXE_TIERS.indexOf(tier);
}

function toolMaxDurability(item) {
    if (typeof item?.maxDurability === 'number') return item.maxDurability;
    try {
        const mcData = require('minecraft-data')(bot.version);
        return mcData.itemsByName[item.name]?.maxDurability ?? Number.POSITIVE_INFINITY;
    } catch (_) {
        return Number.POSITIVE_INFINITY;
    }
}

function toolRemainingUses(item) {
    const maxDurability = toolMaxDurability(item);
    if (!Number.isFinite(maxDurability) || maxDurability <= 0) return Number.POSITIVE_INFINITY;
    const nbtDamage = item?.nbt?.value?.Damage?.value;
    const used = typeof item?.durabilityUsed === 'number'
        ? item.durabilityUsed
        : (typeof nbtDamage === 'number' ? nbtDamage : 0);
    return Math.max(0, maxDurability - used);
}

function hasAnyPickaxeAtLeast(tier, minUses = 1) {
    const minTier = pickaxeTierIndex(tier);
    return bot.inventory.items().some(item =>
        item.name.endsWith('_pickaxe') &&
        pickaxeTierIndex(item.name) >= minTier &&
        toolRemainingUses(item) >= minUses
    );
}

function hasNearbyBlock(blockName, maxDistance = 32) {
    return bot.findBlock({ matching: b => b.name === blockName, maxDistance }) !== null;
}

function hasCraftingTableAccess() {
    return countItem('crafting_table') > 0 || hasNearbyBlock('crafting_table', 32);
}

function requiredStickCountForSequence(sequence = []) {
    if (sequence.some(id => [6, 7, 14, 22].includes(id))) return 8;
    if (sequence.includes(4)) return 2;
    return 0;
}

function requiredPlankCountForSequence(sequence = []) {
    let required = 0;

    if (!hasCraftingTableAccess() && sequence.some(id => [5, 10, 6, 7, 13, 14, 22].includes(id))) {
        required += 4;
    }

    const stickShortfall = Math.max(0, requiredStickCountForSequence(sequence) - countItem('stick'));
    required += Math.ceil(stickShortfall / 4) * 2;

    if (sequence.includes(6) && !hasAnyPickaxeAtLeast('wooden', TOOL_SAFETY_USES)) {
        required += 3;
    }

    return required;
}

function plankPotential() {
    return countItemLike('_planks') + countItemLike('_log') * 4;
}

function needsWoodSupplies(sequence = []) {
    return plankPotential() < requiredPlankCountForSequence(sequence);
}

function isLikelyUnderground() {
    if (!bot.entity) return false;
    const y = Math.floor(bot.entity.position.y);
    const feet = bot.blockAt(bot.entity.position);
    const head2 = bot.blockAt(bot.entity.position.offset(0, 2, 0));
    return y < 60 || (feet?.name !== 'air' && head2?.name !== 'air');
}

async function returnToSurfaceIfNeeded(reason = 'need surface resources') {
    if (!isLikelyUnderground()) return { success: true, message: 'Already near surface' };
    const surfaceSkill = skillManager?.skillRegistry.get(20);
    if (!surfaceSkill) return { success: false, message: 'return_to_surface skill unavailable' };

    bot.chat(`Need surface: ${reason}`);
    const result = await skillManager.executeSkill(20);
    bot.chat(`${result.success ? 'OK' : 'Failed'} surface: ${String(result.message).slice(0, 80)}`);
    return result;
}

async function recoverWoodAndRetry(skillId, taskName, sequence) {
    if (![1, 3, 4, 5, 6, 7, 14, 22].includes(skillId)) {
        return null;
    }

    if (countItemLike('_log') >= 1 || countItemLike('_planks') >= 12) {
        return null;
    }

    const surface = await returnToSurfaceIfNeeded('wood/logs required');
    if (!surface.success) return surface;

    const harvest = await skillManager.executeSkill(1);
    bot.chat(`${harvest.success ? 'OK' : 'Failed'} recovery harvest: ${String(harvest.message).slice(0, 70)}`);
    if (!harvest.success) return harvest;

    if (skillId === 1) return harvest;

    const retrySkill = skillManager.skillRegistry.get(skillId);
    if (!retrySkill) return { success: false, message: `retry skill ${skillId} unavailable` };
    const retry = await skillManager.executeSkill(skillId);
    bot.chat(`${retry.success ? 'OK' : 'Failed'} retry ${retrySkill.name}: ${String(retry.message).slice(0, 70)}`);
    return retry;
}

async function recoverIronAndRetry(skillId, taskName, sequence) {
    if (![11, 12, 14, 19, 21, 22].includes(skillId)) {
        return null;
    }
    if (hasAnyPickaxeAtLeast('iron', TOOL_SAFETY_USES)) {
        return null;
    }

    bot.chat('Need iron tool/materials: recovering iron chain.');
    const recoverySteps = [11, 12, 14];
    for (const recoveryId of recoverySteps) {
        const recoverySkill = skillManager.skillRegistry.get(recoveryId);
        const recoveryContext = { index: sequence.indexOf(recoveryId), sequence };
        if (isSkillAlreadySatisfied(recoveryId, taskName, recoveryContext)) {
            bot.chat(`Skip recovery ${recoveryId}: ${recoverySkill?.name || 'unknown'} already satisfied`);
            continue;
        }

        const result = await skillManager.executeSkill(recoveryId);
        bot.chat(`${result.success ? 'OK' : 'Failed'} recovery ${recoverySkill?.name || recoveryId}: ${String(result.message).slice(0, 70)}`);
        if (!result.success) return result;
    }

    const retrySkill = skillManager.skillRegistry.get(skillId);
    const retry = await skillManager.executeSkill(skillId);
    bot.chat(`${retry.success ? 'OK' : 'Failed'} retry ${retrySkill?.name || skillId}: ${String(retry.message).slice(0, 70)}`);
    return retry;
}

function isSkillAlreadySatisfied(skillId, taskName = '', context = {}) {
    const sequence = context.sequence || TASK_SKILL_SEQUENCES[taskName] || [];
    const stepIndex = Number.isInteger(context.index) ? context.index : -1;
    const craftStonePickaxeIndex = sequence.indexOf(7);
    const craftFurnaceIndex = sequence.indexOf(13);

    switch (skillId) {
        case 1:
            if (needsWoodSupplies(sequence)) {
                return false;
            }
            return taskName === 'wood'
                ? countItemLike('_log') >= 3
                : plankPotential() >= requiredPlankCountForSequence(sequence);
        case 2:
            if (['iron_pickaxe', 'diamond', 'diamond_pickaxe'].includes(taskName)) {
                if (stepIndex >= 0 && craftStonePickaxeIndex >= 0 && stepIndex < craftStonePickaxeIndex) {
                    return countCobbleMaterials() >= 3 || hasAnyPickaxeAtLeast('stone', TOOL_SAFETY_USES);
                }
                if (stepIndex >= 0 && craftFurnaceIndex >= 0 && stepIndex < craftFurnaceIndex) {
                    return countItem('furnace') > 0 || hasNearbyBlock('furnace', 32) || countCobbleMaterials() >= 8;
                }
                return countItem('furnace') > 0 || hasNearbyBlock('furnace', 32) || countCobbleMaterials() >= 8;
            }
            return countCobbleMaterials() >= 3 || hasAnyPickaxeAtLeast('stone', TOOL_SAFETY_USES);
        case 3:
            return countItemLike('_planks') >= requiredPlankCountForSequence(sequence);
        case 4:
            return countItem('stick') >= requiredStickCountForSequence(sequence);
        case 5:
            return countItem('crafting_table') > 0 || hasNearbyBlock('crafting_table', 32);
        case 6:
            return hasAnyPickaxeAtLeast('wooden', TOOL_SAFETY_USES);
        case 7:
            return hasAnyPickaxeAtLeast('stone', TOOL_SAFETY_USES);
        case 10:
            return hasNearbyBlock('crafting_table', 32);
        case 11:
            return countSmeltableIron() + countItem('iron_ingot') >= 3 || hasAnyPickaxeAtLeast('iron', TOOL_SAFETY_USES);
        case 12:
            return countItem('iron_ingot') >= 3 || hasAnyPickaxeAtLeast('iron', TOOL_SAFETY_USES);
        case 13:
            return countItem('furnace') > 0 || hasNearbyBlock('furnace', 32);
        case 14:
            return hasAnyPickaxeAtLeast('iron', TOOL_SAFETY_USES);
        case 19:
            return Math.floor(bot.entity.position.y) <= -50;
        case 21:
            return countItem('diamond') >= 3 || countItem('diamond_pickaxe') > 0;
        case 22:
            return countItem('diamond_pickaxe') > 0;
        default:
            return false;
    }
}

async function dropAllInventory() {
    const items = bot.inventory.items();
    if (items.length === 0) {
        bot.chat('Inventory is empty.');
        return;
    }

    let dropped = 0;
    for (const item of items) {
        try {
            await bot.tossStack(item);
            dropped += item.count;
            await new Promise(resolve => setTimeout(resolve, 150));
        } catch (err) {
            console.log(`[Bot] Failed to drop ${item.name}: ${err.message}`);
        }
    }
    bot.chat(`Dropped ${dropped} item(s).`);
}

async function runDemoTask(taskName) {
    if (!skillManager) {
        bot.chat('Skill manager is not ready.');
        return;
    }
    const sequence = TASK_SKILL_SEQUENCES[taskName];
    if (!sequence) {
        bot.chat(`Unknown task: ${taskName}`);
        return;
    }
    if (bridge) {
        bridge.currentTask = taskName;
        bridge.paused = false;
    }
    if (!bot.physicsEnabled) {
        if (!config.enablePhysicsOnTask) {
            const message = 'Physics is disabled. Restart with START_PHYSICS_DISABLED=0 for real task execution.';
            bot.chat(message);
            console.log(`[Bot] Refusing task ${taskName}: ${message}`);
            return;
        }
        bot.physicsEnabled = true;
        bot.chat('Physics enabled for task execution.');
        await new Promise(resolve => setTimeout(resolve, 500));
    }
    demoPaused = false;
    bot.chat(`Starting task ${taskName} (${sequence.length} skills).`);
    for (let stepIndex = 0; stepIndex < sequence.length; stepIndex++) {
        const skillId = sequence[stepIndex];
        if (demoPaused || bridge?.paused) {
            bot.chat(`Task ${taskName} paused.`);
            return;
        }
        const skill = skillManager.skillRegistry.get(skillId);
        const stepContext = { index: stepIndex, sequence };
        if (isSkillAlreadySatisfied(skillId, taskName, stepContext)) {
            bot.chat(`Skip ${skillId}: ${skill?.name || 'unknown'} already satisfied`);
            continue;
        }

        if (skillId === 1 && needsWoodSupplies(sequence) && isLikelyUnderground()) {
            const surface = await returnToSurfaceIfNeeded('wood/logs required before harvesting');
            if (!surface.success) return;
        }

        bot.chat(`Skill ${skillId}: ${skill?.name || 'unknown'}`);
        const result = await skillManager.executeSkill(skillId);
        bot.chat(`${result.success ? 'OK' : 'Failed'}: ${String(result.message).slice(0, 80)}`);
        if (!result.success) {
            if (String(result.message).startsWith('Preconditions not met') && isSkillAlreadySatisfied(skillId, taskName, stepContext)) {
                bot.chat(`Skip ${skillId}: satisfied after re-check`);
                continue;
            }
            if (String(result.message).startsWith('Preconditions not met')) {
                const recovery = await recoverWoodAndRetry(skillId, taskName, sequence);
                if (recovery?.success) continue;
                if (recovery) {
                    bot.chat(`Recovery failed: ${String(recovery.message).slice(0, 80)}`);
                }
            }
            const ironRecovery = await recoverIronAndRetry(skillId, taskName, sequence);
            if (ironRecovery?.success) continue;
            if (ironRecovery) {
                bot.chat(`Iron recovery failed: ${String(ironRecovery.message).slice(0, 80)}`);
            }
            return;
        }
    }
    bot.chat(`Task ${taskName} complete.`);
}

// Bot event handlers — use once() so bridge/viewer only start on first spawn
// (avoids EADDRINUSE crash if the bot dies and respawns during a training run)
bot.once('spawn', () => {
    console.log('[Bot] Spawned in world!');
    console.log(`[Bot] Position: ${bot.entity.position}`);
    console.log(`[Bot] Health: ${bot.health}, Food: ${bot.food}`);

    if (config.spawnStabilize) {
        bot.physicsEnabled = false;
        console.log('[Bot] Spawn stabilization: physics paused for 2.5s');
        setTimeout(() => {
            bot.physicsEnabled = true;
            console.log('[Bot] Spawn stabilization: physics enabled');
        }, 2500);
    }

    if (config.safeSpawnCheck) {
        // Safety check: if spawned in water or void, find dry ground within 64 blocks.
        // Disabled by default for real demos because automatic movement immediately
        // after joining can trigger invalid_player_movement on strict servers.
        setTimeout(async () => {
            try {
                const pos = bot.entity.position;
                const block = bot.blockAt(pos);
                const blockBelow = bot.blockAt(pos.offset(0, -1, 0));
                const inWater = block?.name?.includes('water') || blockBelow?.name?.includes('water');
                if (inWater || pos.y < 0) {
                    console.log(`[Bot] Unsafe spawn (${block?.name} at y=${pos.y.toFixed(1)}), searching for dry ground...`);
                    const safeBlock = bot.findBlock({
                        matching: b => b.name === 'grass_block' || b.name === 'dirt' || b.name === 'sand' || b.name === 'stone',
                        maxDistance: 64
                    });
                    if (safeBlock) {
                        const { Movements, goals } = require('mineflayer-pathfinder');
                        const mcData = require('minecraft-data')(bot.version);
                        const move = new Movements(bot, mcData);
                        move.canSwim = false;
                        bot.pathfinder.setMovements(move);
                        await bot.pathfinder.goto(new goals.GoalNear(safeBlock.position.x, safeBlock.position.y, safeBlock.position.z, 2));
                        console.log(`[Bot] Moved to safe ground at ${bot.entity.position}`);
                    } else {
                        console.log('[Bot] Could not find safe ground nearby — bot may be stuck in water');
                    }
                } else {
                    console.log(`[Bot] Spawn looks safe: ${block?.name} at y=${pos.y.toFixed(1)}`);
                }
            } catch (err) {
                console.error('[Bot] Safe-spawn check failed:', err.message);
            }
        }, 3000);
    } else {
        console.log('[Bot] Safe-spawn auto movement disabled');
    }

    // Initialize skill manager
    skillManager = new SkillManager(bot);
    console.log(`[Bot] Skill Manager initialized with ${skillManager.getActionSpaceSize()} skills`);

    // Start the bridge
    bridge = new Bridge(bot, skillManager, config.bridgePort);
    bridge.start();

    // Prismarine viewer is optional. It depends on native canvas builds on
    // Windows, so keep it off by default for stable coursework demos.
    if (config.enableViewer) {
        try {
            const { mineflayer: mineflayerViewer } = require('prismarine-viewer');
            mineflayerViewer(bot, { port: config.viewerPort, firstPerson: true });
            console.log(`[Viewer] Prismarine viewer started at http://localhost:${config.viewerPort}`);
            console.log(`[Viewer] Open this URL in your browser to watch the bot!`);
        } catch (err) {
            console.error('[Viewer] Failed to start prismarine viewer:', err.message);
            console.log('[Viewer] Bot will continue without viewer');
        }
    }

    console.log('[Bot] Ready for Python agent connection!');
});

bot.on('health', () => {
    // Log significant health changes
    if (bot.health <= 5) {
        console.log(`[Bot] WARNING: Low health! ${describeSurroundings()}`);
    }
});

bot.on('death', () => {
    console.log('[Bot] Died! Auto-respawning...');
    console.log(`[Bot] Death context: ${describeSurroundings()}`);
    setTimeout(() => {
        bot.respawn();
    }, 1000);
});

bot.on('kicked', (reason) => {
    console.log(`[Bot] Kicked: ${reason}`);
    const text = typeof reason === 'string' ? reason : JSON.stringify(reason);
    if (text.includes('invalid_player_movement')) {
        console.log('[Bot] Diagnosis: server rejected bot movement. This is usually caused by falling, being pushed/hit, pathing inside a tight tunnel, or server movement checks during mining.');
        console.log('[Bot] Tip: use src/runner.js for auto-restart; keep the bot on solid ground; avoid hitting it during tasks; for Paper servers consider allow-flight=true.');
    }
});

bot.on('error', (err) => {
    console.error('[Bot] Error:', err);
});

bot.on('end', () => {
    console.log('[Bot] Disconnected from server');
    if (bridge) {
        bridge.stop();
    }
    process.exit(0);
});

// Load plugins once bot is injected
bot.once('inject_allowed', () => {
    console.log('[Bot] Loading plugins...');
    bot.loadPlugin(pathfinder);
    bot.loadPlugin(toolPlugin);
    bot.loadPlugin(collectBlock);
    console.log('[Bot] Plugins loaded: pathfinder, tool, collectBlock');
    // Give pathfinder more time to compute paths (default ~5s is too short for
    // large search radii like the 64-block harvest_wood scan)
    bot.pathfinder.thinkTimeout = 15000 * TIMEOUT_MULTIPLIER;
});

// Chat commands for debugging (can be sent from Minecraft)
bot.on('chat', (username, message) => {
    if (username === bot.username) return;
    
    const args = message.split(' ');
    const command = args[0].toLowerCase();
    
    switch (command) {
        case '!skills':
            // List available skills
            const skills = skillManager?.getSkillList() || [];
            bot.chat(`Available skills: ${skills.length}`);
            skills.slice(0, 5).forEach(s => {
                bot.chat(`  ${s.id}: ${s.name} [${s.available ? 'OK' : 'NO'}]`);
            });
            break;
            
        case '!exec':
            // Execute a skill by ID
            const skillId = parseInt(args[1]);
            if (!isNaN(skillId) && skillManager) {
                skillManager.executeSkill(skillId).then(result => {
                    bot.chat(`Result: ${result.success ? 'Success' : 'Failed'} - ${result.message}`);
                });
            }
            break;
            
        case '!state':
            // Print current state summary
            if (bridge) {
                const state = bridge._getState();
                bot.chat(`Pos: ${state.position.x}, ${state.position.y}, ${state.position.z}`);
                bot.chat(`HP: ${state.health}, Food: ${state.food}`);
                bot.chat(`Items: ${Object.keys(state.inventory).length} types`);
            }
            break;
            
        case '!inventory':
            // List inventory
            const inv = bot.inventory.items();
            bot.chat(`Inventory (${inv.length} slots):`);
            inv.slice(0, 5).forEach(item => {
                bot.chat(`  ${item.name}: ${item.count}`);
            });
            break;

        case '!dropall':
            dropAllInventory().catch(err => {
                bot.chat(`Drop failed: ${err.message}`);
            });
            break;

        case '!where':
            bot.chat(describeSurroundings().slice(0, 240));
            console.log(`[Bot] Where: ${describeSurroundings()}`);
            break;
            
        case '!help':
            bot.chat('Commands: !skills, !exec <id>, !state, !where, !inventory, !dropall, !surface, !task <wood|wooden_pickaxe|iron_pickaxe|diamond>, !pause, !resume, !reset, !model <name>');
            break;

        case '!task':
            runDemoTask((args[1] || '').toLowerCase()).catch(err => {
                bot.chat(`Task failed: ${err.message}`);
            });
            break;

        case '!surface':
            returnToSurfaceIfNeeded('manual command').catch(err => {
                bot.chat(`Surface failed: ${err.message}`);
            });
            break;

        case '!pause':
            demoPaused = true;
            if (bridge) bridge.paused = true;
            try { bot.pathfinder.stop(); } catch (_) {}
            bot.chat('Paused.');
            break;

        case '!resume':
            demoPaused = false;
            if (bridge) bridge.paused = false;
            bot.chat('Resumed.');
            break;

        case '!reset':
            if (bridge) {
                bridge._handleTrainingReset({ type: 'training_reset' }).then(() => {
                    bot.chat('Training map reset complete.');
                }).catch(err => bot.chat(`Reset failed: ${err.message}`));
            }
            break;

        case '!model':
            if (bridge) {
                bridge.selectedModel = args[1] || 'default';
                bot.chat(`Selected model: ${bridge.selectedModel}`);
            }
            break;
    }
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n[Bot] Shutting down...');
    if (bridge) {
        bridge.stop();
    }
    bot.quit();
    process.exit(0);
});

process.on('uncaughtException', (err) => {
    console.error('[Bot] Uncaught exception:', err);
    try { if (bridge) bridge.stop(); } catch (_) {}
    try { bot.quit(); } catch (_) {}
    process.exit(1);
});

process.on('unhandledRejection', (err) => {
    console.error('[Bot] Unhandled rejection:', err);
    try { if (bridge) bridge.stop(); } catch (_) {}
    try { bot.quit(); } catch (_) {}
    process.exit(1);
});

console.log('[Bot] Connecting to server...');
