/**
 * SkillManager - Manages the Skill Library for Hierarchical RL
 * 
 * Following the Options Framework, each skill is a "temporally extended action"
 * with its own initiation set, termination condition, and internal policy.
 * 
 * Inspired by:
 * - Voyager: Code-as-action paradigm
 * - Plan4MC: Basic skills as atomic units for graph search
 * - DEPS: Error handling and retry logic
 */

const { goals, Movements } = require('mineflayer-pathfinder');
const { GoalNear, GoalBlock, GoalGetToBlock, GoalY } = goals;
const Vec3 = require('vec3');

const LOG_TYPES = [
    'oak_log', 'birch_log', 'spruce_log', 'jungle_log',
    'acacia_log', 'dark_oak_log', 'mangrove_log', 'cherry_log'
];

const LOG_TO_PLANKS = Object.fromEntries(
    LOG_TYPES.map(name => [name, name.replace('_log', '_planks')])
);

// Materials accepted by vanilla stone-tool/furnace recipes in modern MC.
// "cobbled_deepslate" is the item dropped by mining deepslate.
const COBBLE_MATERIALS = ['cobblestone', 'cobbled_deepslate', 'blackstone'];
const IRON_ORE_BLOCKS = ['iron_ore', 'deepslate_iron_ore'];
const SMELTABLE_IRON_ITEMS = ['raw_iron', 'iron_ore', 'deepslate_iron_ore'];
const DIAMOND_ORE_BLOCKS = ['diamond_ore', 'deepslate_diamond_ore'];
const PICKAXE_TIERS = ['wooden', 'stone', 'iron', 'diamond', 'netherite'];
const TOOL_SAFETY_USES = 8;
const RESERVED_STICKS_FOR_TOOLS = 2;
const RESERVED_PLANKS_FOR_TOOLS = 3;
const GRAVITY_BLOCKS = ['gravel', 'sand', 'red_sand', 'concrete_powder'];
const HAND_DIG_ALLOWED_BLOCKS = [
    'dirt', 'coarse_dirt', 'rooted_dirt', 'grass_block', 'podzol',
    ...LOG_TYPES
];
const ESCAPE_CLEARABLE_BLOCKS = [
    'dirt', 'coarse_dirt', 'rooted_dirt', 'grass_block', 'podzol',
    'mud', 'moss_block', 'snow', 'snow_block', 'vine', 'cave_vines',
    'short_grass', 'tall_grass', 'fern', 'large_fern',
    ...LOG_TYPES
];
const SAFE_CAVE_DROP_HEIGHT = Math.max(3, parseInt(process.env.SAFE_CAVE_DROP_HEIGHT || '4', 10));
const DIAMOND_SCAN_RADIUS = Math.max(8, parseInt(process.env.DIAMOND_SCAN_RADIUS || '18', 10));
const TIMEOUT_MULTIPLIER = Math.max(1, parseFloat(process.env.TIMEOUT_MULTIPLIER || '3'));
const COLLECT_CRAFTING_TABLE_AFTER_USE = process.env.COLLECT_CRAFTING_TABLE_AFTER_USE !== '0';

const RESOURCE_SEARCH_ATTEMPTS = Math.max(1, parseInt(process.env.RESOURCE_SEARCH_ATTEMPTS || '20', 10));
const RESOURCE_SEARCH_RADII = [48, 96, 144, 192];

class SkillManager {
    constructor(bot) {
        this.bot = bot;
        this.currentSkill = null;
        this.skillRegistry = new Map();
        this.executionHistory = [];
        
        // Register all available skills
        this._registerSkills();
    }

    /**
     * Register all primitive skills in the library
     * Each skill follows the Options Framework structure:
     * - id: Unique identifier (action space index)
     * - name: Human-readable name
     * - preconditions: Function checking if skill can be initiated
     * - execute: The skill's internal policy
     * - termination: Conditions for skill completion
     */
    _registerSkills() {
        // Skill 0: Idle / No-op
        this.register({
            id: 0,
            name: 'idle',
            description: 'Do nothing for one tick',
            preconditions: () => true,
            execute: async () => {
                await this._wait(50);
                return { success: true, message: 'Idle complete' };
            }
        });

        // Skill 1: Harvest nearest tree (punch wood)
        this.register({
            id: 1,
            name: 'harvest_wood',
            description: 'Find and harvest the nearest tree',
            preconditions: () => true, // Can always attempt
            execute: async () => {
                return await this._harvestWood(3);
            }
        });

        // Skill 2: Mine stone
        this.register({
            id: 2,
            name: 'mine_stone',
            description: 'Mine stone-like blocks for cobble/deepslate/blackstone materials',
            preconditions: () => this._hasUsablePickaxeAtLeast('wooden', 1) || this._canCraftWoodenPickaxe(),
            execute: async () => {
                return await this._mineStoneForCobble(3);
            }
        });

        // Skill 3: Craft planks
        this.register({
            id: 3,
            name: 'craft_planks',
            description: 'Craft wooden planks from logs',
            // Stop crafting once we have a comfortable surplus (32 planks = 8 logs worth)
            preconditions: () => this._hasItemLike('_log') && this._countItemLike('_planks') < 32,
            execute: async () => {
                return await this._craftPlanksFromLogs();
            }
        });

        // Skill 4: Craft sticks
        this.register({
            id: 4,
            name: 'craft_sticks',
            description: 'Craft sticks from planks',
            // 16 sticks covers 5+ pickaxes — no reason to hoard more
            preconditions: () => this._hasItemLike('_planks') && this._countItem('stick') < 16,
            execute: async () => {
                return await this._craftSticksFromPlanks();
            }
        });

        // Skill 5: Craft crafting table
        this.register({
            id: 5,
            name: 'craft_crafting_table',
            description: 'Craft a crafting table',
            // One crafting table is enough — check inventory AND nearby world
            preconditions: () => {
                if (this._countItemLike('_planks') < 4) return false;
                if (this._hasItem('crafting_table')) return false; // already carrying one
                const placed = this.bot.findBlock({ matching: b => b.name === 'crafting_table', maxDistance: 32 });
                return placed === null; // only craft if none placed nearby
            },
            execute: async () => {
                return await this._craftItem('crafting_table', 1);
            }
        });

        // Skill 6: Craft wooden pickaxe
        this.register({
            id: 6,
            name: 'craft_wooden_pickaxe',
            description: 'Craft a wooden pickaxe (requires crafting table nearby)',
            // Only craft if we don't already have any pickaxe (wood or better)
            preconditions: () =>
                this._countItemLike('_planks') >= 3 &&
                this._countItem('stick') >= 2 &&
                !this._hasUsablePickaxeAtLeast('wooden', TOOL_SAFETY_USES),
            execute: async () => {
                return await this._craftWithTable('wooden_pickaxe', 1);
            }
        });

        // Skill 7: Craft stone pickaxe
        this.register({
            id: 7,
            name: 'craft_stone_pickaxe',
            description: 'Craft a stone pickaxe',
            // Only craft if we don't already have a stone or better pickaxe
            preconditions: () =>
                this._countCobbleMaterials() >= 3 &&
                this._countItem('stick') >= 2 &&
                !this._hasUsablePickaxeAtLeast('stone', TOOL_SAFETY_USES),
            execute: async () => {
                return await this._craftWithTable('stone_pickaxe', 1);
            }
        });

        // Skill 8: Eat food
        this.register({
            id: 8,
            name: 'eat_food',
            description: 'Eat available food to restore hunger',
            preconditions: () => this._hasFood() && this.bot.food < 20,
            execute: async () => {
                return await this._eatFood();
            }
        });

        // Skill 9: Navigate to nearest structure (village, etc.)
        this.register({
            id: 9,
            name: 'explore',
            description: 'Explore in a random direction',
            preconditions: () => true,
            execute: async () => {
                return await this._explore();
            }
        });

        // Skill 10: Place crafting table
        this.register({
            id: 10,
            name: 'place_crafting_table',
            description: 'Place a crafting table nearby',
            preconditions: () => this._hasItem('crafting_table'),
            execute: async () => {
                return await this._placeBlock('crafting_table');
            }
        });

        // Skill 11: Mine iron ore
        this.register({
            id: 11,
            name: 'mine_iron',
            description: 'Mine iron ore (requires stone pickaxe)',
            preconditions: () => this._hasUsablePickaxeAtLeast('stone', 1) || this._canCraftStonePickaxe(),
            execute: async () => {
                return await this._mineIron(3);
            }
        });

        // Skill 12: Smelt iron (finds/crafts/places furnace automatically)
        this.register({
            id: 12,
            name: 'smelt_iron',
            description: 'Smelt raw iron into iron ingots',
            preconditions: () => {
                if (this._countSmeltableIron() <= 0) return false;
                // OK if we have a furnace item, enough cobble to make one, or one already in world
                if (this._hasItem('furnace')) return true;
                if (this._countCobbleMaterials() >= 8) return true;
                const nearby = this.bot.findBlock({ matching: b => b.name === 'furnace', maxDistance: 32 });
                return nearby !== null;
            },
            execute: async () => {
                return await this._smeltIron(3);
            }
        });

        // Skill 13: Craft furnace
        this.register({
            id: 13,
            name: 'craft_furnace',
            description: 'Craft a furnace from 8 stone-crafting materials',
            // One furnace is enough — smelt_iron will auto-craft/place one anyway
            preconditions: () =>
                this._countCobbleMaterials() >= 8 &&
                this._countItem('furnace') < 1 &&
                this.bot.findBlock({ matching: b => b.name === 'furnace', maxDistance: 32 }) === null,
            execute: async () => {
                return await this._craftWithTable('furnace', 1);
            }
        });

        // Skill 14: Craft iron pickaxe
        this.register({
            id: 14,
            name: 'craft_iron_pickaxe',
            description: 'Craft an iron pickaxe (requires 3 iron ingots + 2 sticks + crafting table)',
            // Only craft if we don't already have an iron or diamond pickaxe
            preconditions: () =>
                this._countItem('iron_ingot') >= 3 &&
                this._countItem('stick') >= 2 &&
                !this._hasUsablePickaxeAtLeast('iron', TOOL_SAFETY_USES),
            execute: async () => {
                return await this._craftWithTable('iron_pickaxe', 1);
            }
        });

        // Skill 15: Craft iron helmet
        this.register({
            id: 15,
            name: 'craft_iron_helmet',
            description: 'Craft an iron helmet (5 iron ingots + crafting table)',
            preconditions: () =>
                this._countItem('iron_ingot') >= 5 &&
                this._countItem('iron_helmet') < 1,
            execute: async () => {
                return await this._craftWithTable('iron_helmet', 1);
            }
        });

        // Skill 16: Craft iron chestplate
        this.register({
            id: 16,
            name: 'craft_iron_chestplate',
            description: 'Craft an iron chestplate (8 iron ingots + crafting table)',
            preconditions: () =>
                this._countItem('iron_ingot') >= 8 &&
                this._countItem('iron_chestplate') < 1,
            execute: async () => {
                return await this._craftWithTable('iron_chestplate', 1);
            }
        });

        // Skill 17: Craft iron leggings
        this.register({
            id: 17,
            name: 'craft_iron_leggings',
            description: 'Craft iron leggings (7 iron ingots + crafting table)',
            preconditions: () =>
                this._countItem('iron_ingot') >= 7 &&
                this._countItem('iron_leggings') < 1,
            execute: async () => {
                return await this._craftWithTable('iron_leggings', 1);
            }
        });

        // Skill 18: Craft iron boots
        this.register({
            id: 18,
            name: 'craft_iron_boots',
            description: 'Craft iron boots (4 iron ingots + crafting table)',
            preconditions: () =>
                this._countItem('iron_ingot') >= 4 &&
                this._countItem('iron_boots') < 1,
            execute: async () => {
                return await this._craftWithTable('iron_boots', 1);
            }
        });

        // Skill 19: Dig to diamond level
        this.register({
            id: 19,
            name: 'dig_to_diamond_level',
            description: 'Dig down to Y=-59 (diamond ore level), requires iron pickaxe',
            preconditions: () => this._hasUsablePickaxeAtLeast('iron', 1) && Math.floor(this.bot.entity.position.y) > -50,
            execute: async () => {
                return await this._digToY(-59);
            }
        });

        // Skill 20: Return to surface
        this.register({
            id: 20,
            name: 'return_to_surface',
            description: 'Navigate from underground back to the surface (Y>=60)',
            preconditions: () => Math.floor(this.bot.entity.position.y) < 60,
            execute: async () => {
                return await this._returnToSurface();
            }
        });

        // Skill 21: Mine diamond ore
        this.register({
            id: 21,
            name: 'mine_diamond',
            description: 'Mine diamond ore when at diamond level or when visible nearby',
            preconditions: () =>
                this._hasUsablePickaxeAtLeast('iron', 1) &&
                (Math.floor(this.bot.entity.position.y) <= -50 || this._findVisibleDiamondOre(DIAMOND_SCAN_RADIUS) !== null),
            execute: async () => {
                return await this._mineDiamond(3);
            }
        });

        // Skill 22: Craft diamond pickaxe
        this.register({
            id: 22,
            name: 'craft_diamond_pickaxe',
            description: 'Craft a diamond pickaxe (3 diamonds + 2 sticks + crafting table)',
            preconditions: () =>
                this._countItem('diamond') >= 3 &&
                this._countItem('stick') >= 2 &&
                this._countItem('diamond_pickaxe') < 1,
            execute: async () => {
                return await this._craftWithTable('diamond_pickaxe', 1);
            }
        });

        // Skill 23: Craft diamond helmet
        this.register({
            id: 23,
            name: 'craft_diamond_helmet',
            description: 'Craft a diamond helmet (5 diamonds + crafting table)',
            preconditions: () =>
                this._countItem('diamond') >= 5 &&
                this._countItem('diamond_helmet') < 1,
            execute: async () => {
                return await this._craftWithTable('diamond_helmet', 1);
            }
        });

        // Skill 24: Craft diamond chestplate
        this.register({
            id: 24,
            name: 'craft_diamond_chestplate',
            description: 'Craft a diamond chestplate (8 diamonds + crafting table)',
            preconditions: () =>
                this._countItem('diamond') >= 8 &&
                this._countItem('diamond_chestplate') < 1,
            execute: async () => {
                return await this._craftWithTable('diamond_chestplate', 1);
            }
        });

        // Skill 25: Craft diamond leggings
        this.register({
            id: 25,
            name: 'craft_diamond_leggings',
            description: 'Craft diamond leggings (7 diamonds + crafting table)',
            preconditions: () =>
                this._countItem('diamond') >= 7 &&
                this._countItem('diamond_leggings') < 1,
            execute: async () => {
                return await this._craftWithTable('diamond_leggings', 1);
            }
        });

        // Skill 26: Craft diamond boots
        this.register({
            id: 26,
            name: 'craft_diamond_boots',
            description: 'Craft diamond boots (4 diamonds + crafting table)',
            preconditions: () =>
                this._countItem('diamond') >= 4 &&
                this._countItem('diamond_boots') < 1,
            execute: async () => {
                return await this._craftWithTable('diamond_boots', 1);
            }
        });

        // Skill 27: Clear junk inventory
        // Drops low-value blocks that clog inventory during deep mining.
        // Only fires when inventory is nearly full (>=27 of 36 slots occupied).
        this.register({
            id: 27,
            name: 'clear_junk',
            description: 'Drop low-value blocks to free inventory space (auto-triggered when nearly full)',
            preconditions: () => this.bot.inventory.items().length >= 27,
            execute: async () => {
                return await this._clearJunk();
            }
        });
    }

    /**
     * Register a new skill
     */
    register(skill) {
        this.skillRegistry.set(skill.id, skill);
        console.log(`[SkillManager] Registered skill ${skill.id}: ${skill.name}`);
    }

    /**
     * Get all available skills (for action space definition)
     */
    getSkillList() {
        return Array.from(this.skillRegistry.values()).map(s => ({
            id: s.id,
            name: s.name,
            description: s.description,
            available: s.preconditions()
        }));
    }

    /**
     * Get number of skills (action space size)
     */
    getActionSpaceSize() {
        return this.skillRegistry.size;
    }

    /**
     * Execute a skill by ID
     * Returns: { success: bool, message: string, reward: number }
     */
    async executeSkill(skillId) {
        const skill = this.skillRegistry.get(skillId);
        
        if (!skill) {
            return { 
                success: false, 
                message: `Unknown skill ID: ${skillId}`,
                reward: -1 
            };
        }

        // Check preconditions (initiation set in Options Framework)
        if (!skill.preconditions()) {
            return { 
                success: false, 
                message: `Preconditions not met for ${skill.name}`,
                reward: -0.5 
            };
        }

        console.log(`[SkillManager] Executing skill: ${skill.name}`);
        this.currentSkill = skill;
        
        const startTime = Date.now();
        const startInventory = this._getInventorySnapshot();
        
        try {
            const result = await skill.execute();
            const endInventory = this._getInventorySnapshot();
            
            // Calculate intrinsic reward based on inventory changes
            const inventoryReward = this._calculateInventoryReward(startInventory, endInventory);
            
            this.executionHistory.push({
                skillId,
                skillName: skill.name,
                success: result.success,
                duration: Date.now() - startTime,
                timestamp: Date.now()
            });

            return {
                ...result,
                reward: result.success ? (0.1 + inventoryReward) : -0.1
            };
        } catch (error) {
            console.error(`[SkillManager] Skill ${skill.name} failed:`, error.message);
            return { 
                success: false, 
                message: error.message,
                reward: -0.5 
            };
        } finally {
            this.currentSkill = null;
        }
    }

    // ==================== Skill Implementations ====================

    async _harvestWood(targetLogs = 3) {
        const startLogs = this._countItemLike('_log');
        let mined = 0;

        while (this._countItemLike('_log') - startLogs < targetLogs) {
            const log = await this._findResourceWithExploration(
                block => LOG_TYPES.includes(block.name),
                'tree/log'
            );

            if (!log) break;

            const beforeLogs = this._countItemLike('_log');
            const dug = await this._digBlockSafely(log, 'log');
            if (!dug) continue;
            mined++;
            await this._pickupNearbyDrops('_log', beforeLogs + 1, 3500);
        }

        const gained = this._countItemLike('_log') - startLogs;
        if (gained <= 0) {
            return { success: false, message: `No trees found after expanded search (${RESOURCE_SEARCH_ATTEMPTS} attempt(s)) or no logs picked up` };
        }

        return { success: true, message: `Harvested ${gained} log(s), mined ${mined} block(s)` };
    }

    async _mineBlock(blockName, count = 1) {
        let mined = 0;
        
        while (mined < count) {
            const requiredTier = blockName.includes('diamond') ? 'iron' : null;
            if (requiredTier) {
                const ready = await this._ensurePickaxeAtLeast(requiredTier, Math.max(2, count - mined));
                if (!ready.success) return ready;
            }

            const block = await this._findResourceWithExploration(
                b => b.name === blockName || b.name.includes(blockName),
                blockName
            );
            
            if (!block) {
                return { 
                    success: mined > 0, 
                    message: `Mined ${mined}/${count} ${blockName}; no more found after expanded search` 
                };
            }
            
            // Equip best tool
            await this._equipBestTool(block, requiredTier, 1);
            const dug = await this._digBlockSafely(block, blockName);
            if (!dug) continue;
            mined++;
        }
        
        return { success: true, message: `Mined ${count} ${blockName}` };
    }

    async _mineStoneForCobble(targetCount = 3) {
        const startCobble = this._countCobbleMaterials();
        let mined = 0;
        const stoneSources = [
            'stone', 'deepslate', 'cobblestone', 'cobbled_deepslate', 'blackstone'
        ];

        while (this._countCobbleMaterials() - startCobble < targetCount) {
            const ready = await this._ensurePickaxeAtLeast('wooden', Math.max(2, targetCount - mined));
            if (!ready.success) {
                return { success: mined > 0, message: `Collected ${this._countCobbleMaterials() - startCobble}/${targetCount} cobble material(s); ${ready.message}` };
            }

            const block = await this._findResourceWithExploration(
                b => stoneSources.includes(b.name),
                'stone/cobble'
            );

            if (!block) break;

            await this._equipBestTool(block, 'wooden', 1);
            const beforeCobble = this._countCobbleMaterials();
            const dug = await this._digBlockSafely(block, 'stone/cobble');
            if (!dug) continue;
            mined++;
            await this._pickupNearbyCobble(beforeCobble + 1, 3000);
        }

        const gained = this._countCobbleMaterials() - startCobble;
        if (gained <= 0) {
            return { success: false, message: 'No usable cobblestone material collected' };
        }

        return {
            success: gained >= targetCount,
            message: `Collected ${gained}/${targetCount} cobble material(s), mined ${mined} block(s)`
        };
    }

    async _mineIron(targetCount = 3) {
        const startIron = this._countSmeltableIron();
        let mined = 0;

        while (this._countSmeltableIron() - startIron < targetCount) {
            const ready = await this._ensurePickaxeAtLeast('stone', Math.max(2, targetCount - mined));
            if (!ready.success) {
                return { success: mined > 0, message: `Collected ${this._countSmeltableIron() - startIron}/${targetCount} smeltable iron item(s); ${ready.message}` };
            }

            const block = await this._findResourceWithExploration(
                b => IRON_ORE_BLOCKS.includes(b.name),
                'iron ore'
            );

            if (!block) break;

            await this._equipBestTool(block, 'stone', 1);
            const beforeIron = this._countSmeltableIron();
            const dug = await this._digBlockSafely(block, 'iron ore');
            if (!dug) continue;
            mined++;
            await this._pickupNearbySmeltableIron(beforeIron + 1, 5000);
        }

        const gained = this._countSmeltableIron() - startIron;
        if (gained <= 0) {
            return { success: false, message: 'No raw iron or iron ore collected' };
        }

        return {
            success: gained >= targetCount,
            message: `Collected ${gained}/${targetCount} smeltable iron item(s), mined ${mined} block(s)`
        };
    }

    async _mineDiamond(targetCount = 3) {
        const startDiamonds = this._countItem('diamond');
        let mined = 0;

        while (this._countItem('diamond') - startDiamonds < targetCount) {
            const ready = await this._ensurePickaxeAtLeast('iron', Math.max(2, targetCount - mined));
            if (!ready.success) {
                return { success: mined > 0, message: `Collected ${this._countItem('diamond') - startDiamonds}/${targetCount} diamond(s); ${ready.message}` };
            }

            const block = await this._findResourceWithExploration(
                b => DIAMOND_ORE_BLOCKS.includes(b.name),
                'diamond ore'
            );

            if (!block) break;

            await this._equipBestTool(block, 'iron', 1);
            const beforeDiamonds = this._countItem('diamond');
            const dug = await this._digBlockSafely(block, 'diamond ore');
            if (!dug) continue;
            mined++;
            await this._pickupNearbyItem('diamond', beforeDiamonds + 1, 6000);
        }

        const gained = this._countItem('diamond') - startDiamonds;
        if (gained <= 0) {
            return { success: false, message: 'No diamonds collected from diamond ore' };
        }

        return {
            success: gained >= targetCount,
            message: `Collected ${gained}/${targetCount} diamond(s), mined ${mined} block(s)`
        };
    }

    async _craftItem(itemName, count = 1) {
        const mcData = require('minecraft-data')(this.bot.version);
        const recipe = this.bot.recipesFor(mcData.itemsByName[itemName]?.id)[0];
        
        if (!recipe) {
            return { success: false, message: `No recipe found for ${itemName}` };
        }
        
        try {
            await this.bot.craft(recipe, count, null);
            return { success: true, message: `Crafted ${count} ${itemName}` };
        } catch (error) {
            return { success: false, message: `Failed to craft ${itemName}: ${error.message}` };
        }
    }

    async _craftPlanksFromLogs() {
        const mcData = require('minecraft-data')(this.bot.version);
        const targetPlanks = 16;
        let crafted = 0;

        while (this._countItemLike('_planks') < targetPlanks) {
            const logItem = this.bot.inventory.items().find(i => LOG_TYPES.includes(i.name) || i.name.endsWith('_log'));
            if (!logItem) break;

            const plankName = LOG_TO_PLANKS[logItem.name] || logItem.name.replace('_log', '_planks');
            const plankDef = mcData.itemsByName[plankName];
            if (!plankDef) {
                return { success: false, message: `No plank item found for ${logItem.name}` };
            }

            const neededRecipes = Math.max(1, Math.ceil((targetPlanks - this._countItemLike('_planks')) / 4));
            const craftCount = Math.min(logItem.count, neededRecipes);
            const recipe = this.bot.recipesFor(plankDef.id, null, 1, null)[0];
            if (!recipe) {
                return { success: false, message: `No craftable recipe found for ${plankName}` };
            }

            try {
                await this.bot.craft(recipe, craftCount, null);
                crafted += craftCount;
                await this._wait(200);
            } catch (error) {
                return { success: false, message: `Failed to craft ${plankName}: ${error.message}` };
            }
        }

        if (crafted <= 0) {
            return { success: false, message: 'No logs available for plank crafting' };
        }
        return { success: true, message: `Crafted planks from ${crafted} log(s)` };
    }

    async _craftSticksFromPlanks() {
        const mcData = require('minecraft-data')(this.bot.version);
        const targetSticks = 8;
        const currentSticks = this._countItem('stick');
        if (currentSticks >= targetSticks) {
            return { success: true, message: `Already have ${currentSticks} sticks` };
        }

        const stickDef = mcData.itemsByName.stick;
        const recipe = this.bot.recipesFor(stickDef?.id, null, 1, null)[0];
        if (!recipe) {
            return { success: false, message: 'No recipe found for stick' };
        }

        const availablePlanks = this._countItemLike('_planks');
        if (availablePlanks < 2) {
            return { success: false, message: 'Need planks to craft sticks' };
        }

        const neededRecipes = Math.ceil((targetSticks - currentSticks) / 4);
        const maxRecipes = Math.floor(availablePlanks / 2);
        const craftCount = Math.max(1, Math.min(neededRecipes, maxRecipes));

        try {
            await this.bot.craft(recipe, craftCount, null);
            await this._wait(200);
            return { success: true, message: `Crafted sticks, now have ${this._countItem('stick')}` };
        } catch (error) {
            return { success: false, message: `Failed to craft sticks: ${error.message}` };
        }
    }

    async _craftWithTable(itemName, count = 1) {
        const mcData = require('minecraft-data')(this.bot.version);
        const tableCountBefore = this._countItem('crafting_table');
        
        // Find or place crafting table
        let craftingTable = this.bot.findBlock({
            matching: b => b.name === 'crafting_table',
            maxDistance: 32
        });

        if (!craftingTable && !this._hasItem('crafting_table') && this._countItemLike('_planks') >= 4) {
            const craftTable = await this._craftItem('crafting_table', 1);
            if (!craftTable.success) {
                return { success: false, message: `Could not craft portable crafting table: ${craftTable.message}` };
            }
        }
        
        if (!craftingTable && this._hasItem('crafting_table')) {
            const placeResult = await this._placeBlock('crafting_table');
            if (!placeResult.success) return placeResult;
            
            craftingTable = this.bot.findBlock({
                matching: b => b.name === 'crafting_table',
                maxDistance: 8
            });
        }
        
        if (!craftingTable) {
            return { success: false, message: 'No crafting table available' };
        }
        
        await this._goTo(craftingTable.position);
        
        const targetItem = mcData.itemsByName[itemName];
        
        if (!targetItem) {
            return { success: false, message: `Unknown item: ${itemName}` };
        }

        const recipes = this.bot.recipesFor(targetItem.id, null, 1, craftingTable);

        if (!recipes || recipes.length === 0) {
            return { success: false, message: `No recipe found for ${itemName}` };
        }
        
        const errors = [];
        try {
            for (const recipe of recipes) {
                try {
                    await this.bot.craft(recipe, count, craftingTable);
                    const pickup = await this._collectCraftingTableAfterUse(craftingTable, tableCountBefore);
                    const suffix = pickup.success ? `; ${pickup.message}` : `; table recovery warning: ${pickup.message}`;
                    return { success: true, message: `Crafted ${count} ${itemName}${suffix}` };
                } catch (error) {
                    errors.push(error.message);
                }
            }
            return {
                success: false,
                message: `Failed to craft ${itemName}: ${errors.slice(0, 3).join(' | ')}`
            };
        } catch (error) {
            return { success: false, message: `Failed to craft ${itemName}: ${error.message}` };
        }
    }

    async _collectCraftingTableAfterUse(craftingTable, tableCountBefore = 0) {
        if (!COLLECT_CRAFTING_TABLE_AFTER_USE) {
            return { success: true, message: 'left crafting table in place' };
        }
        if (!craftingTable || craftingTable.name !== 'crafting_table') {
            return { success: false, message: 'no crafting table block to collect' };
        }

        const targetCount = Math.max(tableCountBefore, this._countItem('crafting_table') + 1);
        let block = this.bot.blockAt(craftingTable.position);
        if (!block || block.name !== 'crafting_table') {
            const nearby = this.bot.findBlock({
                matching: b => b.name === 'crafting_table',
                maxDistance: 8
            });
            if (!nearby) {
                return this._countItem('crafting_table') >= tableCountBefore
                    ? { success: true, message: 'crafting table already in inventory' }
                    : { success: false, message: 'crafting table disappeared before collection' };
            }
            block = nearby;
        }

        try {
            await this._goTo(block.position);
        } catch (_) {
            // It may still be diggable from current position.
        }

        const before = this._countItem('crafting_table');
        const dug = await this._digBlockSafely(block, 'portable crafting_table', 6);
        if (!dug) {
            return { success: false, message: `could not dig crafting table at ${block.position}` };
        }

        const picked = await this._pickupNearbyItem('crafting_table', Math.max(before + 1, targetCount), 9000);
        if (picked) {
            return { success: true, message: `collected crafting table, now have ${this._countItem('crafting_table')}` };
        }

        const drop = this._nearestItemDrop(12);
        if (drop) {
            try {
                await this._goTo(drop.position);
                await this._wait(this._timeoutMs(1000));
            } catch (_) {
                await this._wait(this._timeoutMs(1000));
            }
        }

        if (this._countItem('crafting_table') >= Math.max(before + 1, targetCount)) {
            return { success: true, message: `collected crafting table after tracking drop` };
        }

        return {
            success: false,
            message: `dug crafting table but pickup not confirmed, have ${this._countItem('crafting_table')}`
        };
    }

    async _placeBlock(itemName) {
        const item = this.bot.inventory.items().find(i => i.name === itemName);
        if (!item) {
            return { success: false, message: `No ${itemName} in inventory` };
        }

        const beforeCount = this._countItem(itemName);

        const escape = await this._escapeLocalObstruction(`before placing ${itemName}`, 1);
        if (escape.cleared > 0) {
            await this._moveToNearbyOpenGround(4, `after clearing ${escape.cleared} local block(s)`, true);
        }

        if (this._isUtilityPlacementBlock(itemName)) {
            const utilityResult = await this._placeUtilityBlockOnSamePlane(itemName, item, beforeCount);
            if (utilityResult.success) return utilityResult;
            // Fall through to the older workspace placement as a last resort.
            console.log(`[Place] Same-plane placement failed for ${itemName}: ${utilityResult.message}`);
        }

        let workspace = await this._preparePlacementWorkspace(itemName);
        if (!workspace.success) {
            const retryEscape = await this._escapeLocalObstruction(`retry workspace for ${itemName}`, 2);
            if (retryEscape.cleared > 0) {
                await this._moveToNearbyOpenGround(5, `after retry clearing ${retryEscape.cleared} local block(s)`, true);
            }
            workspace = await this._preparePlacementWorkspace(itemName);
        }
        if (!workspace.success) {
            return workspace;
        }

        const targetPos = workspace.targetPos;
        const referenceBlock = this.bot.blockAt(targetPos.offset(0, -1, 0));

        if (!referenceBlock || !this._isSolidSupport(referenceBlock)) {
            return { success: false, message: `No solid support for ${itemName} after workspace preparation` };
        }

        let lastError = 'no suitable placement position';
        await this.bot.equip(item, 'hand');

        for (let attempt = 1; attempt <= 5; attempt++) {
            try {
                await this._moveNearPlacementTarget(targetPos, attempt);
                await this.bot.equip(item, 'hand');

                const currentReference = this.bot.blockAt(targetPos.offset(0, -1, 0));
                const currentTarget = this.bot.blockAt(targetPos);
                if (!currentReference || !this._isSolidSupport(currentReference)) {
                    lastError = `support vanished before placement attempt ${attempt}`;
                    continue;
                }
                if (!this._isReplaceableBlock(currentTarget)) {
                    if (currentTarget?.name === itemName) {
                        return { success: true, message: `Placed ${itemName} before retry check` };
                    }
                    lastError = `target occupied by ${currentTarget?.name || 'unknown'} before attempt ${attempt}`;
                    continue;
                }

                const cursor = this._placementCursorForAttempt(attempt);
                const lookPoint = targetPos.offset(0.5 + cursor.x * 0.25, 0.55, 0.5 + cursor.z * 0.25);
                await this.bot.lookAt(lookPoint, true);
                await this._wait(200);
                await Promise.race([
                    this.bot.placeBlock(currentReference, new Vec3(0, 1, 0)),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('placeBlock local timeout')), this._timeoutMs(5500)))
                ]);
                await this._wait(500);

                const placed = this.bot.blockAt(targetPos);
                if (placed?.name === itemName) {
                    return { success: true, message: `Placed ${itemName} in cleared 3x3x2 workspace on attempt ${attempt}` };
                }

                const nearbyPlaced = this.bot.findBlock({ matching: b => b.name === itemName, maxDistance: 10 });
                if (nearbyPlaced) {
                    return { success: true, message: `Placed ${itemName} nearby on attempt ${attempt}` };
                }
                lastError = `server did not place ${itemName} on attempt ${attempt}`;
            } catch (error) {
                lastError = `${error.message} on attempt ${attempt}`;

                // Mineflayer sometimes times out waiting for blockUpdate even when
                // the server accepted the placement. Trust the world/inventory check.
                await this._wait(1000);
                const directPlaced = this.bot.blockAt(targetPos);
                if (directPlaced?.name === itemName) {
                    return { success: true, message: `Placed ${itemName} after delayed update on attempt ${attempt}` };
                }

                const nearbyPlaced = this.bot.findBlock({ matching: b => b.name === itemName, maxDistance: 16 });
                if (nearbyPlaced || this._countItem(itemName) < beforeCount) {
                    return { success: true, message: `Placed ${itemName} after delayed update on attempt ${attempt}` };
                }
            }

            try { this.bot.pathfinder.stop(); } catch (_) {}
            await this._wait(350 + attempt * 200);
        }

        return { success: false, message: `Failed to place ${itemName}: ${lastError}` };
    }

    async _placeUtilityBlockOnSamePlane(itemName, item, beforeCount) {
        let lastError = 'no same-plane placement candidate';
        const candidates = this._samePlanePlacementCandidates();

        for (let attempt = 1; attempt <= Math.min(candidates.length, 16); attempt++) {
            const targetPos = candidates[attempt - 1];
            const referenceBlock = this.bot.blockAt(targetPos.offset(0, -1, 0));
            const targetBlock = this.bot.blockAt(targetPos);

            if (!referenceBlock || !this._isSolidSupport(referenceBlock)) {
                lastError = `no support below ${targetPos}`;
                continue;
            }
            if (!this._isReplaceableBlock(targetBlock)) {
                if (targetBlock?.name === itemName) {
                    return { success: true, message: `${itemName} already placed at ${targetPos}` };
                }
                lastError = `target ${targetPos} occupied by ${targetBlock?.name || 'unknown'}`;
                continue;
            }
            if (this.bot.entity.position.distanceTo(targetPos.offset(0.5, 0, 0.5)) > 4.2) {
                try {
                    await this._gotoWithTimeout(new GoalNear(targetPos.x, targetPos.y, targetPos.z, 2), 10000, `moving near ${itemName} placement`);
                } catch (error) {
                    lastError = `could not move near ${targetPos}: ${error.message}`;
                    continue;
                }
            }

            for (let localAttempt = 1; localAttempt <= 3; localAttempt++) {
                try {
                    try { this.bot.pathfinder.stop(); } catch (_) {}
                    await this.bot.equip(item, 'hand');

                    // Aim at the top face of the support block. This is more
                    // reliable than looking straight at the target air block.
                    await this.bot.lookAt(referenceBlock.position.offset(0.5, 1.0, 0.5), true);
                    await this._wait(250 + localAttempt * 250);

                    await Promise.race([
                        this.bot.placeBlock(referenceBlock, new Vec3(0, 1, 0)),
                        new Promise((_, reject) => setTimeout(() => reject(new Error('same-plane place timeout')), this._timeoutMs(10000)))
                    ]);
                    await this._wait(800);

                    const placed = this.bot.blockAt(targetPos);
                    if (placed?.name === itemName) {
                        return { success: true, message: `Placed ${itemName} on same plane at ${targetPos} attempt ${attempt}.${localAttempt}` };
                    }

                    const nearbyPlaced = this.bot.findBlock({ matching: b => b.name === itemName, maxDistance: 8 });
                    if (nearbyPlaced || this._countItem(itemName) < beforeCount) {
                        return { success: true, message: `Placed ${itemName} nearby after same-plane attempt ${attempt}.${localAttempt}` };
                    }
                    lastError = `server did not place ${itemName} at ${targetPos}`;
                } catch (error) {
                    lastError = `${error.message} at ${targetPos}`;
                    await this._wait(this._timeoutMs(800 + localAttempt * 250));

                    const delayedPlaced = this.bot.blockAt(targetPos);
                    if (delayedPlaced?.name === itemName || this._countItem(itemName) < beforeCount) {
                        return { success: true, message: `Placed ${itemName} after delayed same-plane update at ${targetPos}` };
                    }
                }
            }
        }

        return { success: false, message: lastError };
    }

    _samePlanePlacementCandidates() {
        const base = this.bot.entity.position.floored();
        const front = this._frontDirection();
        const back = { x: -front.x, z: -front.z };
        const side = { x: -front.z, z: front.x };
        const ordered = [
            [front.x, front.z],
            [back.x, back.z],
            [side.x, side.z],
            [-side.x, -side.z],
            [front.x + side.x, front.z + side.z],
            [front.x - side.x, front.z - side.z],
            [back.x + side.x, back.z + side.z],
            [back.x - side.x, back.z - side.z],
            [front.x * 2, front.z * 2],
            [back.x * 2, back.z * 2],
            [side.x * 2, side.z * 2],
            [-side.x * 2, -side.z * 2],
            [front.x * 2 + side.x, front.z * 2 + side.z],
            [front.x * 2 - side.x, front.z * 2 - side.z],
            [back.x * 2 + side.x, back.z * 2 + side.z],
            [back.x * 2 - side.x, back.z * 2 - side.z]
        ];
        const seen = new Set();
        return ordered
            .map(([dx, dz]) => base.offset(dx, 0, dz))
            .filter(pos => {
                const key = `${pos.x},${pos.y},${pos.z}`;
                if (seen.has(key)) return false;
                seen.add(key);
                return true;
            });
    }

    _isUtilityPlacementBlock(itemName) {
        return itemName === 'crafting_table' || itemName === 'furnace';
    }

    async _moveNearPlacementTarget(targetPos, attempt = 1) {
        const mcData = require('minecraft-data')(this.bot.version);
        const move = new Movements(this.bot, mcData);
        move.canDig = false;
        move.canSwim = false;
        move.allow1by1towers = false;
        move.scafoldingBlocks = [];
        this.bot.pathfinder.setMovements(move);

        const current = this.bot.entity.position.floored();
        if (attempt === 1 && current.distanceTo(targetPos) <= 1.5) {
            return;
        }

        const front = this._frontDirection();
        const back = { x: -front.x, z: -front.z };
        const side = { x: -front.z, z: front.x };
        const offsets = [
            [back.x, back.z],
            [back.x + side.x, back.z + side.z],
            [back.x - side.x, back.z - side.z],
            [1, 0],
            [-1, 0],
            [0, 1],
            [0, -1],
            [1, 1],
            [-1, -1],
            [1, -1],
            [-1, 1]
        ];
        const [dx, dz] = offsets[(attempt - 1) % offsets.length];
        const standPos = targetPos.offset(dx, 0, dz);
        await this._gotoWithTimeout(new GoalNear(standPos.x, standPos.y, standPos.z, 1), 8000, 'moving near placement target');
    }

    _frontDirection() {
        const yaw = this.bot.entity?.yaw || 0;
        const x = -Math.sin(yaw);
        const z = -Math.cos(yaw);
        if (Math.abs(x) > Math.abs(z)) {
            return { x: x > 0 ? 1 : -1, z: 0 };
        }
        return { x: 0, z: z > 0 ? 1 : -1 };
    }

    _placementCursorForAttempt(attempt = 1) {
        const cursors = [
            new Vec3(0, 0.5, 0),
            new Vec3(0.25, 0.5, 0),
            new Vec3(-0.25, 0.5, 0),
            new Vec3(0, 0.5, 0.25),
            new Vec3(0, 0.5, -0.25)
        ];
        return cursors[(attempt - 1) % cursors.length];
    }

    async _preparePlacementWorkspace(itemName) {
        const base = this.bot.entity.position.floored();
        const front = this._frontDirection();
        const side = { x: -front.z, z: front.x };
        const candidates = [
            [front.x, 0, front.z],
            [front.x + side.x, 0, front.z + side.z],
            [front.x - side.x, 0, front.z - side.z],
            [front.x * 2, 0, front.z * 2],
            [front.x * 2 + side.x, 0, front.z * 2 + side.z],
            [front.x * 2 - side.x, 0, front.z * 2 - side.z],
            [side.x, 0, side.z],
            [-side.x, 0, -side.z]
        ];

        let lastError = 'no 3x3x2 workspace candidate';

        for (const [dx, dy, dz] of candidates) {
            const targetPos = base.offset(dx, dy, dz);
            const support = this.bot.blockAt(targetPos.offset(0, -1, 0));
            if (!support || !this._isSolidSupport(support)) {
                lastError = `no support below ${targetPos}`;
                continue;
            }

            const safe = await this._clearPlacementWorkspace(targetPos, itemName);
            if (!safe.success) {
                lastError = safe.message;
                continue;
            }

            const targetBlock = this.bot.blockAt(targetPos);
            if (!this._isReplaceableBlock(targetBlock)) {
                lastError = `target ${targetPos} still occupied by ${targetBlock?.name || 'unknown'}`;
                continue;
            }

            return { success: true, targetPos, message: `Prepared 3x3x2 workspace at ${targetPos}` };
        }

        return { success: false, message: `Failed to prepare 3x3x2 workspace for ${itemName}: ${lastError}` };
    }

    async _clearPlacementWorkspace(centerPos, itemName) {
        const protectedNames = new Set([
            itemName,
            'crafting_table',
            'furnace',
            'chest',
            'barrel',
            'bed',
            'white_bed',
            'orange_bed',
            'magenta_bed',
            'light_blue_bed',
            'yellow_bed',
            'lime_bed',
            'pink_bed',
            'gray_bed',
            'light_gray_bed',
            'cyan_bed',
            'purple_bed',
            'blue_bed',
            'brown_bed',
            'green_bed',
            'red_bed',
            'black_bed'
        ]);

        for (const dy of [0, 1]) {
            for (let dx = -1; dx <= 1; dx++) {
                for (let dz = -1; dz <= 1; dz++) {
                    const pos = centerPos.offset(dx, dy, dz);
                    const block = this.bot.blockAt(pos);
                    if (!block || this._isReplaceableBlock(block)) continue;
                    if (protectedNames.has(block.name)) {
                        return { success: false, message: `workspace contains protected block ${block.name} at ${pos}` };
                    }
                    if (this._isUnsafeMiningBlock(block) || !block.diggable || block.name === 'bedrock') {
                        return { success: false, message: `workspace contains unsafe block ${block.name} at ${pos}` };
                    }

                    const ok = await this._digBlockSafely(block, `workspace ${block.name}`, 2);
                    if (!ok) {
                        return { success: false, message: `could not clear workspace block ${block.name} at ${pos}` };
                    }
                    await this._wait(100);
                }
            }
        }

        return { success: true, message: `Cleared 3x3x2 workspace at ${centerPos}` };
    }

    async _escapeLocalObstruction(reason = 'escape', radius = 1) {
        let cleared = 0;
        const positions = this._localEscapePositions(radius);

        for (const pos of positions) {
            const block = this.bot.blockAt(pos);
            if (!this._isEscapeClearableBlock(block)) continue;

            const ok = await this._digEscapeBlock(block, reason);
            if (ok) {
                cleared++;
                await this._wait(120);
            }
        }

        if (cleared > 0) {
            try { this.bot.pathfinder.stop(); } catch (_) {}
            await this._wait(250);
            console.log(`[Escape] Cleared ${cleared} nearby block(s) for ${reason}`);
        }

        return { success: true, cleared };
    }

    _localEscapePositions(radius = 1) {
        const base = this.bot.entity.position.floored();
        const positions = [];
        const seen = new Set();

        const add = (pos, priority) => {
            const key = `${pos.x},${pos.y},${pos.z}`;
            if (seen.has(key)) return;
            seen.add(key);
            positions.push({ pos, priority });
        };

        // Clear body/head first. If these are occupied, pathfinder cannot recover.
        add(base, 0);
        add(base.offset(0, 1, 0), 1);
        add(base.offset(0, 2, 0), 2);

        for (let dy = 0; dy <= 2; dy++) {
            for (let dx = -radius; dx <= radius; dx++) {
                for (let dz = -radius; dz <= radius; dz++) {
                    if (dx === 0 && dz === 0) continue;
                    const manhattan = Math.abs(dx) + Math.abs(dz);
                    if (manhattan > radius + 1) continue;
                    add(base.offset(dx, dy, dz), 10 + manhattan + dy * 2);
                }
            }
        }

        return positions
            .sort((a, b) => a.priority - b.priority || a.pos.distanceTo(base) - b.pos.distanceTo(base))
            .map(entry => entry.pos);
    }

    async _digEscapeBlock(block, reason = 'escape') {
        if (!block || !block.diggable || this._isUnsafeMiningBlock(block)) return false;

        try {
            await this._equipBestTool(block, null, 1);
        } catch (_) {
            // Leaves and logs can be punched if no suitable tool is available.
        }

        try {
            await this.bot.lookAt(block.position.offset(0.5, 0.5, 0.5), true);
            await this._wait(80);
            if (!this.bot.canDigBlock(block)) {
                console.log(`[Escape] Cannot reach ${block.name} at ${block.position} while trying to ${reason}`);
                return false;
            }

            await Promise.race([
                this.bot.dig(block, true),
                new Promise((_, reject) => setTimeout(() => reject(new Error('escape dig timeout')), this._timeoutMs(4500)))
            ]);
            return true;
        } catch (error) {
            console.log(`[Escape] Failed to clear ${block.name} at ${block.position}: ${error.message}`);
            return false;
        }
    }

    _isEscapeClearableBlock(block) {
        if (!block || this._isReplaceableBlock(block)) return false;
        if (!block.diggable || block.name === 'bedrock' || this._isUnsafeMiningBlock(block)) return false;
        if (this._isProtectedUtilityBlock(block.name)) return false;

        const name = block.name;
        return (
            ESCAPE_CLEARABLE_BLOCKS.includes(name) ||
            this._isTreeBlockName(name) ||
            name.endsWith('_leaves') ||
            name.endsWith('_roots') ||
            name.endsWith('_mushroom_block')
        );
    }

    async _moveToNearbyOpenGround(maxRadius = 4, label = 'escape to open ground', forceMove = false) {
        const mcData = require('minecraft-data')(this.bot.version);
        const base = this.bot.entity.position.floored();
        const currentSupport = this.bot.blockAt(base.offset(0, -1, 0));

        if (
            !forceMove &&
            this._isBodySpaceClear(base, base.offset(0, 1, 0)) &&
            currentSupport &&
            this._isSolidSupport(currentSupport) &&
            !this._isUnsafeSupportBlock(currentSupport)
        ) {
            return true;
        }

        const move = new Movements(this.bot, mcData);
        move.canDig = false;
        move.canSwim = false;
        move.allowSprinting = false;
        move.scafoldingBlocks = [];
        this.bot.pathfinder.setMovements(move);

        const candidates = this._nearbyOpenGroundCandidates(base, maxRadius);
        for (const candidate of candidates) {
            try {
                await this._gotoWithTimeout(new GoalBlock(candidate.x, candidate.y, candidate.z), 7000, label);
                const now = this.bot.entity.position.floored();
                if (now.distanceTo(candidate) <= 1.5) return true;
            } catch (_) {
                try { this.bot.pathfinder.stop(); } catch (__) {}
            }
        }
        return false;
    }

    _nearbyOpenGroundCandidates(base, maxRadius = 4) {
        const candidates = [];

        for (let radius = 1; radius <= maxRadius; radius++) {
            for (let dy = 0; dy >= -3; dy--) {
                for (let dx = -radius; dx <= radius; dx++) {
                    for (let dz = -radius; dz <= radius; dz++) {
                        if (Math.abs(dx) !== radius && Math.abs(dz) !== radius) continue;

                        const feet = base.offset(dx, dy, dz);
                        const head = feet.offset(0, 1, 0);
                        const support = this.bot.blockAt(feet.offset(0, -1, 0));
                        if (!this._isBodySpaceClear(feet, head)) continue;
                        if (!support || this._isUnsafeSupportBlock(support) || !this._isSolidSupport(support)) continue;

                        const treeSupportPenalty = this._isTreeBlockName(support.name) || support.name.endsWith('_leaves') ? 10 : 0;
                        candidates.push({
                            pos: feet,
                            score: radius + Math.abs(dy) * 2 + treeSupportPenalty
                        });
                    }
                }
            }
        }

        return candidates
            .sort((a, b) => a.score - b.score || a.pos.distanceTo(base) - b.pos.distanceTo(base))
            .map(entry => entry.pos);
    }

    _isTreeBlockName(name) {
        return (
            LOG_TYPES.includes(name) ||
            name.endsWith('_log') ||
            name.endsWith('_wood') ||
            name.endsWith('_stem') ||
            name.endsWith('_hyphae')
        );
    }

    _isTreeOrLeafName(name) {
        if (!name) return false;
        return (
            this._isTreeBlockName(name) ||
            name.endsWith('_leaves') ||
            name.endsWith('_roots') ||
            name === 'mangrove_roots'
        );
    }

    _isProtectedUtilityBlock(name) {
        return (
            name === 'crafting_table' ||
            name === 'furnace' ||
            name === 'chest' ||
            name === 'barrel' ||
            name.includes('bed') ||
            name.includes('door')
        );
    }

    async _eatFood() {
        const foodItems = this.bot.inventory.items().filter(item => 
            item.name.includes('apple') || 
            item.name.includes('bread') || 
            item.name.includes('cooked') ||
            item.name.includes('steak') ||
            item.name.includes('porkchop')
        );
        
        if (foodItems.length === 0) {
            return { success: false, message: 'No food available' };
        }
        
        try {
            await this.bot.equip(foodItems[0], 'hand');
            await this.bot.consume();
            return { success: true, message: `Ate ${foodItems[0].name}` };
        } catch (error) {
            return { success: false, message: `Failed to eat: ${error.message}` };
        }
    }

    async _explore() {
        const { pathfinder, Movements } = require('mineflayer-pathfinder');
        const mcData = require('minecraft-data')(this.bot.version);

        // Random direction, shorter distance to avoid wandering into ocean
        const angle = Math.random() * 2 * Math.PI;
        const distance = 15 + Math.random() * 20;

        const targetX = this.bot.entity.position.x + Math.cos(angle) * distance;
        const targetZ = this.bot.entity.position.z + Math.sin(angle) * distance;

        const goal = new GoalNear(targetX, this.bot.entity.position.y, targetZ, 5);

        try {
            const safeMove = new Movements(this.bot, mcData);
            safeMove.canSwim = false;          // never enter water voluntarily
            safeMove.allowSprinting = true;
            this.bot.pathfinder.setMovements(safeMove);
            await this.bot.pathfinder.goto(goal);
            return { success: true, message: `Explored to ${targetX.toFixed(0)}, ${targetZ.toFixed(0)}` };
        } catch (error) {
            return { success: false, message: `Exploration failed: ${error.message}` };
        }
    }

    async _clearJunk() {
        // Items worthless to the tech-tree that pile up during descent
        const junkNames = [
            'cobblestone', 'gravel', 'dirt', 'sand', 'andesite',
            'diorite', 'granite', 'tuff', 'calcite', 'deepslate',
            'cobbled_deepslate', 'stone', 'flint', 'clay_ball',
            'sandstone', 'netherrack'
        ];

        let dropped = 0;
        for (const item of this.bot.inventory.items()) {
            if (junkNames.some(j => item.name === j || item.name.includes(j))) {
                try {
                    await this.bot.toss(item.type, null, item.count);
                    dropped += item.count;
                } catch (_) { /* ignore toss errors */ }
            }
        }

        if (dropped === 0) {
            return { success: false, message: 'No junk items to drop' };
        }
        return { success: true, message: `Dropped ${dropped} junk items, freed inventory space` };
    }

    async _digToY(targetY) {
        const mcData = require('minecraft-data')(this.bot.version);

        const digMove = this._createNoScaffoldMovements(mcData, false);
        digMove.allowSprinting = false;
        this.bot.pathfinder.setMovements(digMove);

        try {
            const initialDiamond = this._findVisibleDiamondOre(DIAMOND_SCAN_RADIUS);
            if (initialDiamond) {
                return {
                    success: true,
                    message: `Diamond ore spotted at ${initialDiamond.position}; stopping descent early at Y=${Math.floor(this.bot.entity.position.y)}`
                };
            }

            const stableStart = await this._moveToStableMiningStart('before diamond descent');
            if (!stableStart.success) {
                return stableStart;
            }

            const hardDeadline = Date.now() + this._timeoutMs(720_000);
            let lastProgressTime = Date.now();
            let lastY = Math.floor(this.bot.entity.position.y);
            let lastPos = this.bot.entity.position.clone();
            let carvedSteps = 0;
            let stairRecoveryAttempts = 0;

            while (Math.floor(this.bot.entity.position.y) > targetY) {
                const visibleDiamond = this._findVisibleDiamondOre(DIAMOND_SCAN_RADIUS);
                if (visibleDiamond) {
                    return {
                        success: true,
                        message: `Diamond ore spotted at ${visibleDiamond.position}; stopping descent early at Y=${Math.floor(this.bot.entity.position.y)} after ${carvedSteps} step(s)`
                    };
                }

                const now = Date.now();
                const currentY = Math.floor(this.bot.entity.position.y);
                const movedDistance = this.bot.entity.position.distanceTo(lastPos);

                if (currentY < lastY || movedDistance >= 1.0) {
                    lastProgressTime = now;
                    lastY = currentY;
                    lastPos = this.bot.entity.position.clone();
                }

                if (now > hardDeadline) {
                    return { success: false, message: `_digToY hard timeout at Y=${currentY}, steps=${carvedSteps}` };
                }

                if (now - lastProgressTime > this._timeoutMs(75_000)) {
                    return { success: false, message: `_digToY no progress for 75s at Y=${currentY}, steps=${carvedSteps}` };
                }

                const ready = await this._ensurePickaxeAtLeast('iron', 2);
                if (!ready.success) return ready;

                const moved = await this._carveStairStep(carvedSteps);
                if (!moved.success) {
                    if (stairRecoveryAttempts < 4) {
                        const recovery = await this._recoverStairDescentStart(moved.message, stairRecoveryAttempts);
                        if (recovery.success) {
                            stairRecoveryAttempts++;
                            lastProgressTime = Date.now();
                            lastY = Math.floor(this.bot.entity.position.y);
                            lastPos = this.bot.entity.position.clone();
                            console.log(`[StairDig] ${recovery.message}`);
                            continue;
                        }
                    }
                    return moved;
                }
                stairRecoveryAttempts = 0;
                carvedSteps++;

                const afterMoveDiamond = this._findVisibleDiamondOre(DIAMOND_SCAN_RADIUS);
                if (afterMoveDiamond) {
                    return {
                        success: true,
                        message: `Diamond ore spotted at ${afterMoveDiamond.position}; stopping descent early at Y=${Math.floor(this.bot.entity.position.y)} after ${carvedSteps} step(s)`
                    };
                }

                const afterY = Math.floor(this.bot.entity.position.y);
                if (afterY < lastY || this.bot.entity.position.distanceTo(lastPos) >= 1.0) {
                    lastProgressTime = Date.now();
                    lastY = afterY;
                    lastPos = this.bot.entity.position.clone();
                }
            }

            return { success: true, message: `Reached Y=${Math.floor(this.bot.entity.position.y)} by staircase (${carvedSteps} step(s), no scaffolding)` };
        } catch (error) {
            return { success: false, message: `Stair descent failed: ${error.message}` };
        } finally {
            // Always restore safe movement so other skills don't accidentally tunnel
            const safeMove = this._createNoScaffoldMovements(mcData, false);
            this.bot.pathfinder.setMovements(safeMove);
        }
    }

    async _returnToSurface() {
        const mcData = require('minecraft-data')(this.bot.version);

        try {
            const walkMove = this._createNoScaffoldMovements(mcData, false);
            walkMove.allowSprinting = false;
            this.bot.pathfinder.setMovements(walkMove);
            await this._gotoWithTimeout(new GoalY(64), 90_000, 'walking to surface');
            return { success: true, message: `Surfaced at Y=${Math.floor(this.bot.entity.position.y)}` };
        } catch (error) {
            try {
                const digMove = this._createNoScaffoldMovements(mcData, true);
                digMove.allowSprinting = false;
                this.bot.pathfinder.setMovements(digMove);
                await this._gotoWithTimeout(new GoalY(64), 90_000, 'digging blocked staircase to surface');
                return { success: true, message: `Surfaced at Y=${Math.floor(this.bot.entity.position.y)} after clearing blocks` };
            } catch (fallbackError) {
                try {
                    const scaffoldMove = this._createReturnScaffoldMovements(mcData);
                    this.bot.pathfinder.setMovements(scaffoldMove);
                    await this._gotoWithTimeout(new GoalY(64), 120_000, 'scaffold return to surface');
                    return { success: true, message: `Surfaced at Y=${Math.floor(this.bot.entity.position.y)} using emergency scaffold return` };
                } catch (scaffoldError) {
                    const manual = await this._manualPillarToSurface(64);
                    if (manual.success) return manual;
                    return { success: false, message: `Return to surface failed: ${error.message}; fallback=${fallbackError.message}; scaffold=${scaffoldError.message}; manual=${manual.message}` };
                }
            }
        } finally {
            const safeMove = this._createNoScaffoldMovements(mcData, false);
            this.bot.pathfinder.setMovements(safeMove);
        }
    }

    _createNoScaffoldMovements(mcData, canDig = false) {
        const move = new Movements(this.bot, mcData);
        move.canDig = canDig;
        move.canSwim = false;
        move.allow1by1towers = false;
        move.scafoldingBlocks = [];
        return move;
    }

    _createReturnScaffoldMovements(mcData) {
        const move = new Movements(this.bot, mcData);
        move.canDig = true;
        move.canSwim = false;
        move.allowSprinting = false;
        move.allow1by1towers = true;
        move.scafoldingBlocks = this._availableScaffoldItemIds(mcData);
        return move;
    }

    _availableScaffoldItemIds(mcData) {
        const preferred = [
            'dirt', 'cobblestone', 'cobbled_deepslate', 'blackstone',
            'deepslate', 'stone', 'andesite', 'diorite', 'granite',
            'tuff', 'gravel', 'sand'
        ];
        const inventoryNames = new Set(this.bot.inventory.items().map(item => item.name));
        const ids = preferred
            .filter(name => inventoryNames.has(name) && mcData.itemsByName[name])
            .map(name => mcData.itemsByName[name].id);
        if (ids.length > 0) return ids;
        return ['dirt', 'cobblestone']
            .filter(name => mcData.itemsByName[name])
            .map(name => mcData.itemsByName[name].id);
    }

    async _manualPillarToSurface(targetY = 64) {
        let placed = 0;
        let lastError = 'not started';
        const maxBlocks = Math.max(0, targetY - Math.floor(this.bot.entity.position.y) + 4);

        for (let step = 0; step < maxBlocks && Math.floor(this.bot.entity.position.y) < targetY; step++) {
            const beforeY = Math.floor(this.bot.entity.position.y);
            const result = await this._placeBlockUnderSelfReliable();
            if (!result.success) {
                lastError = result.message;
                break;
            }
            placed++;

            const deadline = Date.now() + this._timeoutMs(2500);
            while (Date.now() < deadline && Math.floor(this.bot.entity.position.y) <= beforeY) {
                this.bot.setControlState('jump', true);
                await this._wait(100);
            }
            this.bot.setControlState('jump', false);
            await this._wait(200);
        }

        if (Math.floor(this.bot.entity.position.y) >= targetY) {
            return { success: true, message: `Surfaced at Y=${Math.floor(this.bot.entity.position.y)} using manual pillar (${placed} block(s))` };
        }
        return { success: false, message: `manual pillar failed after ${placed} block(s): ${lastError}` };
    }

    async _placeBlockUnderSelfReliable() {
        const item = this._selectScaffoldItem();
        if (!item) return { success: false, message: 'No scaffold block available' };

        for (let attempt = 1; attempt <= 6; attempt++) {
            const pos = this.bot.entity.position.floored();
            const belowBlock = this.bot.blockAt(pos.offset(0, -1, 0));

            const reference = belowBlock && this._isSolidSupport(belowBlock)
                ? belowBlock
                : this._findAdjacentPlacementReference(pos);
            if (!reference) {
                return { success: false, message: 'No reference block for pillar placement' };
            }

            try {
                await this.bot.equip(item, 'hand');
                await this.bot.lookAt(reference.position.offset(0.5, 1.0, 0.5), true);
                this.bot.setControlState('jump', true);
                await this._wait(120);
                await Promise.race([
                    this.bot.placeBlock(reference, new Vec3(0, 1, 0)),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('pillar place timeout')), this._timeoutMs(2500)))
                ]);
                await this._wait(250);
                this.bot.setControlState('jump', false);

                const newBelow = this.bot.blockAt(this.bot.entity.position.floored().offset(0, -1, 0));
                if (newBelow && this._isSolidSupport(newBelow)) {
                    return { success: true, message: `Placed ${item.name} under self on attempt ${attempt}` };
                }
            } catch (error) {
                this.bot.setControlState('jump', false);
                await this._wait(180 + attempt * 100);
                if (attempt === 6) {
                    return { success: false, message: `${error.message} on pillar attempt ${attempt}` };
                }
            }
        }

        return { success: false, message: 'Pillar placement attempts exhausted' };
    }

    _selectScaffoldItem() {
        const preferred = [
            'dirt', 'cobblestone', 'cobbled_deepslate', 'blackstone',
            'deepslate', 'stone', 'andesite', 'diorite', 'granite',
            'tuff', 'gravel', 'sand'
        ];
        return preferred
            .map(name => this.bot.inventory.items().find(item => item.name === name))
            .find(Boolean) || null;
    }

    _findAdjacentPlacementReference(pos) {
        const offsets = [
            [1, -1, 0], [-1, -1, 0], [0, -1, 1], [0, -1, -1],
            [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]
        ];
        for (const [dx, dy, dz] of offsets) {
            const block = this.bot.blockAt(pos.offset(dx, dy, dz));
            if (block && this._isSolidSupport(block)) return block;
        }
        return null;
    }

    async _gotoWithTimeout(goal, timeoutMs, label) {
        const timeout = new Promise((_, reject) =>
            setTimeout(() => reject(new Error(`${label} timed out`)), this._timeoutMs(timeoutMs))
        );
        return await Promise.race([this.bot.pathfinder.goto(goal), timeout]);
    }

    async _carveStairStep(stepIndex = 0) {
        const directions = this._stairDirections(stepIndex);
        const start = this.bot.entity.position.floored();
        let lastError = 'no valid stair direction';

        for (const dir of directions) {
            const entryHeadPos = start.offset(dir.x, 1, dir.z);
            const targetHeadPos = start.offset(dir.x, 0, dir.z);
            const targetFeetPos = start.offset(dir.x, -1, dir.z);
            const supportPos = start.offset(dir.x, -2, dir.z);

            const entryHeadBlock = this.bot.blockAt(entryHeadPos);
            const targetHeadBlock = this.bot.blockAt(targetHeadPos);
            const targetFeetBlock = this.bot.blockAt(targetFeetPos);
            const supportBlock = this.bot.blockAt(supportPos);
            const caveLanding = this._findSafeCaveLanding(start, dir);
            const supportUnsafe = this._isUnsafeSupportBlock(supportBlock);

            if (
                this._isUnsafeMiningBlock(entryHeadBlock) ||
                this._isUnsafeMiningBlock(targetHeadBlock) ||
                this._isUnsafeMiningBlock(targetFeetBlock) ||
                (supportUnsafe && !caveLanding)
            ) {
                lastError = `unsafe two-block stair target near ${targetFeetPos}`;
                continue;
            }

            const gravityCheckPositions = [
                entryHeadPos,
                targetHeadPos,
                targetFeetPos
            ];
            if (caveLanding) {
                gravityCheckPositions.push(caveLanding.feet, caveLanding.head);
            }

            const gravitySafe = await this._clearGravityHazardsAbove(gravityCheckPositions);
            if (!gravitySafe.success) {
                lastError = gravitySafe.message;
                continue;
            }

            const clearBlocks = [
                { block: entryHeadBlock, label: 'stair entry head clearance' },
                { block: targetHeadBlock, label: 'stair target head' },
                { block: targetFeetBlock, label: 'stair target feet' }
            ];

            let cleared = true;
            for (const item of clearBlocks) {
                const ok = await this._digForStair(item.block, item.label);
                if (!ok) {
                    lastError = `cannot clear ${item.label} ${item.block?.name || 'unknown'} at ${item.block?.position || 'unknown'}`;
                    cleared = false;
                    break;
                }
            }
            if (!cleared) continue;

            const moveFeetPos = caveLanding?.feet || targetFeetPos;
            const moveHeadPos = caveLanding?.head || targetHeadPos;

            if (!this._isBodySpaceClear(moveFeetPos, moveHeadPos)) {
                lastError = `two-block body space still blocked at ${moveFeetPos}/${moveHeadPos}`;
                continue;
            }

            try {
                await this._moveToStairFoot(moveFeetPos);
                if (caveLanding) {
                    return { success: true, message: `Safely dropped ${caveLanding.dropHeight} block(s) into cave at ${moveFeetPos}` };
                }
                return { success: true, message: `Carved two-block stair step to ${targetFeetPos}` };
            } catch (error) {
                lastError = error.message;
                try { this.bot.pathfinder.stop(); } catch (_) {}
            }
        }

        return { success: false, message: `Could not carve safe stair step: ${lastError}` };
    }

    async _recoverStairDescentStart(reason, attempt = 0) {
        await this._escapeLocalObstruction(`recover stair descent: ${reason}`, 2);

        let current = this.bot.entity.position.floored();
        if (this._isStableMiningStart(current, attempt)) {
            return { success: true, message: `Recovered stair descent at current position after clearing blocks` };
        }

        const radius = 6 + attempt * 3;
        const candidates = this._safeStairStartCandidates(current, radius, attempt);
        const mcData = require('minecraft-data')(this.bot.version);
        const move = this._createNoScaffoldMovements(mcData, false);
        move.allowSprinting = false;
        this.bot.pathfinder.setMovements(move);

        for (const candidate of candidates.slice(0, 24)) {
            try {
                await this._gotoWithTimeout(
                    new GoalBlock(candidate.x, candidate.y, candidate.z),
                    9000,
                    'moving to safer stair start'
                );
                current = this.bot.entity.position.floored();
                if (this._isStableMiningStart(current, attempt)) {
                    return {
                        success: true,
                        message: `Moved to safer stair start at ${current} after: ${reason}`
                    };
                }
            } catch (_) {
                try { this.bot.pathfinder.stop(); } catch (__) {}
            }
        }

        return { success: false, message: `No safer stair start found near ${current}: ${reason}` };
    }

    async _moveToStableMiningStart(label = 'mining start') {
        await this._escapeLocalObstruction(label, 2);

        let current = this.bot.entity.position.floored();
        if (this._isStableMiningStart(current, 0)) {
            return { success: true, message: `Stable mining start at ${current}` };
        }

        const candidates = this._safeStairStartCandidates(current, 18, 0);
        const mcData = require('minecraft-data')(this.bot.version);
        const move = this._createNoScaffoldMovements(mcData, false);
        move.allowSprinting = false;
        this.bot.pathfinder.setMovements(move);

        for (const candidate of candidates.slice(0, 36)) {
            try {
                await this._gotoWithTimeout(
                    new GoalBlock(candidate.x, candidate.y, candidate.z),
                    10_000,
                    `moving to stable ${label}`
                );
                current = this.bot.entity.position.floored();
                if (this._isStableMiningStart(current, 0)) {
                    return { success: true, message: `Moved to stable mining start at ${current}` };
                }
            } catch (_) {
                try { this.bot.pathfinder.stop(); } catch (__) {}
            }
        }

        return {
            success: false,
            message: `Could not find stable mining start near ${current}; move bot/player away from trees or cliffs and retry`
        };
    }

    _safeStairStartCandidates(base, maxRadius = 8, stepIndex = 0) {
        const candidates = [];

        for (let radius = 1; radius <= maxRadius; radius++) {
            for (let dy = 1; dy >= -3; dy--) {
                for (let dx = -radius; dx <= radius; dx++) {
                    for (let dz = -radius; dz <= radius; dz++) {
                        if (Math.abs(dx) !== radius && Math.abs(dz) !== radius) continue;

                        const feet = base.offset(dx, dy, dz);
                        if (!this._isStableMiningStart(feet, stepIndex)) continue;

                        const support = this.bot.blockAt(feet.offset(0, -1, 0));
                        const supportPenalty = this._isTreeBlockName(support.name) || support.name.endsWith('_leaves') ? 20 : 0;
                        const slopePenalty = Math.abs(dy) * 2;
                        candidates.push({
                            pos: feet,
                            score: radius + slopePenalty + supportPenalty
                        });
                    }
                }
            }
        }

        return candidates
            .sort((a, b) => a.score - b.score || a.pos.distanceTo(base) - b.pos.distanceTo(base))
            .map(entry => entry.pos);
    }

    _isStableMiningStart(feet, stepIndex = 0) {
        const head = feet.offset(0, 1, 0);
        const support = this.bot.blockAt(feet.offset(0, -1, 0));

        if (!this._isBodySpaceClear(feet, head)) return false;
        if (!support || this._isUnsafeSupportBlock(support) || !this._isSolidSupport(support)) return false;
        if (this._isTreeOrLeafName(support.name)) return false;
        if (this._hasAdjacentTreeObstruction(feet, 1)) return false;
        if (this._sameLevelSolidSupportCount(feet) < 2) return false;
        if (!this._hasSafeStairDirectionAt(feet, stepIndex)) return false;

        return true;
    }

    _sameLevelSolidSupportCount(feet) {
        const offsets = [
            [1, 0], [-1, 0], [0, 1], [0, -1],
            [1, 1], [1, -1], [-1, 1], [-1, -1]
        ];
        let count = 0;
        for (const [dx, dz] of offsets) {
            const support = this.bot.blockAt(feet.offset(dx, -1, dz));
            if (support && this._isSolidSupport(support) && !this._isUnsafeSupportBlock(support) && !this._isTreeOrLeafName(support.name)) {
                count++;
            }
        }
        return count;
    }

    _hasAdjacentTreeObstruction(feet, radius = 1) {
        for (let dy = 0; dy <= 2; dy++) {
            for (let dx = -radius; dx <= radius; dx++) {
                for (let dz = -radius; dz <= radius; dz++) {
                    if (dx === 0 && dz === 0 && dy <= 1) continue;
                    const block = this.bot.blockAt(feet.offset(dx, dy, dz));
                    if (block && this._isTreeOrLeafName(block.name)) return true;
                }
            }
        }
        return false;
    }

    _hasSafeStairDirectionAt(start, stepIndex = 0) {
        for (const dir of this._stairDirections(stepIndex)) {
            if (this._isSafeStairDirection(start, dir)) return true;
        }
        return false;
    }

    _isSafeStairDirection(start, dir) {
        const entryHeadBlock = this.bot.blockAt(start.offset(dir.x, 1, dir.z));
        const targetHeadBlock = this.bot.blockAt(start.offset(dir.x, 0, dir.z));
        const targetFeetBlock = this.bot.blockAt(start.offset(dir.x, -1, dir.z));
        const supportBlock = this.bot.blockAt(start.offset(dir.x, -2, dir.z));
        const caveLanding = this._findSafeCaveLanding(start, dir);

        if (this._isUnsafeMiningBlock(entryHeadBlock)) return false;
        if (this._isUnsafeMiningBlock(targetHeadBlock)) return false;
        if (this._isUnsafeMiningBlock(targetFeetBlock)) return false;
        if (this._isUnsafeSupportBlock(supportBlock) && !caveLanding) return false;
        if (this._hasGravityHazardAbove(start.offset(dir.x, 1, dir.z))) return false;
        if (this._hasGravityHazardAbove(start.offset(dir.x, 0, dir.z))) return false;
        if (this._hasGravityHazardAbove(start.offset(dir.x, -1, dir.z))) return false;

        return true;
    }

    _findSafeCaveLanding(start, dir) {
        for (let dropHeight = 2; dropHeight <= SAFE_CAVE_DROP_HEIGHT; dropHeight++) {
            if (dropHeight > 3 && this.bot.health <= 8) return null;

            const feet = start.offset(dir.x, -dropHeight, dir.z);
            const head = feet.offset(0, 1, 0);
            const support = feet.offset(0, -1, 0);
            const feetBlock = this.bot.blockAt(feet);
            const headBlock = this.bot.blockAt(head);
            const supportBlock = this.bot.blockAt(support);

            if (!this._isPassableBodyBlock(feetBlock) || !this._isPassableBodyBlock(headBlock)) continue;
            if (this._isUnsafeSupportBlock(supportBlock)) continue;

            return { feet, head, support, dropHeight };
        }
        return null;
    }

    _findVisibleDiamondOre(maxDistance = DIAMOND_SCAN_RADIUS) {
        return this.bot.findBlock({
            matching: block => DIAMOND_ORE_BLOCKS.includes(block.name),
            maxDistance
        });
    }

    _stairDirections(stepIndex = 0) {
        const yaw = this.bot.entity?.yaw || 0;
        const look = { x: -Math.sin(yaw), z: -Math.cos(yaw) };
        const base = [
            { x: 1, z: 0 },
            { x: -1, z: 0 },
            { x: 0, z: 1 },
            { x: 0, z: -1 }
        ].sort((a, b) => (b.x * look.x + b.z * look.z) - (a.x * look.x + a.z * look.z));

        // Keep the primary direction stable, but rotate alternatives so lava or
        // bedrock pockets do not trap the descent.
        const alternatives = base.slice(1);
        const rotateBy = alternatives.length > 0 ? stepIndex % alternatives.length : 0;
        return [base[0], ...alternatives.slice(rotateBy), ...alternatives.slice(0, rotateBy)];
    }

    async _digForStair(block, label) {
        if (!block || this._isReplaceableBlock(block)) return true;
        if (this._isUnsafeMiningBlock(block)) return false;
        if (!block.diggable || block.name === 'bedrock') return false;

        const toolReady = await this._prepareDigTool(block, label);
        if (!toolReady.success) {
            console.log(`[StairDig] ${toolReady.message}`);
            return false;
        }
        await this.bot.lookAt(block.position.offset(0.5, 0.5, 0.5), true);
        await this._wait(100);

        if (!this.bot.canDigBlock(block)) {
            console.log(`[StairDig] Cannot dig ${block.name} (${label}) at ${block.position}`);
            return false;
        }

        try {
            await this.bot.dig(block, true);
            await this._wait(180);
            await this._escapeSuffocationBlocks();
            return true;
        } catch (error) {
            console.log(`[StairDig] Failed to dig ${block.name} (${label}): ${error.message}`);
            await this._escapeSuffocationBlocks();
            return false;
        }
    }

    async _moveToStairFoot(footPos) {
        const mcData = require('minecraft-data')(this.bot.version);
        const move = this._createNoScaffoldMovements(mcData, false);
        move.allowSprinting = false;
        this.bot.pathfinder.setMovements(move);

        await this._gotoWithTimeout(new GoalBlock(footPos.x, footPos.y, footPos.z), 10_000, 'moving to stair step');

        const current = this.bot.entity.position.floored();
        if (current.distanceTo(footPos) > 1.5) {
            throw new Error(`stair step not reached; now at ${current}, target ${footPos}`);
        }
    }

    _isBodySpaceClear(feetPos, headPos) {
        const feetBlock = this.bot.blockAt(feetPos);
        const headBlock = this.bot.blockAt(headPos);
        return this._isPassableBodyBlock(feetBlock) && this._isPassableBodyBlock(headBlock);
    }

    _isPassableBodyBlock(block) {
        if (!block) return false;
        if (this._isUnsafeMiningBlock(block)) return false;
        return this._isReplaceableBlock(block) || block.boundingBox === 'empty';
    }

    _hasGravityHazardAbove(pos, maxHeight = 4) {
        for (let dy = 1; dy <= maxHeight; dy++) {
            const block = this.bot.blockAt(pos.offset(0, dy, 0));
            if (this._isGravityBlock(block)) return true;
        }
        return false;
    }

    async _clearGravityHazardsAbove(positions, maxHeight = 4) {
        for (let pass = 0; pass < 4; pass++) {
            let clearedAny = false;

            for (const pos of positions) {
                for (let dy = 1; dy <= maxHeight; dy++) {
                    const block = this.bot.blockAt(pos.offset(0, dy, 0));
                    if (!this._isGravityBlock(block)) continue;
                    if (!block.diggable || !this.bot.canDigBlock(block)) {
                        return { success: false, message: `gravity block ${block.name} above ${pos} is not safely reachable` };
                    }

                    try {
                        const toolReady = await this._prepareDigTool(block, 'gravity hazard');
                        if (!toolReady.success) {
                            return { success: false, message: toolReady.message };
                        }
                        await this.bot.lookAt(block.position.offset(0.5, 0.5, 0.5), true);
                        console.log(`[Safety] Clearing gravity hazard ${block.name} at ${block.position}`);
                        await this.bot.dig(block, true);
                        await this._wait(350);
                        await this._escapeSuffocationBlocks();
                        clearedAny = true;
                    } catch (error) {
                        return { success: false, message: `failed clearing gravity block ${block.name}: ${error.message}` };
                    }
                }
            }

            if (!clearedAny) {
                return { success: true, message: 'no gravity hazards above stair path' };
            }
        }

        return { success: false, message: 'gravity hazard did not stabilize after clearing attempts' };
    }

    _isGravityBlock(block) {
        if (!block) return false;
        return GRAVITY_BLOCKS.some(name => block.name === name || block.name.endsWith(`_${name}`));
    }

    async _escapeSuffocationBlocks() {
        const pos = this.bot.entity.position.floored();
        const checks = [
            pos,
            pos.offset(0, 1, 0),
            pos.offset(0, 2, 0),
            pos.offset(1, 1, 0),
            pos.offset(-1, 1, 0),
            pos.offset(0, 1, 1),
            pos.offset(0, 1, -1)
        ];

        for (const checkPos of checks) {
            const block = this.bot.blockAt(checkPos);
            if (!this._isGravityBlock(block)) continue;
            if (!block.diggable) continue;

            try {
                await this._equipBestTool(block, null, 1);
                await this.bot.lookAt(block.position.offset(0.5, 0.5, 0.5), true);
                if (this.bot.canDigBlock(block)) {
                    console.log(`[Safety] Clearing suffocation gravity block ${block.name} at ${block.position}`);
                    await this.bot.dig(block, true);
                    await this._wait(150);
                }
            } catch (error) {
                console.log(`[Safety] Failed to clear ${block.name}: ${error.message}`);
            }
        }
    }

    _isUnsafeMiningBlock(block) {
        if (!block) return true;
        if (['lava', 'water', 'bedrock'].includes(block.name)) return true;
        if (block.name.includes('lava') || block.name.includes('water')) return true;
        return false;
    }

    _isUnsafeSupportBlock(block) {
        if (!block) return true;
        if (this._isUnsafeMiningBlock(block)) return true;
        return block.boundingBox !== 'block';
    }

    async _smeltIron(targetIngots = 3) {
        while (this._countItem('iron_ingot') < targetIngots) {
            const inputItem = SMELTABLE_IRON_ITEMS.find(name => this._hasItem(name));
            if (!inputItem) {
                return {
                    success: false,
                    message: `Need ${targetIngots} iron ingot(s), have ${this._countItem('iron_ingot')}; no smeltable iron left`
                };
            }

            const needed = targetIngots - this._countItem('iron_ingot');
            const result = await this._smeltItem(inputItem, 'iron_ingot', needed);
            if (!result.success) return result;
            await this._wait(300);
        }

        return { success: true, message: `Smelted iron, now have ${this._countItem('iron_ingot')} iron ingot(s)` };
    }

    async _smeltItem(inputItem, outputItem, desiredOutputCount = 1) {
        // Step 1: Find an existing furnace in the world
        let furnaceBlock = this.bot.findBlock({
            matching: b => b.name === 'furnace',
            maxDistance: 32
        });

        // Step 2: If no furnace in world, craft one and place it
        if (!furnaceBlock) {
            if (!this._hasItem('furnace')) {
                // Craft from cobblestone
                const craftResult = await this._craftWithTable('furnace', 1);
                if (!craftResult.success) {
                    return { success: false, message: `Could not craft furnace: ${craftResult.message}` };
                }
            }
            // Place furnace next to bot
            const placeResult = await this._placeBlock('furnace');
            if (!placeResult.success) {
                return { success: false, message: `Could not place furnace: ${placeResult.message}` };
            }
            await this._wait(300); // let block appear in world
            furnaceBlock = this.bot.findBlock({
                matching: b => b.name === 'furnace',
                maxDistance: 8
            });
            if (!furnaceBlock) {
                return { success: false, message: 'Placed furnace but could not locate it' };
            }
        }

        // Step 3: Walk up to the furnace
        await this._goTo(furnaceBlock.position);

        // Step 4: Check we still have the input item
        const inputObj = this.bot.inventory.items().find(i => i.name === inputItem);
        if (!inputObj) {
            return { success: false, message: `No ${inputItem} in inventory` };
        }

        // Step 5: Ensure enough fuel for this batch before opening the furnace.
        const desiredInputCount = Math.max(1, Math.min(inputObj.count, 8, desiredOutputCount));
        const fuelReady = await this._ensureSmeltingFuel(desiredInputCount);
        if (!fuelReady.success) return fuelReady;

        const fuelBatch = this._selectFuelBatch(desiredInputCount);
        if (!fuelBatch) {
            return { success: false, message: `No usable fuel for ${desiredInputCount} smelt(s)` };
        }

        let furnace = null;
        try {
            furnace = await this._openFurnaceReliable(furnaceBlock);

            // Load only enough fuel for the requested batch.
            const inputCount = Math.max(1, Math.min(desiredInputCount, fuelBatch.capacity));
            await furnace.putFuel(fuelBatch.item.type, null, fuelBatch.count);
            await furnace.putInput(inputObj.type, null, inputCount);

            // Wait until the requested batch is done, not just the first ingot.
            await new Promise((resolve, reject) => {
                const deadline = setTimeout(() => {
                    reject(new Error(`Smelting timed out after ${Math.round(this._timeoutMs(45000) / 1000)} s`));
                }, this._timeoutMs(45000));

                const poll = setInterval(() => {
                    const output = furnace.outputItem();
                    if (output && output.count >= inputCount) {
                        clearInterval(poll);
                        clearTimeout(deadline);
                        resolve();
                    }
                }, 500);
            });

            // Collect finished ingots
            await furnace.takeOutput();
            furnace.close();

            return {
                success: true,
                message: `Smelted ${inputCount} ${inputItem} -> ${outputItem} using ${fuelBatch.count} ${fuelBatch.item.name}`
            };
        } catch (error) {
            try { furnace?.close(); } catch (_) {}
            return { success: false, message: `Smelting failed: ${error.message}` };
        }
    }

    async _openFurnaceReliable(furnaceBlock, attempts = 3) {
        let lastError = 'not attempted';
        for (let attempt = 1; attempt <= attempts; attempt++) {
            try {
                try { this.bot.pathfinder.stop(); } catch (_) {}
                await this._goTo(furnaceBlock.position);
                await this.bot.lookAt(furnaceBlock.position.offset(0.5, 0.5, 0.5), true);
                await this._wait(500 + attempt * 400);
                return await this.bot.openFurnace(furnaceBlock);
            } catch (error) {
                lastError = error.message;
                console.log(`[Smelt] openFurnace attempt ${attempt}/${attempts} failed: ${lastError}`);
                try { this.bot.closeWindow(this.bot.currentWindow); } catch (_) {}
                try { this.bot.pathfinder.stop(); } catch (_) {}
                await this._wait(this._timeoutMs(1200 + attempt * 600));
            }
        }
        throw new Error(`Could not open furnace after ${attempts} attempts: ${lastError}`);
    }

    // ==================== Helper Methods ====================

    async _goTo(position) {
        const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');
        const mcData = require('minecraft-data')(this.bot.version);

        const safeMove = new Movements(this.bot, mcData);
        safeMove.canSwim = false;   // never route through water
        this.bot.pathfinder.setMovements(safeMove);

        const goal = new goals.GoalNear(position.x, position.y, position.z, 2);
        await this.bot.pathfinder.goto(goal);
    }

    async _findResourceWithExploration(matching, label) {
        for (let attempt = 0; attempt < RESOURCE_SEARCH_ATTEMPTS; attempt++) {
            for (const radius of RESOURCE_SEARCH_RADII) {
                const block = this.bot.findBlock({ matching, maxDistance: radius });
                if (block) {
                    if (attempt > 0) {
                        console.log(`[ResourceSearch] Found ${label} within ${radius} blocks after ${attempt} exploration move(s)`);
                    }
                    return block;
                }
            }

            const step = attempt + 1;
            if (step === 1 || step % 4 === 0) {
                const message = `Searching farther for ${label} (${step}/${RESOURCE_SEARCH_ATTEMPTS})`;
                console.log(`[ResourceSearch] ${message}`);
                try { this.bot.chat(message); } catch (_) {}
            }

            await this._exploreForResource(attempt);
        }

        return null;
    }

    async _digBlockSafely(block, label = 'block', attempts = 4) {
        for (let attempt = 1; attempt <= attempts; attempt++) {
            try {
                try { this.bot.pathfinder.stop(); } catch (_) {}

                const beforeMove = this.bot.blockAt(block.position);
                if (!beforeMove || beforeMove.name === 'air') return true;

                await this._goTo(beforeMove.position);

                const current = this.bot.blockAt(block.position);
                if (!current || current.name === 'air') return true;

                const portableUtility = label.includes('portable crafting_table') || label.includes('portable furnace');
                const toolReady = portableUtility
                    ? { success: true, message: 'portable utility block can be recovered by hand' }
                    : await this._prepareDigTool(current, label);
                if (!toolReady.success) {
                    console.log(`[Dig] ${toolReady.message}`);
                    return false;
                }

                await this.bot.lookAt(current.position.offset(0.5, 0.5, 0.5), true);
                await this._wait(150);

                if (!this.bot.canDigBlock(current)) {
                    const distance = this.bot.entity.position.distanceTo(current.position).toFixed(2);
                    console.log(`[Dig] Cannot dig ${current.name} (${label}) after moving; distance=${distance} at ${current.position}`);
                    return false;
                }

                await this.bot.dig(current, true);
                await this._wait(250);
                await this._escapeSuffocationBlocks();
                return true;
            } catch (error) {
                console.log(`[Dig] ${label} attempt ${attempt}/${attempts} failed: ${error.message}`);
                try { this.bot.pathfinder.stop(); } catch (_) {}
                await this._escapeSuffocationBlocks();
                await this._wait(350 + attempt * 150);

                const refreshed = this.bot.blockAt(block.position);
                if (!refreshed || refreshed.name === 'air') return true;
                block = refreshed;
            }
        }
        return false;
    }

    async _exploreForResource(attempt) {
        const mcData = require('minecraft-data')(this.bot.version);
        const move = new Movements(this.bot, mcData);
        move.canSwim = false;
        move.canDig = false;
        move.allowSprinting = true;
        this.bot.pathfinder.setMovements(move);

        const pos = this.bot.entity.position;
        const angle = attempt * Math.PI * 0.5 + (attempt % 2) * Math.PI * 0.25;
        const distance = Math.min(80, 24 + attempt * 6);
        const targetX = pos.x + Math.cos(angle) * distance;
        const targetZ = pos.z + Math.sin(angle) * distance;
        const goal = new GoalNear(targetX, pos.y, targetZ, 8);

        const timeout = new Promise((_, reject) =>
            setTimeout(() => reject(new Error('resource exploration timed out')), this._timeoutMs(20_000))
        );

        try {
            await Promise.race([this.bot.pathfinder.goto(goal), timeout]);
            return true;
        } catch (error) {
            console.log(`[ResourceSearch] Exploration move skipped: ${error.message}`);
            try { this.bot.pathfinder.stop(); } catch (_) {}
            await this._wait(500);
            return false;
        }
    }

    async _prepareDigTool(block, label = 'block') {
        const requiredTier = this._requiredPickaxeTierForBlock(block);
        await this._equipBestTool(block, requiredTier, 1);

        if (requiredTier) {
            const held = this.bot.heldItem;
            if (
                held &&
                held.name.endsWith('_pickaxe') &&
                this._pickaxeTierIndex(held.name) >= this._pickaxeTierIndex(requiredTier) &&
                this._toolRemainingUses(held) >= 1
            ) {
                return { success: true, message: `Using ${held.name} for ${label}` };
            }
            return { success: false, message: `Need ${requiredTier}+ pickaxe for ${block?.name || label}` };
        }

        if (this._isHandDigAllowed(block)) {
            return { success: true, message: `Hand dig allowed for ${block?.name || label}` };
        }

        const held = this.bot.heldItem;
        if (held && this._isToolItem(held.name)) {
            return { success: true, message: `Using ${held.name} for ${label}` };
        }

        return { success: false, message: `Refusing bare-hand dig for ${block?.name || label}; tool required` };
    }

    async _equipBestTool(block, minimumPickaxeTier = null, minUses = 1) {
        if (minimumPickaxeTier) {
            const pickaxe = this._bestUsablePickaxeAtLeast(minimumPickaxeTier, minUses);
            if (pickaxe) {
                try {
                    await this.bot.equip(pickaxe, 'hand');
                    return;
                } catch (_) {}
            }
        }

        try {
            await this.bot.tool.equipForBlock(block);
        } catch (error) {
            // Ignore - will use hand if no tool available
        }
    }

    _requiredPickaxeTierForBlock(block) {
        if (!block) return null;
        const name = block.name;
        if (['diamond_ore', 'deepslate_diamond_ore', 'redstone_ore', 'deepslate_redstone_ore', 'gold_ore', 'deepslate_gold_ore'].includes(name)) {
            return 'iron';
        }
        if (['iron_ore', 'deepslate_iron_ore', 'copper_ore', 'deepslate_copper_ore', 'lapis_ore', 'deepslate_lapis_ore'].includes(name)) {
            return 'stone';
        }
        if (
            name.includes('stone') ||
            name.includes('deepslate') ||
            name.includes('cobble') ||
            name.includes('blackstone') ||
            ['andesite', 'diorite', 'granite', 'tuff', 'calcite', 'coal_ore', 'deepslate_coal_ore'].includes(name)
        ) {
            return 'wooden';
        }
        return null;
    }

    _isHandDigAllowed(block) {
        if (!block) return false;
        return HAND_DIG_ALLOWED_BLOCKS.includes(block.name);
    }

    _isToolItem(itemName) {
        return (
            itemName.endsWith('_pickaxe') ||
            itemName.endsWith('_axe') ||
            itemName.endsWith('_shovel') ||
            itemName.endsWith('_hoe') ||
            itemName.endsWith('_sword') ||
            itemName === 'shears'
        );
    }

    _wait(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    _timeoutMs(ms) {
        return Math.ceil(ms * TIMEOUT_MULTIPLIER);
    }

    _isReplaceableBlock(block) {
        if (!block) return false;
        const replaceable = [
            'air', 'cave_air', 'void_air', 'snow', 'grass', 'short_grass',
            'tall_grass', 'fern', 'large_fern', 'dead_bush'
        ];
        return replaceable.includes(block.name);
    }

    _isSolidSupport(block) {
        if (!block) return false;
        if (['air', 'cave_air', 'void_air', 'water', 'lava', 'snow'].includes(block.name)) return false;
        return block.boundingBox === 'block';
    }

    async _pickupNearbyDrops(pattern, targetCount, timeoutMs = 3000) {
        const deadline = Date.now() + this._timeoutMs(timeoutMs);
        while (Date.now() < deadline) {
            if (this._countItemLike(pattern) >= targetCount) return true;

            const pos = this.bot.entity.position;
            const drop = this.bot.nearestEntity(entity =>
                entity.position &&
                entity.position.distanceTo(pos) <= 8 &&
                (entity.name === 'item' || entity.displayName === 'Item')
            );

            if (drop) {
                try {
                    await this._goTo(drop.position);
                } catch (_) {
                    // If pathing to the exact item fails, waiting often still lets
                    // vanilla pickup collect nearby drops.
                }
            }

            await this._wait(250);
        }
        return this._countItemLike(pattern) >= targetCount;
    }

    async _pickupNearbyCobble(targetCount, timeoutMs = 3000) {
        const deadline = Date.now() + this._timeoutMs(timeoutMs);
        while (Date.now() < deadline) {
            if (this._countCobbleMaterials() >= targetCount) return true;

            const pos = this.bot.entity.position;
            const drop = this.bot.nearestEntity(entity =>
                entity.position &&
                entity.position.distanceTo(pos) <= 8 &&
                (entity.name === 'item' || entity.displayName === 'Item')
            );

            if (drop) {
                try {
                    await this._goTo(drop.position);
                } catch (_) {}
            }

            await this._wait(250);
        }
        return this._countCobbleMaterials() >= targetCount;
    }

    async _pickupNearbySmeltableIron(targetCount, timeoutMs = 5000) {
        const deadline = Date.now() + this._timeoutMs(timeoutMs);
        while (Date.now() < deadline) {
            if (this._countSmeltableIron() >= targetCount) return true;

            const pos = this.bot.entity.position;
            const drop = this.bot.nearestEntity(entity =>
                entity.position &&
                entity.position.distanceTo(pos) <= 8 &&
                (entity.name === 'item' || entity.displayName === 'Item')
            );

            if (drop) {
                try {
                    await this._goTo(drop.position);
                } catch (_) {}
            }

            await this._wait(250);
        }
        return this._countSmeltableIron() >= targetCount;
    }

    async _pickupNearbyItem(itemName, targetCount, timeoutMs = 5000) {
        const deadline = Date.now() + this._timeoutMs(timeoutMs);
        while (Date.now() < deadline) {
            if (this._countItem(itemName) >= targetCount) return true;

            const pos = this.bot.entity.position;
            const drop = this.bot.nearestEntity(entity =>
                entity.position &&
                entity.position.distanceTo(pos) <= 8 &&
                (entity.name === 'item' || entity.displayName === 'Item')
            );

            if (drop) {
                try {
                    await this._goTo(drop.position);
                } catch (_) {}
            }

            await this._wait(250);
        }
        return this._countItem(itemName) >= targetCount;
    }

    _nearestItemDrop(maxDistance = 8) {
        const pos = this.bot.entity.position;
        return this.bot.nearestEntity(entity =>
            entity.position &&
            entity.position.distanceTo(pos) <= maxDistance &&
            (entity.name === 'item' || entity.displayName === 'Item')
        );
    }

    async _ensureSmeltingFuel(requiredSmelts) {
        if (this._countItem('stick') < RESERVED_STICKS_FOR_TOOLS) {
            const sticks = await this._ensureWoodSupplies(RESERVED_PLANKS_FOR_TOOLS, RESERVED_STICKS_FOR_TOOLS);
            if (!sticks.success) return sticks;
        }

        // Logs are valid fuel, but crafting them into planks gives much more
        // total burn time. Convert logs first unless coal/charcoal already cover it.
        if (this._availableFuelCapacity({ excludeLogs: true }) < requiredSmelts && this._hasItemLike('_log')) {
            const planks = await this._craftPlanksFromLogs();
            if (!planks.success && this._availableFuelCapacity() < requiredSmelts) {
                return { success: false, message: `Could not prepare plank fuel: ${planks.message}` };
            }
        }

        for (let attempt = 0; attempt < 3 && this._availableFuelCapacity() < requiredSmelts; attempt++) {
            const wood = await this._harvestWood(3);
            if (!wood.success && this._availableFuelCapacity() < requiredSmelts) {
                return { success: false, message: `Not enough fuel and wood collection failed: ${wood.message}` };
            }
            if (this._hasItemLike('_log')) {
                await this._craftPlanksFromLogs();
            }
        }

        const capacity = this._availableFuelCapacity();
        if (capacity < requiredSmelts) {
            return {
                success: false,
                message: `Fuel too low: capacity=${capacity.toFixed(1)}, required=${requiredSmelts}`
            };
        }

        return { success: true, message: `Fuel ready: capacity=${capacity.toFixed(1)}` };
    }

    _availableFuelCapacity(options = {}) {
        return this._fuelCandidates(options)
            .reduce((sum, candidate) => sum + candidate.usableCount * candidate.value, 0);
    }

    _selectFuelBatch(requiredSmelts) {
        const candidates = this._fuelCandidates();
        const batches = [];

        for (const candidate of candidates) {
            const count = Math.min(candidate.usableCount, Math.ceil(requiredSmelts / candidate.value));
            const capacity = Math.floor(count * candidate.value);
            if (count <= 0 || capacity <= 0) continue;

            batches.push({
                ...candidate,
                count,
                capacity,
                overburn: (count * candidate.value) - requiredSmelts
            });
        }

        if (batches.length === 0) return null;

        batches.sort((a, b) => {
            const completesDiff = (b.capacity >= requiredSmelts) - (a.capacity >= requiredSmelts);
            if (completesDiff !== 0) return completesDiff;
            if (a.overburn !== b.overburn) return a.overburn - b.overburn;
            return a.priority - b.priority;
        });

        return batches[0];
    }

    _fuelCandidates(options = {}) {
        const candidates = [];
        for (const item of this.bot.inventory.items()) {
            if (options.excludeLogs && this._isLogItem(item.name)) continue;

            const value = this._fuelSmeltValue(item.name);
            if (value <= 0) continue;

            const reserve = this._fuelReserveCount(item.name);
            const usableCount = Math.max(0, item.count - reserve);
            if (usableCount <= 0) continue;

            candidates.push({
                item,
                value,
                usableCount,
                priority: this._fuelPriority(item.name)
            });
        }
        return candidates;
    }

    _fuelSmeltValue(itemName) {
        if (itemName === 'coal_block') return 80;
        if (itemName === 'lava_bucket') return 100;
        if (itemName === 'dried_kelp_block') return 20;
        if (itemName === 'blaze_rod') return 12;
        if (itemName === 'coal' || itemName === 'charcoal') return 8;
        if (itemName.includes('_planks') || this._isLogItem(itemName) || itemName.endsWith('_wood') || itemName.endsWith('_stem') || itemName.endsWith('_hyphae')) return 1.5;
        if (itemName === 'stick' || itemName.endsWith('_sapling')) return 0.5;
        return 0;
    }

    _fuelReserveCount(itemName) {
        if (itemName === 'stick') return RESERVED_STICKS_FOR_TOOLS;
        if (itemName.includes('_planks')) return RESERVED_PLANKS_FOR_TOOLS;
        return 0;
    }

    _fuelPriority(itemName) {
        if (itemName === 'coal' || itemName === 'charcoal') return 0;
        if (itemName.includes('_planks')) return 1;
        if (this._isLogItem(itemName) || itemName.endsWith('_wood') || itemName.endsWith('_stem') || itemName.endsWith('_hyphae')) return 2;
        if (itemName === 'stick' || itemName.endsWith('_sapling')) return 3;
        return 4;
    }

    _isLogItem(itemName) {
        return LOG_TYPES.includes(itemName) || itemName.endsWith('_log');
    }

    async _ensurePickaxeAtLeast(tier, minUses = TOOL_SAFETY_USES) {
        const existing = this._bestUsablePickaxeAtLeast(tier, minUses);
        if (existing) {
            try { await this.bot.equip(existing, 'hand'); } catch (_) {}
            return { success: true, message: `Usable ${existing.name} ready (${this._toolRemainingUses(existing)} uses left)` };
        }

        if (tier === 'wooden') {
            const supplies = await this._ensureWoodSupplies(8, 2);
            if (!supplies.success) return supplies;

            const table = await this._ensureCraftingTableReady();
            if (!table.success) return table;

            if (!this._canCraftWoodenPickaxe()) {
                return { success: false, message: 'Cannot craft replacement wooden pickaxe' };
            }
            return await this._craftWithTable('wooden_pickaxe', 1);
        }

        if (tier === 'stone') {
            const woodPickaxe = await this._ensurePickaxeAtLeast('wooden', Math.max(3, minUses));
            if (!woodPickaxe.success) return woodPickaxe;

            while (this._countCobbleMaterials() < 3) {
                const needed = 3 - this._countCobbleMaterials();
                const cobble = await this._mineStoneForCobble(needed);
                if (!cobble.success && this._countCobbleMaterials() < 3) {
                    return { success: false, message: `Cannot collect cobble for replacement stone pickaxe: ${cobble.message}` };
                }
            }

            const supplies = await this._ensureWoodSupplies(3, 2);
            if (!supplies.success) return supplies;

            const table = await this._ensureCraftingTableReady();
            if (!table.success) return table;

            if (!this._canCraftStonePickaxe()) {
                return { success: false, message: 'Cannot craft replacement stone pickaxe' };
            }
            return await this._craftWithTable('stone_pickaxe', 1);
        }

        if (tier === 'iron') {
            const stonePickaxe = await this._ensurePickaxeAtLeast('stone', Math.max(3, minUses));
            if (!stonePickaxe.success) return stonePickaxe;

            while (this._countItem('iron_ingot') + this._countSmeltableIron() < 3) {
                const neededIron = 3 - (this._countItem('iron_ingot') + this._countSmeltableIron());
                const mined = await this._mineIron(neededIron);
                if (!mined.success && this._countItem('iron_ingot') + this._countSmeltableIron() < 3) {
                    return { success: false, message: `Cannot collect iron for replacement iron pickaxe: ${mined.message}` };
                }
            }

            if (this._countItem('iron_ingot') < 3) {
                const smelted = await this._smeltIron(3);
                if (!smelted.success && this._countItem('iron_ingot') < 3) {
                    return { success: false, message: `Cannot smelt iron for replacement iron pickaxe: ${smelted.message}` };
                }
            }

            const supplies = await this._ensureWoodSupplies(0, 2);
            if (!supplies.success) return supplies;

            const table = await this._ensureCraftingTableReady();
            if (!table.success) return table;

            if (this._countItem('iron_ingot') < 3) {
                return { success: false, message: 'Need 3 iron ingots for replacement iron pickaxe' };
            }
            return await this._craftWithTable('iron_pickaxe', 1);
        }

        return { success: false, message: `No replacement recipe implemented for ${tier} pickaxe` };
    }

    async _ensureWoodSupplies(minPlanks = 0, minSticks = 0) {
        const neededPlanks = Math.max(minPlanks, minSticks > 0 ? 2 : 0);

        for (let attempt = 0; attempt < 3 && this._countItemLike('_planks') < neededPlanks; attempt++) {
            if (!this._hasItemLike('_log')) {
                const wood = await this._harvestWood(3);
                if (!wood.success && !this._hasItemLike('_log')) {
                    return { success: false, message: `Cannot collect wood supplies: ${wood.message}` };
                }
            }

            if (this._hasItemLike('_log')) {
                const planks = await this._craftPlanksFromLogs();
                if (!planks.success && this._countItemLike('_planks') < neededPlanks) {
                    return { success: false, message: `Cannot craft planks: ${planks.message}` };
                }
            }
        }

        if (this._countItem('stick') < minSticks) {
            if (this._countItemLike('_planks') < 2) {
                return { success: false, message: 'Need planks to craft replacement sticks' };
            }
            const sticks = await this._craftSticksFromPlanks();
            if (!sticks.success && this._countItem('stick') < minSticks) {
                return { success: false, message: `Cannot craft replacement sticks: ${sticks.message}` };
            }
        }

        if (this._countItemLike('_planks') < minPlanks || this._countItem('stick') < minSticks) {
            return {
                success: false,
                message: `Insufficient wood supplies: planks=${this._countItemLike('_planks')}, sticks=${this._countItem('stick')}`
            };
        }

        return { success: true, message: 'Wood supplies ready' };
    }

    async _ensureCraftingTableReady() {
        const nearby = this.bot.findBlock({ matching: b => b.name === 'crafting_table', maxDistance: 32 });
        if (nearby || this._hasItem('crafting_table')) return { success: true, message: 'Crafting table ready' };

        const supplies = await this._ensureWoodSupplies(4, 0);
        if (!supplies.success) return supplies;

        if (this._countItemLike('_planks') < 4) {
            return { success: false, message: 'Need 4 planks for crafting table' };
        }
        return await this._craftItem('crafting_table', 1);
    }

    _canCraftWoodenPickaxe() {
        return (
            this._countItemLike('_planks') >= 3 &&
            this._countItem('stick') >= 2 &&
            (this._hasItem('crafting_table') || this.bot.findBlock({ matching: b => b.name === 'crafting_table', maxDistance: 32 }) !== null)
        );
    }

    _canCraftStonePickaxe() {
        return (
            this._countCobbleMaterials() >= 3 &&
            this._countItem('stick') >= 2 &&
            (this._hasItem('crafting_table') || this.bot.findBlock({ matching: b => b.name === 'crafting_table', maxDistance: 32 }) !== null)
        );
    }

    _bestUsablePickaxeAtLeast(tier, minUses = 1) {
        const minTier = this._pickaxeTierIndex(tier);
        if (minTier < 0) return null;

        return this.bot.inventory.items()
            .filter(item => item.name.endsWith('_pickaxe'))
            .filter(item => this._pickaxeTierIndex(item.name) >= minTier)
            .filter(item => this._toolRemainingUses(item) >= minUses)
            .sort((a, b) => {
                const tierDiff = this._pickaxeTierIndex(b.name) - this._pickaxeTierIndex(a.name);
                if (tierDiff !== 0) return tierDiff;
                return this._toolRemainingUses(b) - this._toolRemainingUses(a);
            })[0] || null;
    }

    _hasUsablePickaxeAtLeast(tier, minUses = 1) {
        return this._bestUsablePickaxeAtLeast(tier, minUses) !== null;
    }

    _pickaxeTierIndex(itemOrTierName) {
        const name = String(itemOrTierName || '');
        const tier = PICKAXE_TIERS.find(t => name === t || name.startsWith(`${t}_pickaxe`));
        return PICKAXE_TIERS.indexOf(tier);
    }

    _toolRemainingUses(item) {
        const maxDurability = this._toolMaxDurability(item);
        if (!Number.isFinite(maxDurability) || maxDurability <= 0) return Number.POSITIVE_INFINITY;

        const nbtDamage = item?.nbt?.value?.Damage?.value;
        const used = typeof item?.durabilityUsed === 'number'
            ? item.durabilityUsed
            : (typeof nbtDamage === 'number' ? nbtDamage : 0);
        return Math.max(0, maxDurability - used);
    }

    _toolMaxDurability(item) {
        if (typeof item?.maxDurability === 'number') return item.maxDurability;
        try {
            const mcData = require('minecraft-data')(this.bot.version);
            return mcData.itemsByName[item.name]?.maxDurability ?? Number.POSITIVE_INFINITY;
        } catch (_) {
            return Number.POSITIVE_INFINITY;
        }
    }

    _hasItem(itemName) {
        return this.bot.inventory.items().some(i => i.name === itemName);
    }

    _hasItemLike(pattern) {
        return this.bot.inventory.items().some(i => i.name.includes(pattern));
    }

    _countItem(itemName) {
        return this.bot.inventory.items()
            .filter(i => i.name === itemName)
            .reduce((sum, i) => sum + i.count, 0);
    }

    _countItemLike(pattern) {
        return this.bot.inventory.items()
            .filter(i => i.name.includes(pattern))
            .reduce((sum, i) => sum + i.count, 0);
    }

    _countCobbleMaterials() {
        return this.bot.inventory.items()
            .filter(i => COBBLE_MATERIALS.includes(i.name))
            .reduce((sum, i) => sum + i.count, 0);
    }

    _countSmeltableIron() {
        return this.bot.inventory.items()
            .filter(i => SMELTABLE_IRON_ITEMS.includes(i.name))
            .reduce((sum, i) => sum + i.count, 0);
    }

    _hasFood() {
        return this.bot.inventory.items().some(item => 
            item.name.includes('apple') || 
            item.name.includes('bread') || 
            item.name.includes('cooked') ||
            item.name.includes('steak')
        );
    }

    _getInventorySnapshot() {
        const snapshot = {};
        for (const item of this.bot.inventory.items()) {
            snapshot[item.name] = (snapshot[item.name] || 0) + item.count;
        }
        return snapshot;
    }

    _calculateInventoryReward(before, after) {
        // Reward for gaining new items
        let reward = 0;
        const techTreeValues = {
            // Wood tier
            'oak_log': 0.1, 'birch_log': 0.1, 'spruce_log': 0.1,
            'oak_planks': 0.05, 'birch_planks': 0.05,
            'stick': 0.02,
            'crafting_table': 0.3,
            'wooden_pickaxe': 0.5,
            // Stone tier
            'cobblestone': 0.1,
            'stone_pickaxe': 1.0,
            // Iron tier
            'coal': 0.1,
            'iron_ore': 0.5,
            'raw_iron': 0.5,
            'furnace': 0.8,
            'iron_ingot': 1.0,
            'iron_pickaxe': 2.0,
            'iron_helmet': 3.0,
            'iron_chestplate': 4.5,
            'iron_leggings': 4.0,
            'iron_boots': 2.5,
            // Diamond tier
            'diamond': 5.0,
            'diamond_pickaxe': 10.0,
            'diamond_helmet': 8.0,
            'diamond_chestplate': 12.0,
            'diamond_leggings': 10.0,
            'diamond_boots': 6.0
        };
        
        for (const [item, count] of Object.entries(after)) {
            const gained = count - (before[item] || 0);
            if (gained > 0 && techTreeValues[item]) {
                reward += techTreeValues[item] * gained;
            }
        }
        
        return reward;
    }
}

module.exports = SkillManager;
