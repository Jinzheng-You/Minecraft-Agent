"use strict";

/**
 * Small process supervisor for the Mineflayer bridge.
 *
 * index.js intentionally owns one bot lifecycle. This runner restarts it when
 * the server closes the connection, a plugin throws, or a version mismatch
 * causes an early exit. Python's environment reconnect logic will attach to
 * the bridge again after the child is back.
 */

const { spawn } = require("child_process");
const path = require("path");

const restartDelayMs = Number(process.env.RECONNECT_DELAY_MS || 5000);
const maxRestarts = Number(process.env.MAX_RESTARTS || 1000);
let restarts = 0;
let child = null;
let shuttingDown = false;

function startChild() {
  const indexPath = path.join(__dirname, "index.js");
  child = spawn(process.execPath, [indexPath], {
    cwd: path.resolve(__dirname, ".."),
    env: process.env,
    stdio: "inherit",
  });

  child.on("exit", (code, signal) => {
    child = null;
    if (shuttingDown) {
      process.exit(code || 0);
      return;
    }
    restarts += 1;
    console.warn(`[Runner] Mineflayer exited code=${code} signal=${signal}; restart ${restarts}/${maxRestarts}`);
    if (restarts > maxRestarts) {
      console.error("[Runner] Restart limit reached.");
      process.exit(code || 1);
      return;
    }
    setTimeout(startChild, restartDelayMs);
  });
}

function shutdown() {
  shuttingDown = true;
  if (child) {
    child.kill("SIGINT");
  } else {
    process.exit(0);
  }
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

startChild();
